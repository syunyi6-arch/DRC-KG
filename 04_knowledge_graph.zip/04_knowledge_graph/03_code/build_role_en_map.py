# -*- coding: utf-8 -*-
"""Generate role_en_map.json: Chinese transmission-participant role -> English.

Why this exists
---------------
`02_annotations/*-en.xlsx` sheet `05_Transmission_Class` column `Instance Role`
was translated for the English corpus and for the increment batch, but the main
Chinese batch kept the Chinese annotation text.  `transmission_participants.role_en`
therefore mixed two languages (1628 / 1776 rows Chinese).

This script pairs every distinct Chinese role with a reviewed English rendering and
writes `role_en_map.json`, which is the single authority used by
  * build_kg_tables.py  (materialises role_en; fails if a role has no mapping), and
  * the workbook fix-up that rewrites the Instance Role column of the CN -en book.

Order of the list is the descending-frequency order of the distinct roles in the
current release; the script rebuilds it from the table and asserts the pairing so a
row cannot silently drift.

Run:  python -X utf8 04_knowledge_graph/03_code/build_role_en_map.py
"""
import csv
import json
import re
import sys
from collections import Counter
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")

ROOT = Path(__file__).resolve().parents[2]
TABLE = ROOT / "04_knowledge_graph" / "01_standardized_data" / "transmission_participants.csv"
OUT = Path(__file__).resolve().parent / "role_en_map.json"
CJK = re.compile(r"[\u4e00-\u9fff]")

# Reviewed English renderings, in the same order as the distinct Chinese roles in
# transmission_participants.csv (descending frequency), verified by the assertions below.
EN = [
    "Transmission association claim instance",
    "Original-text tail entity",
    "Original-text head entity",
    "Transmission vector attributed by the authors",
    "Target outbreak",
    "Candidate travel-associated area; not a confirmed infection site",
    "Population survey group, 29% of whom had visited Shiwan",
    "Outbreak with observed spread",
    "Affected spatial extent",
    "Authors' attribution of mosquito-bite exposure and infection; explicitly not an aunt-to-nephew transmission",
    "Candidate infected person",
    "Site where exposure occurred",
    "Associated exposure event",
    "Authors' explicit attribution of the local outbreak to an imported case",
    "Candidate import-source group identified by the authors",
    "Local outbreak outcome",
    "Area where the outbreak occurred",
    "Authors' attribution of Aedes albopictus as the main vector of this outbreak",
    "Associated outbreak",
    "Main vector judged by the authors",
    "Pathogen serotype of this outbreak",
    "Husband as the authors' candidate source / domestic imported case",
    "Locally infected case / secondary case inferred by the authors",
    "Candidate import-source patient",
    "Locally infected patient",
    "Local outbreak attributed by the authors",
    "Candidate co-located infection during the couple's joint business in another province; a shared infected mosquito or direct husband-to-wife transmission is not confirmed",
    "Case group (married couple)",
    "Shared business site (not a confirmed infection site)",
    "Candidate import-exposure area",
    "Local cluster triggered by an imported case - researchers' outbreak-level attribution",
    "Candidate import infection source",
    "Indigenous cluster attributed by the authors",
    "Local cluster triggered by an imported case - authors' outbreak-level causal attribution",
    "Case type of the import source",
    "Local cluster event",
    "Outbreak-level attribution of the import source",
    "Imported case group attributed by the authors",
    "Transmission attribution target: community local outbreak",
    "Research question on the nearby same-serotype outbreak in 2013 and the continuous local transmission after the 2014 virus localisation",
    "Historical outbreak site near the 2013 location",
    "Claim of sustained local transmission pending further study",
    "Localisation question left unresolved in the source text",
    "Source judgement for a single imported infection linked to travel to Guangzhou; no confirmable local secondary transmission chain found",
    "Imported case / candidate infected person",
    "Out-of-town residence relevant to the infection-source judgement",
    "Case-classification judgement result",
    "Attribution of an overseas-travel import source; not a person-by-person transmission chain",
    "Group of confirmed cases returning from abroad",
    "Pre-return work and possible infection area",
    "Attribution of the local outbreak to an import",
    "Candidate infection source, identity not identified",
    "Outbreak-level attribution target",
    "Household clustering and generation inference",
    "Household contacts and the population involved in generation inference",
    "Investigators' generation classification",
    "One case reported at a nearby construction site triggered preventive vector control; cross-site transmission not confirmed",
    "Nearby potential risk site",
    "Case reported at the nearby construction site",
    "Preventive intensified vector control at this construction site",
    "Authors' source-tracing attribution of the local outbreak to an imported case; place names conflict between Cambodia and Thailand across sections, and the introducer was not tested",
    "Presumed imported case designated by the authors",
    "Outbreak attribution target",
    "Authors' explanation of spread from Shanggan to surrounding villages and Fuzhou districts via vectors and population movement",
    "Local outbreak",
    "Vector the authors consider present",
    "Early outbreak centre",
    "Annual-report chronology: imported cases preceded local cases; no direct evidence of causal transmission yet",
    "Earlier-reported case category; not a confirmed infection source",
    "Later-reported case category; not a confirmed infected person",
    "Authors' inference of transmission by indigenous Aedes albopictus",
    "Field vector survey evidence",
    "Candidate vector not captured in the field",
    "Detected locally and presumed to be the main vector",
    "Indigenous outbreak attribution target",
    "Inference of few introduction events supported by the high genomic homology of the viruses",
    "DENV-2 strains obtained from seven case samples",
    "Viral phylogenetic cluster",
    "Travel exposure and source-area judgement for a domestic imported case",
    "Domestic imported case",
    "Travel exposure area",
    "History of domestic mosquito-bite exposure",
    "Shared Thailand travel and possible mosquito exposure of the mother and daughter, both imported cases",
    "Imported case A",
    "Imported case B",
    "Shared travel destination",
    "Clue to bite exposure in a shared environment during travel",
    "Hypothesis that the serotype IV indigenous outbreak was caused by an imported case or an infected vector",
    "Local three-case cluster event",
    "Candidate import source proposed in the paper; the specific individual is undetermined",
    "Epidemiological and E-gene evidence for a shared infection source of two cases working in the same shop",
    "Two cases working in the same shop with close onset dates",
    "Shared work exposure environment",
    "Shared-source conclusion supported by the authors",
    "Investigation evidence for case and outbreak classification",
    "This import-related outbreak in Jiaxiang County",
    "Reported case under evaluation",
    "Group with market mosquito-bite exposure before illness onset",
    "Infection-risk clue linked to market exposure",
    "Vector breeding risk indicators across shops",
    "Hypothesis that Guangzhou workers may have introduced DENV-1 into the Huilai County construction site",
    "Construction-site outbreak reported here",
    "Candidate imported person whose infection status is undetermined",
    "Genetic relatedness evidence between site virus D14466 and Guangzhou D14231",
    "Gene sequence of the Huilai construction-site isolate",
    "Virus strain isolated from an early-September case in Guangzhou",
    "Clustering association of 12 infected persons sharing the flower-and-bird market exposure environment",
    "Same-serotype pathogen clue from isolation and testing of confirmed cases",
    "Infected persons associated with the flower-and-bird market",
    "Shared exposure environment with the specific biting site undetermined",
    "Hypothesis that transported plants introduced infected Aedes mosquitoes and larvae",
    "Plants possibly transported across regions",
    "Mosquito larvae collected and tested negative",
    "Market with a local case cluster",
    "DENV-1 genomes highly homologous to 2023 epidemic strains in Yunnan and Guangdong",
    "Four DENV nucleic-acid-positive serum specimens",
    "Three successfully obtained whole-genome sequences",
    "Non-local DENV-1 reference strains used for comparison",
    "No new cases within 25 days after the last case and vector-index control results",
    "This outbreak, reported as brought under control",
    "No newly reported cases within the 25-day observation window",
    "Aedes density index declining during the monitoring phase",
    "Onset of case 1 preceded cases 2 and 3 by about 15 days; the specific infection chain is unclear",
    "Two patients with later onset",
    "Patient with earlier onset",
    "Temporal evidence of onset order",
    "Local infection cluster under response",
    "No newly reported cases within 25 days after the onset of case 3",
    "Aedes density index after control measures",
    "Target corresponding to the claim; not an empirically established transmission direction",
    "One presumed centre of the geographic transmission chain",
    "Inferred head entity / source end",
    "Inferred tail entity / target end",
    "Transmission claim instance",
    "Authors' attribution or risk judgement in the source text",
    "Source or related object",
    "Outbreak or observed event being explained",
]


def main():
    rows = list(csv.DictReader(open(TABLE, encoding="utf-8-sig", newline="")))
    zh = Counter(r["role_raw"] for r in rows if CJK.search(r["role_en"]))
    if not zh and OUT.exists():
        # Already fixed: the map is the authority and must not be regenerated from
        # a table that no longer carries Chinese role_en values.
        existing = json.loads(OUT.read_text(encoding="utf-8"))
        if len(existing) != len(EN):
            raise SystemExit("existing map has %d entries, expected %d" % (len(existing), len(EN)))
        print("role_en_map.json: already fixed (%d roles), nothing to do" % len(existing))
        return
    ordered = [k for k, _ in zh.most_common()]
    if len(ordered) != len(EN):
        raise SystemExit("distinct Chinese roles %d != translations %d" % (len(ordered), len(EN)))
    mapping = {}
    for key, en in zip(ordered, EN):
        if not CJK.search(key):
            raise SystemExit("unexpected non-Chinese key: %r" % key)
        if CJK.search(en):
            raise SystemExit("translation still contains Chinese: %r -> %r" % (key, en))
        mapping[key] = en
    OUT.write_text(json.dumps(mapping, ensure_ascii=False, indent=1, sort_keys=True) + "\n",
                   encoding="utf-8")
    print("role_en_map.json:", len(mapping), "roles,", sum(zh.values()), "rows affected")


if __name__ == "__main__":
    main()
