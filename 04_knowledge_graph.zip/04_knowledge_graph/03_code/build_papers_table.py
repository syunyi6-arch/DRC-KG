# -*- coding: utf-8 -*-
"""Rebuild 01_source_literature/DRC-KG_261_Research_Papers.{csv,xlsx} from the KG tables.

The literature table is the human-facing index of the 261 research cases: bibliographic
metadata (title / authors / journal / publication_year) plus the per-case row and fact
counts of the knowledge graph. The metadata columns are carried over verbatim; every count
column is recomputed from 04_knowledge_graph/01_standardized_data/cases.csv, so the index
can never drift from the tables it describes. `n_increment_rows` records how many annotation
rows the 11-15 incremental batch (increment_1115) added to that case.

Run:  python -X utf8 04_knowledge_graph/03_code/build_papers_table.py

The CSV uses UTF-8 with BOM (utf-8-sig, so Excel on a Chinese Windows still opens it without
asking); the XLSX carries the same table.
"""
import csv
import sys
from pathlib import Path

import openpyxl
from openpyxl.styles import Alignment, Font
from openpyxl.utils import get_column_letter

sys.stdout.reconfigure(encoding="utf-8")

ROOT = Path(__file__).resolve().parents[2]
Z = ROOT
CASES = Z / "04_knowledge_graph" / "01_standardized_data" / "cases.csv"
OUT_DIR = Z / "01_source_literature"
CSV_OUT = OUT_DIR / "DRC-KG_261_Research_Papers.csv"
XLSX_OUT = OUT_DIR / "DRC-KG_261_Research_Papers.xlsx"
CSV_ENCODING = "utf-8-sig"

COUNT_COLS = ["n_01", "n_02", "n_03", "n_04", "n_05", "n_06", "n_07",
              "total_source_rows", "has_rules", "has_transmission",
              "n_entities", "n_attributes", "n_relations", "n_transmission",
              "n_rules", "n_knowledge_units", "n_evidence"]
EXTRA_COLS = ["n_increment_rows"]          # 增量批次（increment_1115）新增行数
META_COLS = ["title", "authors", "journal", "publication_year"]
COLUMNS = ["case_id", "language"] + META_COLS + COUNT_COLS + EXTRA_COLS


def read_csv(path, encoding):
    with open(path, encoding=encoding, newline="") as handle:
        return list(csv.DictReader(handle))


def main():
    cases = read_csv(CASES, "utf-8-sig")
    previous = {row["case_id"]: row for row in read_csv(CSV_OUT, CSV_ENCODING)}
    print("cases.csv      :", len(cases), "rows")
    print("previous index :", len(previous), "rows")

    missing_meta, title_mismatch, rows = [], [], []
    for case in cases:
        cid = case["case_id"]
        old = previous.get(cid)
        if old is None:
            missing_meta.append((cid, "not in the previous edition"))
            old = {}
        row = {"case_id": cid, "language": case["language"]}
        for field in META_COLS:
            row[field] = old.get(field, "") or case.get(field, "")
        if old.get("title") and case.get("title") and old["title"] != case["title"]:
            title_mismatch.append((cid, old["title"], case["title"]))
        for field in COUNT_COLS:
            row[field] = case.get(field, "")
        row["n_increment_rows"] = case.get("n_increment_rows", "0") or "0"
        for field in META_COLS[1:]:
            if not row[field]:
                missing_meta.append((cid, field))
        rows.append(row)

    if len(rows) != len(cases):
        raise SystemExit("row count mismatch: %d != %d" % (len(rows), len(cases)))

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    with open(CSV_OUT, "w", encoding=CSV_ENCODING, newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=COLUMNS, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
    print("wrote", CSV_OUT.name, CSV_OUT.stat().st_size, "B", "(encoding=%s)" % CSV_ENCODING)

    book = openpyxl.Workbook()
    sheet = book.active
    sheet.title = "DRC-KG_261_Research_Papers"
    sheet.append(COLUMNS)
    for cell in sheet[1]:
        cell.font = Font(bold=True)
        cell.alignment = Alignment(vertical="center")
    int_cols = {"n_02", "n_03", "n_04", "n_05", "n_06", "n_07", "n_entities", "n_attributes",
                "n_relations", "n_transmission", "n_rules", "n_knowledge_units", "n_evidence"}
    for row in rows:
        values = []
        for column in COLUMNS:
            value = row[column]
            if column in int_cols or column in ("n_01", "total_source_rows", "n_increment_rows"):
                try:
                    value = int(value)
                except (TypeError, ValueError):
                    value = value
            values.append(value)
        sheet.append(values)
    sheet.freeze_panes = "C2"
    widths = {"case_id": 10, "language": 9, "title": 58, "authors": 14, "journal": 26,
              "publication_year": 10}
    for index, column in enumerate(COLUMNS, 1):
        sheet.column_dimensions[get_column_letter(index)].width = widths.get(column, 13)
    book.save(XLSX_OUT)
    print("wrote", XLSX_OUT.name, XLSX_OUT.stat().st_size, "B")

    touched = [r for r in rows if int(r["n_increment_rows"] or 0) > 0]
    print("cases with increment rows:", len(touched),
          "| rows added:", sum(int(r["n_increment_rows"]) for r in touched))
    if missing_meta:
        print("MISSING metadata:", len(missing_meta))
        for item in missing_meta[:20]:
            print("  ", item)
    if title_mismatch:
        print("TITLE drift vs previous edition:", len(title_mismatch))
        for cid, old, new in title_mismatch[:10]:
            print("  ", cid, "|", old, "->", new)
    print("DONE")


if __name__ == "__main__":
    main()
