# -*- coding: utf-8 -*-
"""Knowledge-graph data build, derived ONLY from DRC-KG/02_annotations (4 aggregation workbooks).

The 149-row increment batch is already merged into the same workbooks: the two -zh workbooks
carry a trailing 批次 column, where increment_1115 marks those rows and a blank cell marks the
main annotation batch. Its English labels are the canonical terms of
03_ontology/ontology_bilingual.xlsx, mirrored column-by-column in the -en workbooks.

Outputs (04_knowledge_graph/01_standardized_data/):
  cases, entities, attributes, relations, transmission, transmission_participants,
  transmission_attributes, rules, rule_elements, rule_groups, knowledge_units,
  knowledge_unit_clusters, evidence_references,
  data_dictionary.csv, release_manifest.json, README.md

Design notes
  * 中文…-中文本体.xlsx / 英文…-中文本体.xlsx  provide the Chinese ontology labels and the
    annotation content; the matching *-英文本体.xlsx files provide English labels for the very
    same rows (verified row-aligned), so every table is bilingual.
  * Ontology labels are resolved to stable term IDs / URIs through 03_统一本体/ontology_term_map.csv.
  * locator_only: no third-party sentence is written. Knowledge units carry only a
    normalised-text SHA-256 + length, never the sentence itself.
  * Evidence rows are generated one per annotation row that carries a source sentence,
    pointing at the knowledge unit it came from.
"""
import csv
import hashlib
import json
import re
import sys
import unicodedata
from collections import Counter, OrderedDict, defaultdict
from pathlib import Path

import openpyxl

sys.stdout.reconfigure(encoding="utf-8")

ROOT = Path(__file__).resolve().parents[2]
Z = ROOT
SRC = Z / "02_annotations"
ONTO = Z / "03_ontology" / "ontology_term_map.csv"
PAPERS = Z / "01_source_literature" / "DRC-KG_261_Research_Papers.csv"
# 中文参与角色 -> 英文：唯一权威映射，由 build_role_en_map.py 维护。
# *-英文本体 工作簿的 Instance Role 列曾保留中文，这里做硬校验，任何未映射的中文角色直接失败。
ROLE_EN_MAP = json.loads((Path(__file__).resolve().parent / "role_en_map.json").read_text(encoding="utf-8"))
CJK = re.compile(r"[\u4e00-\u9fff]")
OUT = Z / "04_knowledge_graph" / "01_standardized_data"
OUT.mkdir(parents=True, exist_ok=True)

LANGS = [
    ("CN", "CN_138_classification_tables_ontology-zh.xlsx", "CN_138_classification_tables_ontology-en.xlsx", "CN_138_classification_tables"),
    ("EN", "EN_123_classification_tables_ontology-zh.xlsx", "EN_123_classification_tables_ontology-en.xlsx", "EN_123_classification_tables"),
]
SHEETS = [
    ("01_普通三元组_类", "01_Plain Triple_Class", "01"),
    ("02_普通三元组_属性", "02_Plain Triple_Attribute", "02"),
    ("03_普通三元组_关系", "03_Plain Triple_Relation", "03"),
    ("04_规则汇总", "04_Rules Summary", "04"),
    ("05_传播关系_类", "05_Transmission_Class", "05"),
    ("06_传播关系_属性", "06_Transmission_Attribute", "06"),
    ("07_传播关系_关系", "07_Transmission_Relation", "07"),
]
TEXT_COL = {"01": 2, "02": 4, "03": 5, "04": 3, "05": 2, "06": 4, "07": 5}

# ---------------------------------------------------------------- ontology term map
def norm(s):
    s = unicodedata.normalize("NFKC", str(s)).strip()
    return re.sub(r"\s+", " ", s)


terms = list(csv.DictReader(open(ONTO, encoding="utf-8-sig", newline="")))
BY_ZH = {}
BY_EN = {}
for t in terms:
    BY_ZH[(t["term_kind"], norm(t["label_zh"]).lower())] = t
    BY_EN[(t["term_kind"], norm(t["label_en"]).lower())] = t
print("terms:", len(terms))

# ---------------------------------------------------------------- 复核来源校验
# 英文标签的唯一权威来源是人工复核过的 1030《统一术语映射》；这里的 CSV 必须与它逐条相等，
# 否则直接失败，避免任何一轮构建悄悄用上未复核的标签。
REVIEWED_WB = Z / "03_ontology" / "ontology_bilingual.xlsx"
REVIEWED_SHEET = "统一术语映射"
TERM_KIND_EN = {"Class": "class", "Attribute": "attribute", "Semantic Relationship": "relation"}


def _reviewed_pairs():
    book = openpyxl.load_workbook(REVIEWED_WB, read_only=True, data_only=True)
    sheet = book[REVIEWED_SHEET]
    rows = sheet.iter_rows(values_only=True)
    next(rows)
    out = set()
    for row in rows:
        if not row or row[0] is None:
            continue
        kind = TERM_KIND_EN.get(str(row[0]).strip())
        if kind is None:
            continue
        out.add((kind, norm(row[1]), norm(row[2])))
    book.close()
    return out


_reviewed = _reviewed_pairs()
_csv_pairs = {(t["term_kind"], norm(t["label_zh"]), norm(t["label_en"])) for t in terms}
if _reviewed != _csv_pairs:
    raise SystemExit(
        "ontology_term_map.csv 与复核表《%s》不一致：仅CSV %d 条，仅复核表 %d 条，示例 %r"
        % (REVIEWED_SHEET, len(_csv_pairs - _reviewed), len(_reviewed - _csv_pairs),
           sorted(_csv_pairs ^ _reviewed)[:3]))
print("reviewed term pairs:", len(_reviewed), "== term map:", len(_csv_pairs))

label_stats = Counter()          # agree / drift / unmapped
label_drift_samples = []
role_en_stats = Counter()        # mapped_from_cjk / already_english


def en_label(kind, zh, fallback):
    """英文标签一律取复核映射中的 Canonical English Term。

    fallback 是 *-英文本体 工作簿里的对应值，只用于交叉核对：与复核表不一致时计数留样，
    但仍以复核表为准。
    """
    zh = norm(zh) if zh else ""
    got = norm(fallback) if fallback is not None else ""
    if not zh:
        return got
    entry = BY_ZH.get((kind, zh.lower()))
    if entry is None:
        label_stats["unmapped"] += 1
        return got
    expected = norm(entry["label_en"])
    if got and got.lower() != expected.lower():
        label_stats["drift"] += 1
        if len(label_drift_samples) < 20:
            label_drift_samples.append([kind, zh, got, expected])
    else:
        label_stats["agree"] += 1
    return expected


def resolve(kind, zh, en):
    t = BY_ZH.get((kind, norm(zh).lower())) if zh else None
    if t is None and en:
        t = BY_EN.get((kind, norm(en).lower()))
    if t is None:
        return "", "", ""
    return t["term_id"], t["uri"], t["label_en"] if en == "" else t["label_en"]


def text_key(s):
    s = unicodedata.normalize("NFKC", str(s))
    s = re.sub(r"\s+", "", s)
    return s


def sha(s):
    return hashlib.sha256(text_key(s).encode("utf-8")).hexdigest()


# ---------------------------------------------------------------- case index from 01
def open_text(p):
    raw = open(p, "rb").read(4)
    enc = "utf-8-sig"
    try:
        open(p, encoding="utf-8-sig").read(2048)
    except UnicodeDecodeError:
        enc = "gb18030"
    return open(p, encoding=enc, newline="")


papers = {r["case_id"]: r for r in csv.DictReader(open_text(PAPERS))}
print("papers:", len(papers))

cases = OrderedDict()
counts = defaultdict(Counter)
entities = OrderedDict()          # (case, entity_norm, class_zh) -> record
attributes = []
relations = []
tr_parts = []
tr_attrs = []
tr_meta = defaultdict(lambda: {"roles": Counter(), "records": 0, "attrs": 0})
rule_rows = []
kus = OrderedDict()               # (case, text_hash) -> record
ku_order = defaultdict(int)
evidence = []
unmapped = Counter()
header_cache = {}

seq = defaultdict(lambda: defaultdict(int))


def next_id(prefix, lang, case_no, width=4):
    seq[prefix][(lang, case_no)] += 1
    return "%s-%s-%s-%0*d" % (prefix, lang, case_no, width, seq[prefix][(lang, case_no)])


# ---------------------------------------------------------------- batch constants
# 主批次：02_annotations 下四本汇总工作簿；增量批次：后续单独交付的“独立七分表”。
BATCH_MAIN = "annotation_main"
BATCH_INCREMENT = "increment_1115"
FCOL = {"01": 3, "02": 5, "03": 6, "04": 0, "05": 3, "06": 5, "07": 6}
# 每张表中承载本体标签的列 -> 术语类别，用于给只有中文列的增量表回填英文标签。
LABEL_COLS = {
    "01": [(0, "class")],
    "02": [(0, "class"), (2, "attribute")],
    "03": [(0, "class"), (3, "class"), (7, "relation")],
    "04": [],
    "05": [(0, "class")],
    "06": [(2, "attribute")],
    "07": [(0, "class"), (3, "class"), (7, "relation")],
}

FILE_INDEX = defaultdict(set)    # 源文件名 -> {case_id}
case_files = defaultdict(set)    # case_id -> {源文件名}
inc_rows = defaultdict(int)      # case_id -> 增量批次行数
inc_by_sheet = Counter()         # 表号 -> 增量批次行数
lang_rows = Counter()            # (language, 表号) -> 行数
pending_evidence = []            # 05/06/07 的证据延后追加，保持既有 evidence_id 不变


def en_of(kind, zh):
    """中文本体标签反查英文标签（增量七分表不附英文镜像表）。"""
    t = BY_ZH.get((kind, norm(zh).lower())) if zh else None
    return t["label_en"] if t else ""


def en_mirror(tag, rz):
    """为只有中文列的增量行构造与 *-英文本体 表等价的英文标签行。"""
    out = [""] * len(rz)
    for col, kind in LABEL_COLS.get(tag, ()):
        if col < len(rz) and rz[col] is not None:
            out[col] = en_of(kind, rz[col])
    return out


def ingest_row(lang, tag, rz, re_, rowno, case_id, batch, source_file):
    """一行标注 -> 实体/属性/关系/规则/传播/证据；批次与源文件进入溯源列。"""
    case_no = case_id.split("-")[1]
    counts[case_id][tag] += 1
    lang_rows[(lang, tag)] += 1
    if batch == BATCH_INCREMENT:
        inc_rows[case_id] += 1
        inc_by_sheet[tag] += 1
    if source_file:
        case_files[case_id].add(source_file)

    # knowledge unit (only when a source sentence exists)
    text = rz[TEXT_COL[tag]]
    ku_id = ""
    if text is not None and str(text).strip():
        h = sha(text)
        key = (case_id, h)
        ku = kus.get(key)
        if ku is None:
            ku_order[case_id] += 1
            ku = {"ku_id": "KU-%s-%s-%04d" % (lang, case_no, ku_order[case_id]),
                  "case_id": case_id, "language": lang, "text_length": len(text_key(text)),
                  "text_sha256": h, "n_occurrences": 0, "sheets": set(), "rows": [],
                  "batches": set(), "cluster_id": ""}
            kus[key] = ku
        ku["n_occurrences"] += 1
        ku["sheets"].add(tag)
        ku["batches"].add(batch)
        ku["rows"].append("%s/%s/%d" % (batch, tag, rowno))
        ku_id = ku["ku_id"]

    if tag == "01":
        ctype_zh = norm(rz[0])
        ctype_en = en_label("class", ctype_zh, re_[0])
        val = norm(rz[1])
        tid, uri, _ = resolve("class", ctype_zh, ctype_en)
        if not uri and ctype_zh:
            unmapped[("class", ctype_zh)] += 1
        key = (case_id, val.lower(), ctype_zh)
        ent = entities.get(key)
        if ent is None:
            ent = {"entity_id": next_id("ENT", lang, case_no), "case_id": case_id,
                   "language": lang, "entity_raw": val, "class_label_zh": ctype_zh,
                   "class_label_en": ctype_en, "class_id": tid, "class_uri": uri,
                   "n_mentions": 0, "first_source_row": rowno, "batches": set()}
            entities[key] = ent
        ent["n_mentions"] += 1
        ent["batches"].add(batch)
        if ku_id:
            evidence.append(("entity", ent["entity_id"], case_id, lang, ku_id,
                             "mention_evidence", "01", rowno, batch, source_file))

    elif tag == "02":
        cls_zh = norm(rz[0])
        cls_en = en_label("class", cls_zh, re_[0])
        ent_raw = norm(rz[1])
        at_zh = norm(rz[2])
        at_en = en_label("attribute", at_zh, re_[2])
        atid, auri, _ = resolve("attribute", at_zh, at_en)
        if not auri and at_zh:
            unmapped[("attribute", at_zh)] += 1
        cid, curi, _ = resolve("class", cls_zh, cls_en)
        if not curi and cls_zh:
            unmapped[("class", cls_zh)] += 1
        attributes.append({
            "attribute_id": next_id("ATT", lang, case_no), "case_id": case_id,
            "language": lang, "owner_entity_raw": ent_raw,
            "class_label_zh": cls_zh, "class_label_en": cls_en, "class_uri": curi,
            "attribute_label_zh": at_zh, "attribute_label_en": at_en,
            "attribute_id_ont": atid, "attribute_uri": auri,
            "attribute_value": norm(rz[3]) if rz[3] is not None else "",
            "value_language": lang, "source_sheet": "02", "source_row": rowno,
            "source_file": source_file, "source_batch": batch,
        })
        if ku_id:
            evidence.append(("attribute", attributes[-1]["attribute_id"], case_id, lang,
                             ku_id, "assertion_evidence", "02", rowno, batch, source_file))

    elif tag == "03":
        h_zh = norm(rz[0])
        h_en = en_label("class", h_zh, re_[0])
        pred = norm(rz[2])
        t_zh = norm(rz[3])
        t_en = en_label("class", t_zh, re_[3])
        on_zh = norm(rz[7])
        on_en = en_label("relation", on_zh, re_[7])
        rid, ruri, _ = resolve("relation", on_zh, on_en)
        if not ruri and on_zh:
            unmapped[("relation", on_zh)] += 1
        hcid, hcuri, _ = resolve("class", h_zh, h_en)
        tcid, tcuri, _ = resolve("class", t_zh, t_en)
        relations.append({
            "relation_id": next_id("REL", lang, case_no), "case_id": case_id,
            "language": lang,
            "head_class_zh": h_zh, "head_class_en": h_en, "head_class_uri": hcuri,
            "head_value": norm(rz[1]),
            "relation_raw": pred,
            "ontology_relation_zh": on_zh, "ontology_relation_en": on_en,
            "ontology_relation_id": rid, "ontology_relation_uri": ruri,
            "tail_class_zh": t_zh, "tail_class_en": t_en, "tail_class_uri": tcuri,
            "tail_value": norm(rz[4]),
            "source_sheet": "03", "source_row": rowno,
            "source_file": source_file, "source_batch": batch,
        })
        if ku_id:
            evidence.append(("relation", relations[-1]["relation_id"], case_id, lang,
                             ku_id, "assertion_evidence", "03", rowno, batch, source_file))

    elif tag == "04":
        elem_zh, elem_en = norm(rz[4]), norm(re_[4])
        rule_rows.append({"case_id": case_id, "language": lang,
                          "research_case": norm(rz[1]), "title_block": norm(rz[2]),
                          "element_zh": elem_zh, "element_en": elem_en,
                          "content": rz[5] if rz[5] is not None else "",
                          "ku_id": ku_id, "row": rowno, "case_no": case_no,
                          "source_file": source_file, "source_batch": batch})

    elif tag == "05":
        tr_id = norm(rz[4]) if rz[4] is not None else ""
        role = norm(rz[5]) if rz[5] is not None else ""
        ctype_zh = norm(rz[0])
        ctype_en = en_label("class", ctype_zh, re_[0])
        cid, curi, _ = resolve("class", ctype_zh, ctype_en)
        role_en = norm(re_[5]) if re_[5] is not None else ""
        if CJK.search(role_en):
            mapped = ROLE_EN_MAP.get(role)
            if mapped is None:
                raise SystemExit(
                    "role_en 缺少英文映射：%r（案例 %s 第 %d 行）；请补 "
                    "04_knowledge_graph/03_code/role_en_map.json" % (role, case_id, rowno))
            role_en = mapped
            role_en_stats["mapped_from_cjk"] += 1
        elif role_en:
            role_en_stats["already_english"] += 1
        tr_parts.append({
            "participant_id": "", "transmission_id": tr_id, "case_id": case_id,
            "language": lang, "class_label_zh": ctype_zh, "class_label_en": ctype_en,
            "class_uri": curi, "entity_value": norm(rz[1]), "role_raw": role,
            "role_en": role_en,
            "source_row": rowno, "ku_id": ku_id,
        })
        tr_meta[tr_id]["roles"][role] += 1
        if ku_id:
            pending_evidence.append(("transmission", tr_id, case_id, lang, ku_id,
                                     "participant_evidence", "05", rowno, batch, source_file))

    elif tag == "06":
        tr_id = norm(rz[6]) if rz[6] is not None else ""
        at_zh = norm(rz[2])
        at_en = en_label("attribute", at_zh, re_[2])
        tr_attrs.append({"transmission_id": tr_id, "case_id": case_id, "language": lang,
                         "attribute_label_zh": at_zh, "attribute_label_en": at_en,
                         "attribute_value": norm(rz[3]) if rz[3] is not None else "",
                         "source_row": rowno, "ku_id": ku_id})
        tr_meta[tr_id]["attrs"] += 1
        if ku_id:
            pending_evidence.append(("transmission", tr_id, case_id, lang, ku_id,
                                     "attribute_evidence", "06", rowno, batch, source_file))

    elif tag == "07":
        tr_id = norm(rz[8]) if rz[8] is not None else ""
        tr_meta[tr_id]["records"] += 1
        if ku_id:
            pending_evidence.append(("transmission", tr_id, case_id, lang, ku_id,
                                     "relation_evidence", "07", rowno, batch, source_file))


# ---------------------------------------------------------------- read every annotation row
# -zh 工作簿末两列：批次（increment_1115 = 增量批次，空白 = 主批次）、批次行号（该批自身的原行号）。
def iter_annotation_rows():
    for lang, fz, fe, wbname in LANGS:
        wbz = openpyxl.load_workbook(SRC / fz, read_only=True, data_only=True)
        wbe = openpyxl.load_workbook(SRC / fe, read_only=True, data_only=True)
        for sz, se, tag in SHEETS:
            wsz, wse = wbz[sz], wbe[se]
            iz = wsz.iter_rows(values_only=True)
            ie = wse.iter_rows(values_only=True)
            hz = next(iz)
            he = next(ie)
            header_cache[tag] = (hz, he)
            bidx = next((i for i, v in enumerate(hz) if v is not None and norm(v) == "批次"), None)
            oidx = next((i for i, v in enumerate(hz) if v is not None and norm(v) == "批次行号"), None)
            rowno = 0
            for rz, re_ in zip(iz, ie):
                rowno += 1
                if rz is None or all(v is None for v in rz):
                    continue
                rz = list(rz) + [None] * (len(hz) - len(rz))
                re_ = list(re_) + [None] * (len(he) - len(re_))
                is_inc = (bidx is not None and bidx < len(rz) and rz[bidx] is not None
                          and norm(rz[bidx]) == BATCH_INCREMENT)
                order = rowno
                if is_inc and oidx is not None and oidx < len(rz) and rz[oidx] is not None:
                    order = int(rz[oidx])
                src_file = norm(rz[FCOL[tag]]) if rz[FCOL[tag]] is not None else ""
                m = re.match(r"^(\d{3})_", src_file)
                if not m:
                    raise SystemExit("[%s %s] unmapped source file: %r" % (lang, tag, src_file[:60]))
                case_id = "%s-%s" % (lang, m.group(1))
                FILE_INDEX[src_file].add(case_id)
                yield (lang, tag, rz, re_, order, case_id,
                       BATCH_INCREMENT if is_inc else BATCH_MAIN, src_file)
        wbz.close()
        wbe.close()


# ---------------------------------------------------------------- ingest: main rows stream, increment rows replay by batch row number
inc_buffer = defaultdict(list)
for rec in iter_annotation_rows():
    if rec[6] == BATCH_MAIN:
        ingest_row(rec[0], rec[1], rec[2], rec[3], rec[4], rec[5], rec[6], rec[7])
    else:
        inc_buffer[rec[1]].append(rec)
for _sz, _se, tag in SHEETS:
    for rec in sorted(inc_buffer.get(tag, []), key=lambda r: r[4]):
        ingest_row(rec[0], rec[1], rec[2], rec[3], rec[4], rec[5], rec[6], rec[7])

for lang in (l[0] for l in LANGS):
    print("[%s] rows per sheet:" % lang,
          {t: lang_rows[(lang, t)] for t in sorted(TEXT_COL)})


# 05/06/07 的每一行同样是“一行标注 + 一段原文”，补齐后证据行数应严格等于标注行数
evidence.extend(pending_evidence)
print("annotation rows:", sum(sum(c.values()) for c in counts.values()))
print("increment rows:", sum(inc_rows.values()), "cases touched:", len(inc_rows),
      "by sheet:", dict(sorted(inc_by_sheet.items())))
print("entities:", len(entities), "attributes:", len(attributes), "relations:", len(relations))
print("transmission participants:", len(tr_parts), "attrs:", len(tr_attrs), "instances:", len(tr_meta))
# role_en 必须是英文：中文只允许留在 role_raw（原文角色）
_leaked = [p for p in tr_parts if CJK.search(p["role_en"])]
if _leaked:
    raise SystemExit("role_en 仍含中文 %d 条，示例 %r" % (len(_leaked), _leaked[0]["role_en"]))
role_en_stats["rows_using_reviewed_map"] = sum(1 for p in tr_parts if p["role_raw"] in ROLE_EN_MAP)
role_en_stats["rows_other"] = len(tr_parts) - role_en_stats["rows_using_reviewed_map"]
print("rule rows:", len(rule_rows), "knowledge units:", len(kus))
print("unmapped ontology labels:", len(unmapped), sum(unmapped.values()))
print("english labels: agree %d | drift %d | unmapped %d"
      % (label_stats["agree"], label_stats["drift"], label_stats["unmapped"]))
if label_stats["drift"]:
    print("WARNING label drift vs reviewed ontology:", label_drift_samples[:5])

# ---------------------------------------------------------------- rules
rules = OrderedDict()
rule_seq = defaultdict(int)
for r in rule_rows:
    key = (r["case_id"], r["title_block"], r["ku_id"])
    rule = rules.get(key)
    if rule is None:
        rule_seq[r["case_id"]] += 1
        rule = {"rule_id": "RULE-%s-%s-%04d" % (r["language"], r["case_no"], rule_seq[r["case_id"]]),
                "rule_group_id": "", "case_id": r["case_id"], "language": r["language"],
                "research_case": r["research_case"], "title_block": r["title_block"],
                "ku_id": r["ku_id"], "elements": []}
        rules[key] = rule
    rule["elements"].append(r)

groups = OrderedDict()
group_seq = defaultdict(int)
for (case_id, block, _), rule in rules.items():
    gkey = (case_id, block)
    g = groups.get(gkey)
    if g is None:
        group_seq[case_id] += 1
        g = {"rule_group_id": "RG-%s-%s-%04d" % (rule["language"], case_id.split("-")[1],
                                                group_seq[case_id]),
             "case_id": case_id, "language": rule["language"], "title_block": block,
             "n_rules": 0, "n_elements": 0}
        groups[gkey] = g
    g["n_rules"] += 1
    g["n_elements"] += len(rule["elements"])
    rule["rule_group_id"] = g["rule_group_id"]

ELEM_CAT = [("主体", "subject"), ("条件", "condition"), ("结果", "result"),
            ("依据", "authority"), ("来源", "authority")]


def categorize(label):
    for zh, cat in ELEM_CAT:
        if label.startswith(zh):
            return cat
    return "other"


rule_elements = []
rules_out = []
for rule in rules.values():
    buckets = defaultdict(list)
    for i, el in enumerate(rule["elements"], 1):
        cat = categorize(el["element_zh"]) if el["element_zh"] else "other"
        buckets[cat].append(el["content"] if el["content"] is not None else "")
        rule_elements.append({
            "rule_element_id": "%s-E%02d" % (rule["rule_id"], i),
            "rule_id": rule["rule_id"], "rule_group_id": rule["rule_group_id"],
            "case_id": rule["case_id"], "language": rule["language"],
            "element_order": i, "element_raw": el["element_zh"], "element_category": cat,
            "content": el["content"] if el["content"] is not None else "",
            "ku_id": el["ku_id"], "source_sheet": "04", "source_row": el["row"],
            "source_file": el["source_file"], "source_batch": el["source_batch"],
        })
    rules_out.append({
        "rule_id": rule["rule_id"], "rule_group_id": rule["rule_group_id"],
        "case_id": rule["case_id"], "language": rule["language"],
        "research_case": rule["research_case"], "title_block": rule["title_block"],
        "n_elements": len(rule["elements"]),
        "subject": " | ".join(buckets.get("subject", [])),
        "conditions": " | ".join(buckets.get("condition", [])),
        "result": " | ".join(buckets.get("result", [])),
        "authority": " | ".join(buckets.get("authority", [])),
        "split_status": "auto_single", "ku_id": rule["ku_id"],
        "source_rows": json.dumps([e["row"] for e in rule["elements"]]),
    })
    # evidence per rule element
    for el in rule_elements[-len(rule["elements"]):]:
        if el["ku_id"]:
            evidence.append(("rule_element", el["rule_element_id"], el["case_id"], el["language"],
                             el["ku_id"], "rule_element_evidence", "04", el["source_row"],
                             el["source_batch"], el["source_file"]))

print("rules:", len(rules_out), "elements:", len(rule_elements), "groups:", len(groups))

# 不变式：证据行数 == 标注行数（01/02/03 立即生成，04 随规则生成，05/06/07 延后合并）
annotation_rows = sum(sum(c.values()) for c in counts.values())
if len(evidence) != annotation_rows:
    raise SystemExit("evidence rows %d != annotation rows %d" % (len(evidence), annotation_rows))
print("evidence rows:", len(evidence), "== annotation rows:", annotation_rows)

# ---------------------------------------------------------------- KU clusters
clusters = OrderedDict()
for key, ku in kus.items():
    h = ku["text_sha256"]
    c = clusters.get(h)
    if c is None:
        c = {"cluster_id": "KUC-%05d" % (len(clusters) + 1), "text_sha256": h,
             "text_length": ku["text_length"], "n_knowledge_units": 0, "cases": set()}
        clusters[h] = c
    c["n_knowledge_units"] += 1
    c["cases"].add(ku["case_id"])
    ku["cluster_id"] = c["cluster_id"]

# ---------------------------------------------------------------- transmission table
tr_rows = []
tr_id_by_key = {}
for p in tr_parts:
    tr_id_by_key.setdefault((p["case_id"], p["transmission_id"]), []).append(p)
for (case_id, tr_id), parts in tr_id_by_key.items():
    roles = Counter(p["role_raw"] for p in parts)
    head = next((p["entity_value"] for p in parts if "头实体" in p["role_raw"]), "")
    tail = next((p["entity_value"] for p in parts if "尾实体" in p["role_raw"]), "")
    meta = tr_meta.get(tr_id, {"attrs": 0, "records": 0})
    graph_ready = bool(head and tail and len(parts) >= 2)
    tr_rows.append({
        "transmission_id": tr_id, "case_id": case_id, "language": parts[0]["language"],
        "n_participants": len(parts), "n_attributes": meta["attrs"],
        "n_relation_records": meta["records"], "head_participant": head,
        "tail_participant": tail, "graph_ready": "true" if graph_ready else "false",
        "role_counts": json.dumps(dict(roles), ensure_ascii=False),
        "source_sheet": "05",
    })
    for i, p in enumerate(parts, 1):
        p["participant_id"] = "%s-P%02d" % (tr_id, i)
        p["graph_ready"] = "true" if graph_ready else "false"
print("transmission instances:", len(tr_rows), "graph_ready:", sum(1 for t in tr_rows if t["graph_ready"] == "true"))

# ids for transmission attributes
for i, a in enumerate(tr_attrs, 1):
    a["transmission_attribute_id"] = "TRA-%05d" % i

# ---------------------------------------------------------------- cases table
cases_out = []
for case_id in sorted(counts, key=lambda c: (c.split("-")[0], int(c.split("-")[1]))):
    lang = case_id.split("-")[0]
    c = counts[case_id]
    p = papers.get(case_id, {})
    n_ent = sum(1 for e in entities.values() if e["case_id"] == case_id)
    n_att = sum(1 for a in attributes if a["case_id"] == case_id)
    n_rel = sum(1 for r in relations if r["case_id"] == case_id)
    n_tr = sum(1 for t in tr_rows if t["case_id"] == case_id)
    n_rules = sum(1 for r in rules_out if r["case_id"] == case_id)
    n_ku = sum(1 for k in kus.values() if k["case_id"] == case_id)
    n_ev = sum(1 for e in evidence if e[2] == case_id)
    cases_out.append({
        "case_id": case_id, "language": lang, "title": p.get("title", ""),
        "n_01": c["01"], "n_02": c["02"], "n_03": c["03"], "n_04": c["04"],
        "n_05": c["05"], "n_06": c["06"], "n_07": c["07"],
        "total_source_rows": sum(c.values()),
        "has_rules": "true" if c["04"] else "false",
        "has_transmission": "true" if (c["05"] or c["06"] or c["07"]) else "false",
        "n_entities": n_ent, "n_attributes": n_att, "n_relations": n_rel,
        "n_transmission": n_tr, "n_rules": n_rules, "n_knowledge_units": n_ku,
        "n_evidence": n_ev,
        "source_files": json.dumps(sorted(case_files.get(case_id, [])), ensure_ascii=False),
        "n_increment_rows": inc_rows.get(case_id, 0),
        "source_workbook_zh": [f for l, f, _, _ in LANGS if l == lang][0],
        "source_workbook_en": [f for l, _, f, _ in LANGS if l == lang][0],
    })
print("cases:", len(cases_out))

# ---------------------------------------------------------------- write CSVs
def write_csv(name, rows, cols):
    p = OUT / name
    with open(p, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols, lineterminator="\n", extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow(r)
    print("  %-34s %8d rows %10d B" % (name, len(rows), p.stat().st_size))
    return p


TABLES = OrderedDict()
TABLES["cases.csv"] = (cases_out, ["case_id", "language", "title", "n_01", "n_02", "n_03", "n_04",
                                   "n_05", "n_06", "n_07", "total_source_rows", "has_rules",
                                   "has_transmission", "n_entities", "n_attributes", "n_relations",
                                   "n_transmission", "n_rules", "n_knowledge_units", "n_evidence",
                                   "source_workbook_zh", "source_workbook_en"])

ent_out = []
for e in entities.values():
    e2 = dict(e)
    e2["identity_status"] = "candidate"
    e2["source_sheet"] = "01"
    e2["source_batches"] = json.dumps(sorted(e["batches"]))
    ent_out.append(e2)
TABLES["entities.csv"] = (ent_out, ["entity_id", "case_id", "language", "entity_raw",
                                    "class_label_zh", "class_label_en", "class_id", "class_uri",
                                    "n_mentions", "identity_status", "source_sheet",
                                    "first_source_row"])

TABLES["attributes.csv"] = (attributes, ["attribute_id", "case_id", "language", "owner_entity_raw",
                                         "class_label_zh", "class_label_en", "class_uri",
                                         "attribute_label_zh", "attribute_label_en",
                                         "attribute_id_ont", "attribute_uri", "attribute_value",
                                         "value_language", "source_sheet", "source_row"])

TABLES["relations.csv"] = (relations, ["relation_id", "case_id", "language", "head_class_zh",
                                       "head_class_en", "head_class_uri", "head_value",
                                       "relation_raw", "ontology_relation_zh", "ontology_relation_en",
                                       "ontology_relation_id", "ontology_relation_uri",
                                       "tail_class_zh", "tail_class_en", "tail_class_uri",
                                       "tail_value", "source_sheet", "source_row"])

TABLES["transmission.csv"] = (tr_rows, ["transmission_id", "case_id", "language", "n_participants",
                                        "n_attributes", "n_relation_records", "head_participant",
                                        "tail_participant", "graph_ready", "role_counts",
                                        "source_sheet"])

TABLES["transmission_participants.csv"] = (tr_parts, ["participant_id", "transmission_id", "case_id",
                                                      "language", "class_label_zh", "class_label_en",
                                                      "class_uri", "entity_value", "role_raw",
                                                      "role_en", "graph_ready", "source_row"])

TABLES["transmission_attributes.csv"] = (tr_attrs, ["transmission_attribute_id", "transmission_id",
                                                    "case_id", "language", "attribute_label_zh",
                                                    "attribute_label_en", "attribute_value",
                                                    "source_row"])

TABLES["rules.csv"] = (rules_out, ["rule_id", "rule_group_id", "case_id", "language",
                                   "research_case", "title_block", "n_elements", "subject",
                                   "conditions", "result", "authority", "split_status", "ku_id",
                                   "source_rows"])

TABLES["rule_elements.csv"] = (rule_elements, ["rule_element_id", "rule_id", "rule_group_id",
                                               "case_id", "language", "element_order",
                                               "element_raw", "element_category", "content",
                                               "ku_id", "source_sheet", "source_row"])

groups_out = [dict(g, n_rules=g["n_rules"], n_elements=g["n_elements"]) for g in groups.values()]
TABLES["rule_groups.csv"] = (groups_out, ["rule_group_id", "case_id", "language", "title_block",
                                          "n_rules", "n_elements"])

ku_out = []
for k in kus.values():
    ku_out.append({
        "ku_id": k["ku_id"], "case_id": k["case_id"], "language": k["language"],
        "text_length": k["text_length"], "text_sha256": k["text_sha256"],
        "text_mode": "locator_only", "n_occurrences": k["n_occurrences"],
        "source_sheets": json.dumps(sorted(k["sheets"])), "source_rows": json.dumps(k["rows"]),
        "source_batches": json.dumps(sorted(k["batches"])),
        "cluster_id": k["cluster_id"],
    })
TABLES["knowledge_units.csv"] = (ku_out, ["ku_id", "case_id", "language", "text_length",
                                          "text_sha256", "text_mode", "n_occurrences",
                                          "source_sheets", "source_rows", "cluster_id"])

cl_out = []
for c in clusters.values():
    cl_out.append({"cluster_id": c["cluster_id"], "text_sha256": c["text_sha256"],
                   "text_length": c["text_length"], "n_knowledge_units": c["n_knowledge_units"],
                   "n_cases": len(c["cases"]), "cases": json.dumps(sorted(c["cases"]))})
TABLES["knowledge_unit_clusters.csv"] = (cl_out, ["cluster_id", "text_sha256", "text_length",
                                                  "n_knowledge_units", "n_cases", "cases"])

ev_out = []
for i, (ftype, fid, case_id, lang, ku_id, role, sheet, row, batch, src_file) in \
        enumerate(evidence, 1):
    ev_out.append({"evidence_id": "EVD-%s%05d" % (case_id, i), "fact_type": ftype,
                   "fact_id": fid, "case_id": case_id, "language": lang, "ku_id": ku_id,
                   "evidence_role": role, "source_sheet": sheet, "source_row": row,
                   "source_file": src_file, "source_batch": batch})
TABLES["evidence_references.csv"] = (ev_out, ["evidence_id", "fact_type", "fact_id", "case_id",
                                              "language", "ku_id", "evidence_role",
                                              "source_sheet", "source_row"])

# ---- 溯源列：追加在原列之后，原列顺序与含义不变 -----------------------------
EXTRA_COLS = {
    "cases.csv": ["source_files", "n_increment_rows"],
    "entities.csv": ["source_batches"],
    "attributes.csv": ["source_file", "source_batch"],
    "relations.csv": ["source_file", "source_batch"],
    "rule_elements.csv": ["source_file", "source_batch"],
    "evidence_references.csv": ["source_file", "source_batch"],
    "knowledge_units.csv": ["source_batches"],
}
for _name, _extra in EXTRA_COLS.items():
    _rows, _cols = TABLES[_name]
    TABLES[_name] = (_rows, list(_cols) + _extra)

sizes = {}
for name, (rows, cols) in TABLES.items():
    p = write_csv(name, rows, cols)
    sizes[name] = p.stat().st_size

# ---------------------------------------------------------------- data dictionary
DD = [
    ("cases.csv", "case_id", "研究案例编号 CN-001…CN-138 / EN-001…EN-123",
     "Research case ID (CN-001…CN-138 / EN-001…EN-123)", "string"),
    ("cases.csv", "n_01…n_07", "该案例在 02 七张表中的原始行数",
     "Number of source rows this case contributes to each of the seven annotation sheets", "integer"),
    ("cases.csv", "total_source_rows", "七张表行数合计",
     "Total rows across the seven annotation sheets", "integer"),
    ("cases.csv", "n_entities…n_evidence", "本数据集中由该案例派生的实体/属性/关系/传播/规则/KU/证据数",
     "Entities / attributes / relations / transmission statements / rules / knowledge units / "
     "evidence records derived from this case", "integer"),
    ("entities.csv", "entity_id", "实体候选编号 ENT-<LANG>-<case>-<seq>",
     "Entity candidate ID (ENT-<LANG>-<case>-<seq>)", "string"),
    ("entities.csv", "entity_raw", "文献中的实体表述（未做全局消歧）",
     "Entity surface form as written in the source (no global disambiguation)", "string"),
    ("entities.csv", "class_label_zh / class_label_en", "本体类的中/英标签（源自 03 术语表）",
     "Chinese / English ontology class label (from the 03 term map)", "string"),
    ("entities.csv", "class_uri", "本体类 URI（urn:dengekg:ontology:class:…），未能匹配时为空",
     "Ontology class URI (urn:dengekg:ontology:class:…); empty when no term matched", "string"),
    ("entities.csv", "n_mentions", "同一案例内该实体表述的出现次数",
     "Occurrences of this entity surface form within the case", "integer"),
    ("entities.csv", "identity_status", "恒为 candidate：未做跨文献实体消歧",
     "Always candidate: no cross-paper entity disambiguation was performed", "string"),
    ("attributes.csv", "owner_entity_raw", "属性所属实体的原始表述",
     "Surface form of the entity that owns the attribute", "string"),
    ("attributes.csv", "attribute_label_zh / _en", "本体属性标签",
     "Ontology attribute label (Chinese / English)", "string"),
    ("attributes.csv", "attribute_value", "属性取值原文（未做数值归一）",
     "Attribute value as written in the source (no numeric normalisation)", "string"),
    ("relations.csv", "head_value / tail_value", "头/尾实体的原始表述",
     "Surface form of the head / tail entity", "string"),
    ("relations.csv", "relation_raw", "标注者抽取的关系表述",
     "Relation expression as annotated", "string"),
    ("relations.csv", "ontology_relation_uri", "归一化后的本体语义关系 URI",
     "Semantic relation URI after ontology normalisation", "string"),
    ("transmission.csv", "transmission_id", "传播关系实例编号（沿用标注表中的 TR-…）",
     "Transmission instance ID (kept from the annotation table, TR-…)", "string"),
    ("transmission.csv", "graph_ready", "头尾参与实体齐备且参与者≥2 时为 true（结构可入图，不代表传播已证实）",
     "true when head and tail participants are both present and there are at least two "
     "participants (structurally drawable; not proof that transmission occurred)", "boolean"),
    ("transmission.csv", "role_counts", "各参与角色的计数（JSON）",
     "Counts per participant role (JSON)", "json"),
    ("transmission_participants.csv", "role_raw / role_en", "参与者角色（原文角色 / 英译）",
     "Participant role (original annotation text / English translation)", "string"),
    ("rules.csv", "rule_id", "规则编号", "Rule ID", "string"),
    ("rules.csv", "subject/conditions/result/authority", "按要素类别聚合的规则文本（| 分隔）",
     "Rule text aggregated by element category (|-separated)", "string"),
    ("rule_elements.csv", "element_raw / element_category",
     "原始要素标签（主体/条件1…）与归一类别（subject/condition/result/authority）",
     "Original element label and normalised category (subject/condition/result/authority)", "string"),
    ("knowledge_units.csv", "text_length", "归一化（去空白）后的字符数",
     "Character count after normalisation (whitespace removed)", "integer"),
    ("knowledge_units.csv", "text_sha256",
     "归一化文本的 SHA-256，可用于去重与自校验，但不泄露原文",
     "SHA-256 of the normalised text; supports deduplication and self-checks without "
     "exposing the source text", "string"),
    ("knowledge_units.csv", "text_mode", "恒为 locator_only：只发布定位与哈希，不发布原文",
     "Always locator_only: only locators and hashes are released, not the source text", "string"),
    ("knowledge_units.csv", "source_sheets / source_rows", "该 KU 出现过的表号与行号（JSON）",
     "Sheet numbers and row numbers where this knowledge unit occurs (JSON)", "json"),
    ("knowledge_unit_clusters.csv", "cluster_id", "按文本哈希聚类的编号",
     "Cluster ID assigned by text hash", "string"),
    ("evidence_references.csv", "fact_type / fact_id", "证据指向的事实类型与编号",
     "Fact type and ID the evidence points to", "string"),
    ("evidence_references.csv", "ku_id", "证据所属知识单元",
     "Knowledge unit the evidence belongs to", "string"),
]
DD.extend([
    ("*.csv", "source_batch",
     "标注批次：annotation_main（02_annotations 主批次）或 increment_1115（11-15 增量七分表）",
     "Annotation batch: annotation_main (main 02_annotations batch) or increment_1115 "
     "(the 11-15 incremental seven-sheet table)", "string"),
    ("entities.csv / knowledge_units.csv", "source_batches",
     "该实体/KU 出现过的标注批次（JSON 数组，两批次都出现时为两个值）",
     "Annotation batches in which this entity / knowledge unit appears (JSON array; two "
     "values when it appears in both batches)", "json"),
    ("attributes.csv / relations.csv / rule_elements.csv / evidence_references.csv", "source_file",
     "该行标注对应的源文献文件名（带三位案例序号）",
     "Source article file name for this annotated row (with the three-digit case number)", "string"),
    ("cases.csv", "source_files",
     "该案例全部源文献文件名（JSON 数组；个别案例同一序号下有两份文件）",
     "All source file names for this case (JSON array; a few case numbers carry two files)", "json"),
    ("cases.csv", "n_increment_rows",
     "该案例在增量批次 increment_1115 中新增的标注行数",
     "Annotated rows this case gained from the increment_1115 batch", "integer"),
    ("knowledge_units.csv", "source_rows",
     "该 KU 出现过的位置，格式为 <批次>/<表号>/<行号>",
     "Positions where this knowledge unit occurs, as <batch>/<sheet>/<row>", "json"),
    ("transmission_attributes.csv", "transmission_attribute_id",
     "传播属性记录编号（TRA-…）",
     "Transmission attribute record ID (TRA-…)", "string"),
    ("transmission_attributes.csv", "transmission_id",
     "所属传播关系实例编号（TR-…）",
     "Owning transmission instance ID (TR-…)", "string"),
    ("transmission_attributes.csv", "attribute_label_zh / attribute_label_en",
     "该传播属性对应的本体属性标签（如 断言确定性 / Assertion Certainty）",
     "Ontology attribute label of this transmission attribute (e.g. Assertion Certainty)", "string"),
    ("transmission_attributes.csv", "attribute_value",
     "属性取值原文（未做数值归一）",
     "Attribute value as written in the source (no numeric normalisation)", "string"),
    ("transmission_attributes.csv", "source_row",
     "该行在 07 传播关系_属性 表中的行号",
     "Row number in the 07 transmission-attribute sheet", "integer"),
    ("rule_groups.csv", "rule_group_id",
     "规则组编号（RG-…）",
     "Rule group ID (RG-…)", "string"),
    ("rule_groups.csv", "title_block",
     "规则所在标题块",
     "Title block the rule sits under", "string"),
    ("rule_groups.csv", "n_rules / n_elements",
     "组内规则数 / 规则要素数",
     "Rules / rule elements in the group", "integer"),
])
with open(OUT / "data_dictionary.csv", "w", encoding="utf-8-sig", newline="") as f:
    w = csv.writer(f, lineterminator="\n")
    w.writerow(["table", "field", "description_zh", "description_en", "type"])
    for row in DD:
        w.writerow(row)
print("  data_dictionary.csv", (OUT / "data_dictionary.csv").stat().st_size)

# ---------------------------------------------------------------- manifest
def fsha(p):
    h = hashlib.sha256()
    with open(p, "rb") as fh:
        for b in iter(lambda: fh.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


counts_map = {name: len(rows) for name, (rows, _) in TABLES.items()}
manifest = {
    "version": "1.0",
    "derived_from": "02_annotations (4 aggregation workbooks) + 1115 increment batch",
    "generated": "2026-11-20",
    "increment": {
        "file": "02_annotations/*-zh.xlsx, trailing batch column = increment_1115",
        "batch": BATCH_INCREMENT,
        "rows": sum(inc_rows.values()),
        "cases_touched": len(inc_rows),
        "rows_by_sheet": dict(sorted(inc_by_sheet.items())),
        "case_binding": "case_id is bound through the full source-file name; the CN and EN numbering "
                        "repeats (070, 052, 031), so the numeric prefix alone does not identify a case",
        "label_note": "the increment sheets carry Chinese columns only; their English labels are the "
                      "human-reviewed canonical terms of the reviewed term-mapping sheet in "
                      "03_ontology/ontology_bilingual.xlsx (0 drift against the English mirror)",
    },
    "mode": "locator_only",
    "release_ready": True,
    "counts": counts_map,
    "table_hashes": {name: fsha(OUT / name) for name in TABLES},
    "label_provenance": {
        "source": "03_ontology/ontology_bilingual.xlsx, reviewed term-mapping sheet (467 terms)",
        "term_map_equals_reviewed_sheet": True,
        "english_labels_from_reviewed_map": label_stats["agree"],
        "drift_vs_reviewed_map": label_stats["drift"],
        "unmapped_labels": label_stats["unmapped"],
        "drift_samples": label_drift_samples,
        "note": "the English ontology workbooks are a cross-check only; every English label in the "
                "tables is the canonical English term of the reviewed term map",
    },
    "participant_role_provenance": {
        "source": "02_annotations/*-en.xlsx, sheet 05, Instance Role column; the Chinese role is kept "
                  "in role_raw",
        "map": "04_knowledge_graph/03_code/role_en_map.json",
        "mapped_roles": len(ROLE_EN_MAP),
        "rows_using_reviewed_map": role_en_stats["rows_using_reviewed_map"],
        "rows_from_english_mirror": role_en_stats["rows_other"],
        "rows_needing_mapping_at_build": role_en_stats["mapped_from_cjk"],
        "note": "role_en is English and Chinese stays in role_raw: a row that is already English in the "
                "mirror is used as it is, any other role is filled from the map, and the build fails "
                "if a role has no mapping or still contains Chinese",
    },
    "ontology_terms_mapped": {"total_terms": len(terms),
                              "unmapped_labels": {("%s:%s" % k): v for k, v in list(unmapped.items())[:200]},
                              "unmapped_label_kinds": dict(Counter(k[0] for k in unmapped))},
    "derivation_rules": {
        "entity": "deduplicated by (case_id, entity string, ontology class); n_mentions counts the occurrences",
        "attribute": "one row per annotation row (no aggregation); every row is one attribute fact",
        "relation": "one row per annotation row; the ontology relation is normalised through "
                    "03_ontology/ontology_term_map.csv",
        "transmission": "participants and attributes aggregated by the TR instance id of the annotation "
                        "sheets; graph_ready is the structural criterion",
        "rule": "rules aggregated by (case_id, title block, knowledge unit); elements grouped into "
                "subject / condition / result / basis",
        "knowledge_unit": "deduplicated by (case_id, SHA-256 of the normalised text)",
        "evidence": "one evidence record per annotation row that carries a source sentence, pointing at "
                    "its knowledge unit",
    },
}
(OUT / "release_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2),
                                          encoding="utf-8")
print("  release_manifest.json", (OUT / "release_manifest.json").stat().st_size)
print("DONE")
