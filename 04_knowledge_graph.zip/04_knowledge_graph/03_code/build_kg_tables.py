# -*- coding: utf-8 -*-
"""Knowledge-graph data build, derived ONLY from DRC-KG/02_分类标注成果 (4 aggregation workbooks).

Outputs (DRC-KG/知识图谱/标准化数据/):
  cases, entities, attributes, relations, transmission, transmission_participants,
  transmission_attributes, rules, rule_elements, rule_groups, knowledge_units,
  knowledge_unit_clusters, evidence_references,
  data_dictionary.csv, release_manifest.json, README.md

Design notes
  * 中文…-中文本体.xlsx / 英文…-中文本体.xlsx  provide the Chinese ontology labels and the
    annotation content; the matching *-英文本体.xlsx files provide English labels for the very
    same rows (verified row-aligned), so every table is bilingual.
  * Ontology labels are resolved to stable term IDs / URIs through 03_统一本体/ontology_term_map.csv.
  * locator_only: no third-party sentence is written. Knowledge units carry only a
    normalised-text SHA-256 + length, never the sentence itself.
  * Evidence rows are generated one per annotation row that carries a source sentence,
    pointing at the knowledge unit it came from.
"""
import csv
import hashlib
import json
import re
import sys
import unicodedata
from collections import Counter, OrderedDict, defaultdict
from pathlib import Path

import openpyxl

sys.stdout.reconfigure(encoding="utf-8")

ROOT = Path(r"D:\sc成果")
Z = ROOT / "DRC-KG"
SRC = Z / "02_annotations"
ONTO = Z / "03_ontology" / "ontology_term_map.csv"
PAPERS = Z / "01_source_literature" / "DRC-KG_261_Research_Papers.csv"
OUT = Z / "04_knowledge_graph" / "01_standardized_data"
OUT.mkdir(parents=True, exist_ok=True)

LANGS = [
    ("CN", "CN_138_classification_tables_ontology-zh.xlsx", "CN_138_classification_tables_ontology-en.xlsx", "CN_138_classification_tables"),
    ("EN", "EN_123_classification_tables_ontology-zh.xlsx", "EN_123_classification_tables_ontology-en.xlsx", "EN_123_classification_tables"),
]
SHEETS = [
    ("01_普通三元组_类", "01_Plain Triple_Class", "01"),
    ("02_普通三元组_属性", "02_Plain Triple_Attribute", "02"),
    ("03_普通三元组_关系", "03_Plain Triple_Relation", "03"),
    ("04_规则汇总", "04_Rules Summary", "04"),
    ("05_传播关系_类", "05_Transmission_Class", "05"),
    ("06_传播关系_属性", "06_Transmission_Attribute", "06"),
    ("07_传播关系_关系", "07_Transmission_Relation", "07"),
]
TEXT_COL = {"01": 2, "02": 4, "03": 5, "04": 3, "05": 2, "06": 4, "07": 5}

# ---------------------------------------------------------------- ontology term map
def norm(s):
    s = unicodedata.normalize("NFKC", str(s)).strip()
    return re.sub(r"\s+", " ", s)


terms = list(csv.DictReader(open(ONTO, encoding="utf-8-sig", newline="")))
BY_ZH = {}
BY_EN = {}
for t in terms:
    BY_ZH[(t["term_kind"], norm(t["label_zh"]).lower())] = t
    BY_EN[(t["term_kind"], norm(t["label_en"]).lower())] = t
print("terms:", len(terms))


def resolve(kind, zh, en):
    t = BY_ZH.get((kind, norm(zh).lower())) if zh else None
    if t is None and en:
        t = BY_EN.get((kind, norm(en).lower()))
    if t is None:
        return "", "", ""
    return t["term_id"], t["uri"], t["label_en"] if en == "" else t["label_en"]


def text_key(s):
    s = unicodedata.normalize("NFKC", str(s))
    s = re.sub(r"\s+", "", s)
    return s


def sha(s):
    return hashlib.sha256(text_key(s).encode("utf-8")).hexdigest()


# ---------------------------------------------------------------- case index from 01
def open_text(p):
    raw = open(p, "rb").read(4)
    enc = "utf-8-sig"
    try:
        open(p, encoding="utf-8-sig").read(2048)
    except UnicodeDecodeError:
        enc = "gb18030"
    return open(p, encoding=enc, newline="")


papers = {r["case_id"]: r for r in csv.DictReader(open_text(PAPERS))}
print("papers:", len(papers))

cases = OrderedDict()
counts = defaultdict(Counter)
entities = OrderedDict()          # (case, entity_norm, class_zh) -> record
attributes = []
relations = []
tr_parts = []
tr_attrs = []
tr_meta = defaultdict(lambda: {"roles": Counter(), "records": 0, "attrs": 0})
rule_rows = []
kus = OrderedDict()               # (case, text_hash) -> record
ku_order = defaultdict(int)
evidence = []
unmapped = Counter()
header_cache = {}

seq = defaultdict(lambda: defaultdict(int))


def next_id(prefix, lang, case_no, width=4):
    seq[prefix][(lang, case_no)] += 1
    return "%s-%s-%s-%0*d" % (prefix, lang, case_no, width, seq[prefix][(lang, case_no)])


for lang, fz, fe, wbname in LANGS:
    wbz = openpyxl.load_workbook(SRC / fz, read_only=True, data_only=True)
    wbe = openpyxl.load_workbook(SRC / fe, read_only=True, data_only=True)
    for sz, se, tag in SHEETS:
        wsz, wse = wbz[sz], wbe[se]
        iz = wsz.iter_rows(values_only=True)
        ie = wse.iter_rows(values_only=True)
        hz = next(iz)
        hе = next(ie)
        header_cache[tag] = (hz, hе)
        rowno = 0
        for rz, re_ in zip(iz, ie):
            rowno += 1
            if rz is None or all(v is None for v in rz):
                continue
            rz = list(rz) + [None] * (len(hz) - len(rz))
            re_ = list(re_) + [None] * (len(hе) - len(re_))
            # provenance / case
            fcol = 0 if tag == "04" else (3 if tag in ("01", "05") else (6 if tag in ("03", "07") else 5))
            src_file = str(rz[fcol]).strip() if rz[fcol] is not None else ""
            m = re.match(r"^(\d{3})_", src_file)
            if not m:
                raise SystemExit("[%s %s] unmapped source file: %r" % (lang, tag, src_file[:60]))
            case_no = m.group(1)
            case_id = "%s-%s" % (lang, case_no)
            counts[case_id][tag] += 1

            # knowledge unit (only when a source sentence exists)
            text = rz[TEXT_COL[tag]]
            ku_id = ""
            if text is not None and str(text).strip():
                h = sha(text)
                key = (case_id, h)
                ku = kus.get(key)
                if ku is None:
                    ku_order[case_id] += 1
                    ku = {"ku_id": "KU-%s-%s-%04d" % (lang, case_no, ku_order[case_id]),
                          "case_id": case_id, "language": lang, "text_length": len(text_key(text)),
                          "text_sha256": h, "n_occurrences": 0, "sheets": set(), "rows": [],
                          "cluster_id": ""}
                    kus[key] = ku
                ku["n_occurrences"] += 1
                ku["sheets"].add(tag)
                ku["rows"].append("%s:%d" % (tag, rowno))
                ku_id = ku["ku_id"]

            if tag == "01":
                ctype_zh, ctype_en = norm(rz[0]), norm(re_[0])
                val = norm(rz[1])
                tid, uri, _ = resolve("class", ctype_zh, ctype_en)
                if not uri and ctype_zh:
                    unmapped[("class", ctype_zh)] += 1
                key = (case_id, val.lower(), ctype_zh)
                ent = entities.get(key)
                if ent is None:
                    ent = {"entity_id": next_id("ENT", lang, case_no), "case_id": case_id,
                           "language": lang, "entity_raw": val, "class_label_zh": ctype_zh,
                           "class_label_en": ctype_en, "class_id": tid, "class_uri": uri,
                           "n_mentions": 0, "first_source_row": rowno}
                    entities[key] = ent
                ent["n_mentions"] += 1
                if ku_id:
                    evidence.append(("entity", ent["entity_id"], case_id, lang, ku_id,
                                     "mention_evidence", "01", rowno))

            elif tag == "02":
                cls_zh, cls_en = norm(rz[0]), norm(re_[0])
                ent_raw = norm(rz[1])
                at_zh, at_en = norm(rz[2]), norm(re_[2])
                atid, auri, _ = resolve("attribute", at_zh, at_en)
                if not auri and at_zh:
                    unmapped[("attribute", at_zh)] += 1
                cid, curi, _ = resolve("class", cls_zh, cls_en)
                if not curi and cls_zh:
                    unmapped[("class", cls_zh)] += 1
                attributes.append({
                    "attribute_id": next_id("ATT", lang, case_no), "case_id": case_id,
                    "language": lang, "owner_entity_raw": ent_raw,
                    "class_label_zh": cls_zh, "class_label_en": cls_en, "class_uri": curi,
                    "attribute_label_zh": at_zh, "attribute_label_en": at_en,
                    "attribute_id_ont": atid, "attribute_uri": auri,
                    "attribute_value": norm(rz[3]) if rz[3] is not None else "",
                    "value_language": lang, "source_sheet": "02", "source_row": rowno,
                })
                if ku_id:
                    evidence.append(("attribute", attributes[-1]["attribute_id"], case_id, lang,
                                     ku_id, "assertion_evidence", "02", rowno))

            elif tag == "03":
                h_zh, h_en = norm(rz[0]), norm(re_[0])
                pred = norm(rz[2])
                t_zh, t_en = norm(rz[3]), norm(re_[3])
                on_zh, on_en = norm(rz[7]), norm(re_[7])
                rid, ruri, _ = resolve("relation", on_zh, on_en)
                if not ruri and on_zh:
                    unmapped[("relation", on_zh)] += 1
                hcid, hcuri, _ = resolve("class", h_zh, h_en)
                tcid, tcuri, _ = resolve("class", t_zh, t_en)
                relations.append({
                    "relation_id": next_id("REL", lang, case_no), "case_id": case_id,
                    "language": lang,
                    "head_class_zh": h_zh, "head_class_en": h_en, "head_class_uri": hcuri,
                    "head_value": norm(rz[1]),
                    "relation_raw": pred,
                    "ontology_relation_zh": on_zh, "ontology_relation_en": on_en,
                    "ontology_relation_id": rid, "ontology_relation_uri": ruri,
                    "tail_class_zh": t_zh, "tail_class_en": t_en, "tail_class_uri": tcuri,
                    "tail_value": norm(rz[4]),
                    "source_sheet": "03", "source_row": rowno,
                })
                if ku_id:
                    evidence.append(("relation", relations[-1]["relation_id"], case_id, lang,
                                     ku_id, "assertion_evidence", "03", rowno))

            elif tag == "04":
                elem_zh, elem_en = norm(rz[4]), norm(re_[4])
                rule_rows.append({"case_id": case_id, "language": lang,
                                  "research_case": norm(rz[1]), "title_block": norm(rz[2]),
                                  "element_zh": elem_zh, "element_en": elem_en,
                                  "content": rz[5] if rz[5] is not None else "",
                                  "ku_id": ku_id, "row": rowno, "case_no": case_no})

            elif tag == "05":
                tr_id = norm(rz[4]) if rz[4] is not None else ""
                role = norm(rz[5]) if rz[5] is not None else ""
                ctype_zh, ctype_en = norm(rz[0]), norm(re_[0])
                cid, curi, _ = resolve("class", ctype_zh, ctype_en)
                tr_parts.append({
                    "participant_id": "", "transmission_id": tr_id, "case_id": case_id,
                    "language": lang, "class_label_zh": ctype_zh, "class_label_en": ctype_en,
                    "class_uri": curi, "entity_value": norm(rz[1]), "role_raw": role,
                    "role_en": norm(re_[5]) if re_[5] is not None else "",
                    "source_row": rowno, "ku_id": ku_id,
                })
                tr_meta[tr_id]["roles"][role] += 1

            elif tag == "06":
                tr_id = norm(rz[6]) if rz[6] is not None else ""
                at_zh, at_en = norm(rz[2]), norm(re_[2])
                tr_attrs.append({"transmission_id": tr_id, "case_id": case_id, "language": lang,
                                 "attribute_label_zh": at_zh, "attribute_label_en": at_en,
                                 "attribute_value": norm(rz[3]) if rz[3] is not None else "",
                                 "source_row": rowno, "ku_id": ku_id})
                tr_meta[tr_id]["attrs"] += 1

            elif tag == "07":
                tr_id = norm(rz[8]) if rz[8] is not None else ""
                tr_meta[tr_id]["records"] += 1

    wbz.close()
    wbe.close()
    print("[%s] rows per sheet:" % lang, {t: counts["%s-001" % lang][t] for t in ("01",)})

print("annotation rows:", sum(sum(c.values()) for c in counts.values()))
print("entities:", len(entities), "attributes:", len(attributes), "relations:", len(relations))
print("transmission participants:", len(tr_parts), "attrs:", len(tr_attrs), "instances:", len(tr_meta))
print("rule rows:", len(rule_rows), "knowledge units:", len(kus))
print("unmapped ontology labels:", len(unmapped), sum(unmapped.values()))

# ---------------------------------------------------------------- rules
rules = OrderedDict()
rule_seq = defaultdict(int)
for r in rule_rows:
    key = (r["case_id"], r["title_block"], r["ku_id"])
    rule = rules.get(key)
    if rule is None:
        rule_seq[r["case_id"]] += 1
        rule = {"rule_id": "RULE-%s-%s-%04d" % (r["language"], r["case_no"], rule_seq[r["case_id"]]),
                "rule_group_id": "", "case_id": r["case_id"], "language": r["language"],
                "research_case": r["research_case"], "title_block": r["title_block"],
                "ku_id": r["ku_id"], "elements": []}
        rules[key] = rule
    rule["elements"].append(r)

groups = OrderedDict()
group_seq = defaultdict(int)
for (case_id, block, _), rule in rules.items():
    gkey = (case_id, block)
    g = groups.get(gkey)
    if g is None:
        group_seq[case_id] += 1
        g = {"rule_group_id": "RG-%s-%s-%04d" % (rule["language"], case_id.split("-")[1],
                                                group_seq[case_id]),
             "case_id": case_id, "language": rule["language"], "title_block": block,
             "n_rules": 0, "n_elements": 0}
        groups[gkey] = g
    g["n_rules"] += 1
    g["n_elements"] += len(rule["elements"])
    rule["rule_group_id"] = g["rule_group_id"]

ELEM_CAT = [("主体", "subject"), ("条件", "condition"), ("结果", "result"),
            ("依据", "authority"), ("来源", "authority")]


def categorize(label):
    for zh, cat in ELEM_CAT:
        if label.startswith(zh):
            return cat
    return "other"


rule_elements = []
rules_out = []
for rule in rules.values():
    buckets = defaultdict(list)
    for i, el in enumerate(rule["elements"], 1):
        cat = categorize(el["element_zh"]) if el["element_zh"] else "other"
        buckets[cat].append(el["content"] if el["content"] is not None else "")
        rule_elements.append({
            "rule_element_id": "%s-E%02d" % (rule["rule_id"], i),
            "rule_id": rule["rule_id"], "rule_group_id": rule["rule_group_id"],
            "case_id": rule["case_id"], "language": rule["language"],
            "element_order": i, "element_raw": el["element_zh"], "element_category": cat,
            "content": el["content"] if el["content"] is not None else "",
            "ku_id": el["ku_id"], "source_sheet": "04", "source_row": el["row"],
        })
    rules_out.append({
        "rule_id": rule["rule_id"], "rule_group_id": rule["rule_group_id"],
        "case_id": rule["case_id"], "language": rule["language"],
        "research_case": rule["research_case"], "title_block": rule["title_block"],
        "n_elements": len(rule["elements"]),
        "subject": " | ".join(buckets.get("subject", [])),
        "conditions": " | ".join(buckets.get("condition", [])),
        "result": " | ".join(buckets.get("result", [])),
        "authority": " | ".join(buckets.get("authority", [])),
        "split_status": "auto_single", "ku_id": rule["ku_id"],
        "source_rows": json.dumps([e["row"] for e in rule["elements"]]),
    })
    # evidence per rule element
    for el in rule_elements[-len(rule["elements"]):]:
        if el["ku_id"]:
            evidence.append(("rule_element", el["rule_element_id"], el["case_id"], el["language"],
                             el["ku_id"], "rule_element_evidence", "04", el["source_row"]))

print("rules:", len(rules_out), "elements:", len(rule_elements), "groups:", len(groups))

# ---------------------------------------------------------------- KU clusters
clusters = OrderedDict()
for key, ku in kus.items():
    h = ku["text_sha256"]
    c = clusters.get(h)
    if c is None:
        c = {"cluster_id": "KUC-%05d" % (len(clusters) + 1), "text_sha256": h,
             "text_length": ku["text_length"], "n_knowledge_units": 0, "cases": set()}
        clusters[h] = c
    c["n_knowledge_units"] += 1
    c["cases"].add(ku["case_id"])
    ku["cluster_id"] = c["cluster_id"]

# ---------------------------------------------------------------- transmission table
tr_rows = []
tr_id_by_key = {}
for p in tr_parts:
    tr_id_by_key.setdefault((p["case_id"], p["transmission_id"]), []).append(p)
for (case_id, tr_id), parts in tr_id_by_key.items():
    roles = Counter(p["role_raw"] for p in parts)
    head = next((p["entity_value"] for p in parts if "头实体" in p["role_raw"]), "")
    tail = next((p["entity_value"] for p in parts if "尾实体" in p["role_raw"]), "")
    meta = tr_meta.get(tr_id, {"attrs": 0, "records": 0})
    graph_ready = bool(head and tail and len(parts) >= 2)
    tr_rows.append({
        "transmission_id": tr_id, "case_id": case_id, "language": parts[0]["language"],
        "n_participants": len(parts), "n_attributes": meta["attrs"],
        "n_relation_records": meta["records"], "head_participant": head,
        "tail_participant": tail, "graph_ready": "true" if graph_ready else "false",
        "role_counts": json.dumps(dict(roles), ensure_ascii=False),
        "source_sheet": "05",
    })
    for i, p in enumerate(parts, 1):
        p["participant_id"] = "%s-P%02d" % (tr_id, i)
        p["graph_ready"] = "true" if graph_ready else "false"
print("transmission instances:", len(tr_rows), "graph_ready:", sum(1 for t in tr_rows if t["graph_ready"] == "true"))

# ids for transmission attributes
for i, a in enumerate(tr_attrs, 1):
    a["transmission_attribute_id"] = "TRA-%05d" % i

# ---------------------------------------------------------------- cases table
cases_out = []
for case_id in sorted(counts, key=lambda c: (c.split("-")[0], int(c.split("-")[1]))):
    lang = case_id.split("-")[0]
    c = counts[case_id]
    p = papers.get(case_id, {})
    n_ent = sum(1 for e in entities.values() if e["case_id"] == case_id)
    n_att = sum(1 for a in attributes if a["case_id"] == case_id)
    n_rel = sum(1 for r in relations if r["case_id"] == case_id)
    n_tr = sum(1 for t in tr_rows if t["case_id"] == case_id)
    n_rules = sum(1 for r in rules_out if r["case_id"] == case_id)
    n_ku = sum(1 for k in kus.values() if k["case_id"] == case_id)
    n_ev = sum(1 for e in evidence if e[2] == case_id)
    cases_out.append({
        "case_id": case_id, "language": lang, "title": p.get("title", ""),
        "n_01": c["01"], "n_02": c["02"], "n_03": c["03"], "n_04": c["04"],
        "n_05": c["05"], "n_06": c["06"], "n_07": c["07"],
        "total_source_rows": sum(c.values()),
        "has_rules": "true" if c["04"] else "false",
        "has_transmission": "true" if (c["05"] or c["06"] or c["07"]) else "false",
        "n_entities": n_ent, "n_attributes": n_att, "n_relations": n_rel,
        "n_transmission": n_tr, "n_rules": n_rules, "n_knowledge_units": n_ku,
        "n_evidence": n_ev,
        "source_workbook_zh": [w for l, _, _, w in LANGS if l == lang][0] + "-中文本体.xlsx",
        "source_workbook_en": [w for l, _, _, w in LANGS if l == lang][0] + "-英文本体.xlsx",
    })
print("cases:", len(cases_out))

# ---------------------------------------------------------------- write CSVs
def write_csv(name, rows, cols):
    p = OUT / name
    with open(p, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols, lineterminator="\n", extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow(r)
    print("  %-34s %8d rows %10d B" % (name, len(rows), p.stat().st_size))
    return p


TABLES = OrderedDict()
TABLES["cases.csv"] = (cases_out, ["case_id", "language", "title", "n_01", "n_02", "n_03", "n_04",
                                   "n_05", "n_06", "n_07", "total_source_rows", "has_rules",
                                   "has_transmission", "n_entities", "n_attributes", "n_relations",
                                   "n_transmission", "n_rules", "n_knowledge_units", "n_evidence",
                                   "source_workbook_zh", "source_workbook_en"])

ent_out = []
for e in entities.values():
    e2 = dict(e)
    e2["identity_status"] = "candidate"
    e2["source_sheet"] = "01"
    ent_out.append(e2)
TABLES["entities.csv"] = (ent_out, ["entity_id", "case_id", "language", "entity_raw",
                                    "class_label_zh", "class_label_en", "class_id", "class_uri",
                                    "n_mentions", "identity_status", "source_sheet",
                                    "first_source_row"])

TABLES["attributes.csv"] = (attributes, ["attribute_id", "case_id", "language", "owner_entity_raw",
                                         "class_label_zh", "class_label_en", "class_uri",
                                         "attribute_label_zh", "attribute_label_en",
                                         "attribute_id_ont", "attribute_uri", "attribute_value",
                                         "value_language", "source_sheet", "source_row"])

TABLES["relations.csv"] = (relations, ["relation_id", "case_id", "language", "head_class_zh",
                                       "head_class_en", "head_class_uri", "head_value",
                                       "relation_raw", "ontology_relation_zh", "ontology_relation_en",
                                       "ontology_relation_id", "ontology_relation_uri",
                                       "tail_class_zh", "tail_class_en", "tail_class_uri",
                                       "tail_value", "source_sheet", "source_row"])

TABLES["transmission.csv"] = (tr_rows, ["transmission_id", "case_id", "language", "n_participants",
                                        "n_attributes", "n_relation_records", "head_participant",
                                        "tail_participant", "graph_ready", "role_counts",
                                        "source_sheet"])

TABLES["transmission_participants.csv"] = (tr_parts, ["participant_id", "transmission_id", "case_id",
                                                      "language", "class_label_zh", "class_label_en",
                                                      "class_uri", "entity_value", "role_raw",
                                                      "role_en", "graph_ready", "source_row"])

TABLES["transmission_attributes.csv"] = (tr_attrs, ["transmission_attribute_id", "transmission_id",
                                                    "case_id", "language", "attribute_label_zh",
                                                    "attribute_label_en", "attribute_value",
                                                    "source_row"])

TABLES["rules.csv"] = (rules_out, ["rule_id", "rule_group_id", "case_id", "language",
                                   "research_case", "title_block", "n_elements", "subject",
                                   "conditions", "result", "authority", "split_status", "ku_id",
                                   "source_rows"])

TABLES["rule_elements.csv"] = (rule_elements, ["rule_element_id", "rule_id", "rule_group_id",
                                               "case_id", "language", "element_order",
                                               "element_raw", "element_category", "content",
                                               "ku_id", "source_sheet", "source_row"])

groups_out = [dict(g, n_rules=g["n_rules"], n_elements=g["n_elements"]) for g in groups.values()]
TABLES["rule_groups.csv"] = (groups_out, ["rule_group_id", "case_id", "language", "title_block",
                                          "n_rules", "n_elements"])

ku_out = []
for k in kus.values():
    ku_out.append({
        "ku_id": k["ku_id"], "case_id": k["case_id"], "language": k["language"],
        "text_length": k["text_length"], "text_sha256": k["text_sha256"],
        "text_mode": "locator_only", "n_occurrences": k["n_occurrences"],
        "source_sheets": json.dumps(sorted(k["sheets"])), "source_rows": json.dumps(k["rows"]),
        "cluster_id": k["cluster_id"],
    })
TABLES["knowledge_units.csv"] = (ku_out, ["ku_id", "case_id", "language", "text_length",
                                          "text_sha256", "text_mode", "n_occurrences",
                                          "source_sheets", "source_rows", "cluster_id"])

cl_out = []
for c in clusters.values():
    cl_out.append({"cluster_id": c["cluster_id"], "text_sha256": c["text_sha256"],
                   "text_length": c["text_length"], "n_knowledge_units": c["n_knowledge_units"],
                   "n_cases": len(c["cases"]), "cases": json.dumps(sorted(c["cases"]))})
TABLES["knowledge_unit_clusters.csv"] = (cl_out, ["cluster_id", "text_sha256", "text_length",
                                                  "n_knowledge_units", "n_cases", "cases"])

ev_out = []
for i, (ftype, fid, case_id, lang, ku_id, role, sheet, row) in enumerate(evidence, 1):
    ev_out.append({"evidence_id": "EVD-%s%05d" % (case_id, i), "fact_type": ftype,
                   "fact_id": fid, "case_id": case_id, "language": lang, "ku_id": ku_id,
                   "evidence_role": role, "source_sheet": sheet, "source_row": row})
TABLES["evidence_references.csv"] = (ev_out, ["evidence_id", "fact_type", "fact_id", "case_id",
                                              "language", "ku_id", "evidence_role",
                                              "source_sheet", "source_row"])

sizes = {}
for name, (rows, cols) in TABLES.items():
    p = write_csv(name, rows, cols)
    sizes[name] = p.stat().st_size

# ---------------------------------------------------------------- data dictionary
DD = [
    ("cases.csv", "case_id", "研究案例编号 CN-001…CN-138 / EN-001…EN-123", "string"),
    ("cases.csv", "n_01…n_07", "该案例在 02 七张表中的原始行数", "integer"),
    ("cases.csv", "total_source_rows", "七张表行数合计", "integer"),
    ("cases.csv", "n_entities…n_evidence", "本数据集中由该案例派生的实体/属性/关系/传播/规则/KU/证据数", "integer"),
    ("entities.csv", "entity_id", "实体候选编号 ENT-<LANG>-<case>-<seq>", "string"),
    ("entities.csv", "entity_raw", "文献中的实体表述（未做全局消歧）", "string"),
    ("entities.csv", "class_label_zh / class_label_en", "本体类的中/英标签（源自 03 术语表）", "string"),
    ("entities.csv", "class_uri", "本体类 URI（urn:dengekg:ontology:class:…），未能匹配时为空", "string"),
    ("entities.csv", "n_mentions", "同一案例内该实体表述的出现次数", "integer"),
    ("entities.csv", "identity_status", "恒为 candidate：未做跨文献实体消歧", "string"),
    ("attributes.csv", "owner_entity_raw", "属性所属实体的原始表述", "string"),
    ("attributes.csv", "attribute_label_zh / _en", "本体属性标签", "string"),
    ("attributes.csv", "attribute_value", "属性取值原文（未做数值归一）", "string"),
    ("relations.csv", "head_value / tail_value", "头/尾实体的原始表述", "string"),
    ("relations.csv", "relation_raw", "标注者抽取的关系表述", "string"),
    ("relations.csv", "ontology_relation_uri", "归一化后的本体语义关系 URI", "string"),
    ("transmission.csv", "transmission_id", "传播关系实例编号（沿用标注表中的 TR-…）", "string"),
    ("transmission.csv", "graph_ready", "头尾参与实体齐备且参与者≥2 时为 true（结构可入图，不代表传播已证实）", "boolean"),
    ("transmission.csv", "role_counts", "各参与角色的计数（JSON）", "json"),
    ("transmission_participants.csv", "role_raw / role_en", "参与者角色（原文角色 / 英译）", "string"),
    ("rules.csv", "rule_id", "规则编号", "string"),
    ("rules.csv", "subject/conditions/result/authority", "按要素类别聚合的规则文本（| 分隔）", "string"),
    ("rule_elements.csv", "element_raw / element_category", "原始要素标签（主体/条件1…）与归一类别（subject/condition/result/authority）", "string"),
    ("knowledge_units.csv", "text_length", "归一化（去空白）后的字符数", "integer"),
    ("knowledge_units.csv", "text_sha256", "归一化文本的 SHA-256，可用于去重与自校验，但不泄露原文", "string"),
    ("knowledge_units.csv", "text_mode", "恒为 locator_only：只发布定位与哈希，不发布原文", "string"),
    ("knowledge_units.csv", "source_sheets / source_rows", "该 KU 出现过的表号与行号（JSON）", "json"),
    ("knowledge_unit_clusters.csv", "cluster_id", "按文本哈希聚类的编号", "string"),
    ("evidence_references.csv", "fact_type / fact_id", "证据指向的事实类型与编号", "string"),
    ("evidence_references.csv", "ku_id", "证据所属知识单元", "string"),
]
with open(OUT / "data_dictionary.csv", "w", encoding="utf-8-sig", newline="") as f:
    w = csv.writer(f, lineterminator="\n")
    w.writerow(["table", "field", "description", "type"])
    for row in DD:
        w.writerow(row)
print("  data_dictionary.csv", (OUT / "data_dictionary.csv").stat().st_size)

# ---------------------------------------------------------------- manifest
def fsha(p):
    h = hashlib.sha256()
    with open(p, "rb") as fh:
        for b in iter(lambda: fh.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


counts_map = {name: len(rows) for name, (rows, _) in TABLES.items()}
manifest = {
    "version": "v1.0",
    "derived_from": "DRC-KG/02_分类标注成果 (4 aggregation workbooks)",
    "generated": "2026-11-04",
    "mode": "locator_only",
    "release_ready": False,
    "published": False,
    "counts": counts_map,
    "table_hashes": {name: fsha(OUT / name) for name in TABLES},
    "ontology_terms_mapped": {"total_terms": len(terms),
                              "unmapped_labels": {("%s:%s" % k): v for k, v in list(unmapped.items())[:200]},
                              "unmapped_label_kinds": dict(Counter(k[0] for k in unmapped))},
    "derivation_rules": {
        "entity": "按 (case_id, 实体表述, 本体类) 去重，n_mentions 记出现次数",
        "attribute": "逐行保留（不聚合），每行一条属性事实",
        "relation": "逐行保留；本体关系由 03_统一本体/ontology_term_map.csv 归一",
        "transmission": "按标注表中的 TR 实例编号聚合参与者与属性；graph_ready 为结构判据",
        "rule": "按 (case_id, 标题块, 知识单元) 聚合规则，要素按 主体/条件/结果/依据 归类",
        "knowledge_unit": "按 (case_id, 归一化文本 SHA-256) 去重；原文不发布",
        "evidence": "每个带原文的标注行生成一条证据，指向其 KU",
    },
    "limits": [
        "不含任何第三方原文：知识单元只发布归一化文本的 SHA-256 与长度，不发布文本本身",
        "实体未做跨文献消歧，全部为 candidate",
        "传播实例为作者主张的关联，graph_ready 仅表示结构完整（头尾参与者齐备）",
    ],
}
(OUT / "release_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2),
                                          encoding="utf-8")
print("  release_manifest.json", (OUT / "release_manifest.json").stat().st_size)
print("DONE")
