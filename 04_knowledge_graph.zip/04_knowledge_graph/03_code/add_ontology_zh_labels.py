# -*- coding: utf-8 -*-
"""Add a Chinese `rdfs:label` to every term of the released ontology.

Before this fix the ontology carried
    rdfs:label   "Aedes aegypti"@en
    rdfs:comment "中文名称：埃及伊蚊 …"@zh
i.e. the Chinese name only lived *inside* a comment string, so any label-based lookup
returned nothing in Chinese.  This script copies the name after `中文名称：` into a real
`rdfs:label @zh` / `<rdfs:label xml:lang="zh">` triple, immediately after the English
label, and leaves every other triple untouched.

Run:  python -X utf8 04_knowledge_graph/03_code/add_ontology_zh_labels.py
"""
import re
import sys
from pathlib import Path
from xml.sax.saxutils import escape

sys.stdout.reconfigure(encoding="utf-8")

ROOT = Path(__file__).resolve().parents[2]
ONTO = ROOT / "03_ontology"
TTL = ONTO / "Dengue_Research_Case_Ontology.ttl"
OWL = ONTO / "Dengue_Research_Case_Ontology.owl"

NAME_RE = re.compile(r'中文名称：([^\n\r"]+)')
TTL_LABEL_LINE = re.compile(r'(?P<indent>[ \t]*)rdfs:label[ \t]+"(?P<en>(?:[^"\\]|\\.)*)"@en[ \t]*;')
TTL_ZH_COMMENT = re.compile(r'rdfs:comment[ \t]+"""(?P<comment>.*?)"""@zh', re.S)
OWL_BLOCK = re.compile(r"<rdf:Description\b.*?</rdf:Description>", re.S)
OWL_EN_LABEL = re.compile(
    r'(?P<line>(?P<indent>[ \t]*)<rdfs:label xml:lang="en">.*?</rdfs:label>[ \t]*\r?\n)')
OWL_ZH_COMMENT = re.compile(r'<rdfs:comment xml:lang="zh">(?P<comment>.*?)</rdfs:comment>', re.S)


def chinese_name(comment):
    m = NAME_RE.search(comment)
    if not m:
        return None, "no 中文名称 line"
    name = m.group(1).strip()
    if not name:
        return None, "empty Chinese name"
    if '"' in name or "\n" in name or "\r" in name:
        return None, "unsupported characters in Chinese name: %r" % name
    return name, None


def fix_ttl(text):
    blocks = text.split("\n\n")
    added = 0
    out = []
    for part in blocks:
        en = TTL_LABEL_LINE.search(part)
        if not en:
            out.append(part)
            continue
        zh = TTL_ZH_COMMENT.search(part)
        # zh comments appear both as a standalone """…"""@zh and as the second item of a
        # comma-separated rdfs:comment list; the 中文名称： line identifies them either way.
        name, err = chinese_name(zh.group("comment") if zh else part)
        if err:
            raise SystemExit("TTL %r: %s" % (en.group("en"), err))
        indent = en.group("indent")
        ins = '\n%srdfs:label "%s"@zh ;' % (indent, name.replace("\\", "\\\\"))
        out.append(part[:en.end()] + ins + part[en.end():])
        added += 1
    return "\n\n".join(out), added


def fix_owl(text):
    added = 0

    def one(m):
        nonlocal added
        block = m.group(0)
        zh = OWL_ZH_COMMENT.search(block)
        en = OWL_EN_LABEL.search(block)
        if not zh or not en:
            return block
        name, err = chinese_name(zh.group("comment"))
        if err:
            raise SystemExit("OWL block: %s" % err)
        ins = '%s<rdfs:label xml:lang="zh">%s</rdfs:label>\n' % (en.group("indent"), escape(name))
        added += 1
        return block[:en.end()] + ins + block[en.end():]

    return OWL_BLOCK.sub(one, text), added


def main():
    ttl_text = TTL.read_text(encoding="utf-8")
    new_ttl, n_ttl = fix_ttl(ttl_text)
    owl_text = OWL.read_text(encoding="utf-8")
    new_owl, n_owl = fix_owl(owl_text)
    ttl_terms = len(re.findall(r"中文名称：", ttl_text))
    owl_terms = len(re.findall(r"中文名称：", owl_text))
    if n_ttl != ttl_terms or n_owl != owl_terms:
        raise SystemExit("incomplete: ttl %d/%d owl %d/%d" % (n_ttl, ttl_terms, n_owl, owl_terms))
    TTL.write_text(new_ttl, encoding="utf-8")
    OWL.write_text(new_owl, encoding="utf-8")
    print("TTL Chinese labels added: %d / %d" % (n_ttl, ttl_terms))
    print("OWL Chinese labels added: %d / %d" % (n_owl, owl_terms))


if __name__ == "__main__":
    main()
