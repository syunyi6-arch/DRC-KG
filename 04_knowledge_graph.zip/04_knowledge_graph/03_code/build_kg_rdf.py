# -*- coding: utf-8 -*-
"""Build the RDF instance graph from 04_knowledge_graph/01_standardized_data/.

Outputs (04_knowledge_graph/02_rdf_graph/):
  instance_vocab.ttl      词汇定义（13 类 / 对象属性 / 数据类型属性）
  instances.ttl           全量实例三元组（Turtle）
  instances.nt            全量实例三元组（N-Triples，供批量导入）
  graph_sample.ttl        CN-001…003 子集（Turtle）
  graph_sample.jsonld     同一子集的 JSON-LD 1.1（与 ttl 严格等价）
  graph_build_manifest.json
"""
import csv
import hashlib
import json
import sys
from collections import OrderedDict
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")

ROOT = Path(r"D:\sc成果")
Z = ROOT / "DRC-KG"
T = Z / "04_knowledge_graph" / "01_standardized_data"
OUT = Z / "04_knowledge_graph" / "02_rdf_graph"
OUT.mkdir(parents=True, exist_ok=True)
STD_MANIFEST = json.loads((T / "release_manifest.json").read_text(encoding="utf-8"))

G = "urn:dengekg:graph:"
I = "urn:dengekg:instance:"
RDF_TYPE = "http://www.w3.org/1999/02/22-rdf-syntax-ns#type"
SAMPLE = {"CN-001", "CN-002", "CN-003"}


def rd(name):
    with open(T / name, encoding="utf-8-sig", newline="") as f:
        for r in csv.DictReader(f):
            yield r


def esc(s):
    if s is None:
        return ""
    return str(s).replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n").replace("\r", "\\r")


class Writer:
    def __init__(self, ttl_path, nt_path):
        self.ttl = open(ttl_path, "w", encoding="utf-8", newline="\n")
        self.nt = open(nt_path, "w", encoding="utf-8", newline="\n")
        self.ttl.write("@prefix dkgi: <urn:dengekg:instance:> .\n"
                       "@prefix dkgv: <urn:dengekg:graph:> .\n"
                       "@prefix dkg: <urn:dengekg:ontology:> .\n"
                       "@prefix xsd: <http://www.w3.org/2001/XMLSchema#> .\n\n")
        self.n = 0
        self.sample = []      # (subject_uri, pred_local, obj_kind, obj_value)
        self.case_of = {}     # subject_uri -> case_id (for sample filtering)

    def block(self, subj, rdf_type, props, case_id=None):
        """props: list of (pred_local, kind, value) where kind in iri|lit|int|bool"""
        s = I + subj
        if case_id in SAMPLE:
            self.sample.append((subj, "type", "iri", G + rdf_type))
        self.ttl.write("dkgi:%s a dkgv:%s" % (subj, rdf_type))
        self.nt.write("<%s%s> <%s> <%s%s> .\n" % (I, subj, RDF_TYPE, G, rdf_type))
        self.n += 1
        for pred, kind, val in props:
            if val is None or val == "":
                continue
            if kind == "iri":
                self.ttl.write(" ;\n    dkgv:%s <%s>" % (pred, val))
                self.nt.write("<%s%s> <%s%s> <%s> .\n" % (I, subj, G, pred, val))
            elif kind == "int":
                self.ttl.write(" ;\n    dkgv:%s %d" % (pred, int(val)))
                self.nt.write('<%s%s> <%s%s> "%d"^^<http://www.w3.org/2001/XMLSchema#integer> .\n'
                              % (I, subj, G, pred, int(val)))
            else:
                self.ttl.write(' ;\n    dkgv:%s "%s"' % (pred, esc(val)))
                self.nt.write('<%s%s> <%s%s> "%s" .\n' % (I, subj, G, pred, esc(val)))
            if case_id in SAMPLE:
                self.sample.append((subj, pred, kind, val))
            self.n += 1
        self.ttl.write(" .\n\n")

    def close(self):
        self.ttl.close()
        self.nt.close()


W = Writer(OUT / "instances.ttl", OUT / "instances.nt")

# ---------------------------------------------------------------- cases
for c in rd("cases.csv"):
    W.block("CASE-%s" % c["case_id"], "ResearchCase", [
        ("caseId", "lit", c["case_id"]),
        ("language", "lit", c["language"]),
        ("title", "lit", c["title"]),
        ("totalSourceRows", "int", c["total_source_rows"]),
        ("hasRules", "lit", c["has_rules"]),
        ("hasTransmission", "lit", c["has_transmission"]),
        ("nRules", "int", c["n_rules"]),
        ("nKnowledgeUnits", "int", c["n_knowledge_units"]),
        ("sourceWorkbook", "lit", c["source_workbook_zh"]),
        ("nIncrementRows", "int", c["n_increment_rows"]),
    ] + [("sourceFile", "lit", f) for f in json.loads(c["source_files"] or "[]")], c["case_id"])

# ---------------------------------------------------------------- entities
for e in rd("entities.csv"):
    W.block(e["entity_id"], "CandidateEntity", [
        ("inCase", "iri", I + "CASE-" + e["case_id"]),
        ("entityName", "lit", e["entity_raw"]),
        ("candidateClass", "iri", e["class_uri"]),
        ("ontologyClassLabel", "lit", e["class_label_en"]),
        ("classLabelZh", "lit", e["class_label_zh"]),
        ("nMentions", "int", e["n_mentions"]),
        ("identityStatus", "lit", e["identity_status"]),
        ("sourceTable", "lit", e["source_sheet"]),
        ("sourceBatches", "lit", e["source_batches"]),
    ], e["case_id"])

# ---------------------------------------------------------------- attributes
for a in rd("attributes.csv"):
    W.block(a["attribute_id"], "AttributeAssertion", [
        ("inCase", "iri", I + "CASE-" + a["case_id"]),
        ("attributeOfRaw", "lit", a["owner_entity_raw"]),
        ("attributeClass", "iri", a["class_uri"]),
        ("attributeType", "iri", a["attribute_uri"]),
        ("attributeTypeLabel", "lit", a["attribute_label_en"]),
        ("attributeTypeLabelZh", "lit", a["attribute_label_zh"]),
        ("attributeValue", "lit", a["attribute_value"]),
        ("valueLanguage", "lit", a["value_language"]),
        ("sourceTable", "lit", a["source_sheet"]),
        ("sourceRow", "int", a["source_row"]),
        ("sourceFile", "lit", a["source_file"]),
        ("sourceBatch", "lit", a["source_batch"]),
    ], a["case_id"])

# ---------------------------------------------------------------- relations
for r in rd("relations.csv"):
    W.block(r["relation_id"], "RelationAssertion", [
        ("inCase", "iri", I + "CASE-" + r["case_id"]),
        ("headClass", "iri", r["head_class_uri"]),
        ("headRaw", "lit", r["head_value"]),
        ("originalPredicate", "lit", r["relation_raw"]),
        ("ontologyPredicate", "iri", r["ontology_relation_uri"]),
        ("ontologyRelationLabel", "lit", r["ontology_relation_en"]),
        ("ontologyRelationLabelZh", "lit", r["ontology_relation_zh"]),
        ("tailClass", "iri", r["tail_class_uri"]),
        ("tailRaw", "lit", r["tail_value"]),
        ("sourceTable", "lit", r["source_sheet"]),
        ("sourceRow", "int", r["source_row"]),
        ("sourceFile", "lit", r["source_file"]),
        ("sourceBatch", "lit", r["source_batch"]),
    ], r["case_id"])

# ---------------------------------------------------------------- transmission
for t in rd("transmission.csv"):
    W.block(t["transmission_id"], "TransmissionAssertion", [
        ("inCase", "iri", I + "CASE-" + t["case_id"]),
        ("nParticipants", "int", t["n_participants"]),
        ("nAttributeRecords", "int", t["n_attributes"]),
        ("nRelationRecords", "int", t["n_relation_records"]),
        ("headRaw", "lit", t["head_participant"]),
        ("tailRaw", "lit", t["tail_participant"]),
        ("graphReady", "lit", t["graph_ready"]),
        ("roleCounts", "lit", t["role_counts"]),
    ], t["case_id"])

for p in rd("transmission_participants.csv"):
    W.block(p["participant_id"], "TransmissionParticipant", [
        ("participatesIn", "iri", I + p["transmission_id"]),
        ("inCase", "iri", I + "CASE-" + p["case_id"]),
        ("participantClass", "iri", p["class_uri"]),
        ("participantEntity", "lit", p["entity_value"]),
        ("roleOriginal", "lit", p["role_raw"]),
        ("roleEnglish", "lit", p["role_en"]),
        ("graphReady", "lit", p["graph_ready"]),
        ("sourceRow", "int", p["source_row"]),
    ], p["case_id"])

for a in rd("transmission_attributes.csv"):
    W.block(a["transmission_attribute_id"], "TransmissionAttributeAssertion", [
        ("transmissionAttributeOf", "iri", I + a["transmission_id"]),
        ("inCase", "iri", I + "CASE-" + a["case_id"]),
        ("attributeTypeLabel", "lit", a["attribute_label_en"]),
        ("attributeTypeLabelZh", "lit", a["attribute_label_zh"]),
        ("attributeValue", "lit", a["attribute_value"]),
        ("sourceRow", "int", a["source_row"]),
    ], a["case_id"])

# ---------------------------------------------------------------- rules
for g in rd("rule_groups.csv"):
    W.block(g["rule_group_id"], "RuleGroup", [
        ("inCase", "iri", I + "CASE-" + g["case_id"]),
        ("titleBlock", "lit", g["title_block"]),
        ("nRules", "int", g["n_rules"]),
        ("nElements", "int", g["n_elements"]),
    ], g["case_id"])

for r in rd("rules.csv"):
    W.block(r["rule_id"], "RuleAssertion", [
        ("inCase", "iri", I + "CASE-" + r["case_id"]),
        ("ruleGroup", "iri", I + r["rule_group_id"]),
        ("researchCase", "lit", r["research_case"]),
        ("titleBlock", "lit", r["title_block"]),
        ("nElements", "int", r["n_elements"]),
        ("ruleSubject", "lit", r["subject"]),
        ("ruleConditions", "lit", r["conditions"]),
        ("ruleResult", "lit", r["result"]),
        ("ruleAuthority", "lit", r["authority"]),
        ("splitStatus", "lit", r["split_status"]),
        ("inKnowledgeUnit", "iri", I + r["ku_id"]),
    ], r["case_id"])

for el in rd("rule_elements.csv"):
    W.block(el["rule_element_id"], "RuleElement", [
        ("elementOfRule", "iri", I + el["rule_id"]),
        ("inCase", "iri", I + "CASE-" + el["case_id"]),
        ("elementOrder", "int", el["element_order"]),
        ("elementCategory", "lit", el["element_category"]),
        ("elementOriginal", "lit", el["element_raw"]),
        ("elementContent", "lit", el["content"]),
        ("inKnowledgeUnit", "iri", I + el["ku_id"]),
        ("sourceRow", "int", el["source_row"]),
        ("sourceFile", "lit", el["source_file"]),
        ("sourceBatch", "lit", el["source_batch"]),
    ], el["case_id"])

# ---------------------------------------------------------------- knowledge units & clusters
for c in rd("knowledge_unit_clusters.csv"):
    W.block(c["cluster_id"], "KnowledgeUnitCluster", [
        ("textSha256", "lit", c["text_sha256"]),
        ("textLength", "int", c["text_length"]),
        ("nParticipants", "int", c["n_knowledge_units"]),
        ("nCases", "int", c["n_cases"]),
    ])

for k in rd("knowledge_units.csv"):
    W.block(k["ku_id"], "KnowledgeUnit", [
        ("inCase", "iri", I + "CASE-" + k["case_id"]),
        ("inCluster", "iri", I + k["cluster_id"]),
        ("textMode", "lit", k["text_mode"]),
        ("textLength", "int", k["text_length"]),
        ("textSha256", "lit", k["text_sha256"]),
        ("nOccurrences", "int", k["n_occurrences"]),
        ("sourceSheets", "lit", k["source_sheets"]),
        ("sourceBatches", "lit", k["source_batches"]),
    ], k["case_id"])

# ---------------------------------------------------------------- evidence
for ev in rd("evidence_references.csv"):
    W.block(ev["evidence_id"], "EvidenceReference", [
        ("inCase", "iri", I + "CASE-" + ev["case_id"]),
        ("evidenceOf", "iri", I + ev["fact_id"]),
        ("inKnowledgeUnit", "iri", I + ev["ku_id"]),
        ("factType", "lit", ev["fact_type"]),
        ("evidenceRole", "lit", ev["evidence_role"]),
        ("sourceTable", "lit", ev["source_sheet"]),
        ("sourceRow", "int", ev["source_row"]),
        ("sourceFile", "lit", ev["source_file"]),
        ("sourceBatch", "lit", ev["source_batch"]),
    ], ev["case_id"])

W.close()
print("triples:", W.n)

# ---------------------------------------------------------------- vocabulary
CLASSES = ["ResearchCase", "CandidateEntity", "AttributeAssertion", "RelationAssertion",
           "TransmissionAssertion", "TransmissionParticipant", "TransmissionAttributeAssertion",
           "RuleAssertion", "RuleElement", "RuleGroup", "KnowledgeUnit", "KnowledgeUnitCluster",
           "EvidenceReference"]
OBJ = ["inCase", "candidateClass", "attributeClass", "attributeType", "headClass", "tailClass",
       "ontologyPredicate", "participatesIn", "transmissionAttributeOf", "elementOfRule",
       "ruleGroup", "inKnowledgeUnit", "inCluster", "evidenceOf"]
LIT = ["caseId", "language", "title", "entityName", "ontologyClassLabel", "classLabelZh",
       "nMentions", "identityStatus", "sourceTable", "sourceRow", "attributeOfRaw",
       "attributeTypeLabel", "attributeTypeLabelZh", "attributeValue", "valueLanguage",
       "headRaw", "tailRaw", "originalPredicate", "ontologyRelationLabel",
       "ontologyRelationLabelZh", "nParticipants", "nAttributeRecords", "nRelationRecords",
       "graphReady", "roleCounts", "participantClass", "participantEntity", "roleOriginal",
       "roleEnglish",
       "researchCase", "titleBlock", "nElements", "nRules", "ruleSubject", "ruleConditions",
       "ruleResult", "ruleAuthority", "splitStatus", "elementOrder", "elementCategory",
       "elementOriginal", "elementContent", "textMode", "textLength", "textSha256",
       "nOccurrences", "sourceSheets", "nCases", "factType", "evidenceRole",
       "totalSourceRows", "hasRules", "hasTransmission", "nKnowledgeUnits", "sourceWorkbook",
       "nIncrementRows", "sourceFile", "sourceBatches", "sourceBatch"]
v = ["@prefix dkgv: <urn:dengekg:graph:> .",
     "@prefix owl: <http://www.w3.org/2002/07/owl#> .",
     "@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .",
     "@prefix xsd: <http://www.w3.org/2001/XMLSchema#> .",
     "@prefix dcterms: <http://purl.org/dc/terms/> .", "",
     "dkgv: a owl:Ontology ;",
     '    dcterms:title "DRC-KG instance graph vocabulary"@en ;',
     '    dcterms:description "Meta-vocabulary for evidence-bearing assertion nodes; derived from the 02 annotation tables. Domain terms stay in urn:dengekg:ontology:."@en ;',
     '    owl:versionInfo "1.0" .', ""]
for c in CLASSES:
    v.append("dkgv:%s a owl:Class ." % c)
v.append("")
for p in OBJ:
    v.append("dkgv:%s a owl:ObjectProperty ." % p)
v.append("")
for p in LIT:
    v.append("dkgv:%s a owl:DatatypeProperty ." % p)
(OUT / "instance_vocab.ttl").write_text("\n".join(v) + "\n", encoding="utf-8")
print("vocab terms:", len(CLASSES), len(OBJ), len(LIT))

# ---------------------------------------------------------------- sample (ttl + jsonld)
sample = W.sample
nodes = OrderedDict()
for subj, pred, kind, val in sample:
    nd = nodes.setdefault(subj, {"@id": I + subj, "props": []})
    nd["props"].append((pred, kind, val))

CTX = {"dkgv": G, "dkgi": I, "dkg": "urn:dengekg:ontology:",
       "xsd": "http://www.w3.org/2001/XMLSchema#"}
ttl = ["@prefix dkgi: <urn:dengekg:instance:> .",
       "@prefix dkgv: <urn:dengekg:graph:> .",
       "@prefix dkg: <urn:dengekg:ontology:> .", ""]
for subj, nd in nodes.items():
    types = [val for p, k, val in nd["props"] if p == "type"]
    rest = [(p, k, val) for p, k, val in nd["props"] if p != "type"]
    head = "dkgi:%s a %s" % (subj, ", ".join("dkgv:" + t.split(":")[-1] for t in types))
    parts = [head]
    for p, k, val in rest:
        if k == "iri":
            parts.append("    dkgv:%s <%s>" % (p, val))
        elif k == "int":
            parts.append("    dkgv:%s %d" % (p, int(val)))
        else:
            parts.append('    dkgv:%s "%s"' % (p, esc(val)))
    ttl.append(" ;\n".join(parts) + " .\n")
(OUT / "graph_sample.ttl").write_text("\n".join(ttl) + "\n", encoding="utf-8")

jgraph = []
for subj, nd in nodes.items():
    node = {"@id": I + subj}
    types = [val for p, k, val in nd["props"] if p == "type"]
    if types:
        node["@type"] = ["dkgv:" + t.split(":")[-1] for t in types]
    for p, k, val in nd["props"]:
        if p == "type":
            continue
        item = ({"@id": val} if k == "iri" else val)
        key = "dkgv:" + p
        if key in node:
            if not isinstance(node[key], list):
                node[key] = [node[key]]
            node[key].append(item)
        else:
            node[key] = item
    jgraph.append(node)
jsonld = {"@context": CTX, "@graph": jgraph}
(OUT / "graph_sample.jsonld").write_text(json.dumps(jsonld, ensure_ascii=False, indent=1),
                                         encoding="utf-8")
print("sample nodes:", len(jgraph), "sample statements:", len(sample))

# ---------------------------------------------------------------- manifest
def fsha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


counts = {}
for name in ("cases.csv", "entities.csv", "attributes.csv", "relations.csv", "transmission.csv",
             "transmission_participants.csv", "transmission_attributes.csv", "rules.csv",
             "rule_elements.csv", "rule_groups.csv", "knowledge_units.csv",
             "knowledge_unit_clusters.csv", "evidence_references.csv"):
    with open(T / name, encoding="utf-8-sig", newline="") as f:
        counts[name] = max(0, sum(1 for _ in f) - 1)

man = {
    "version": "1.0",
    "generated": "2026-11-20",
    "increment": STD_MANIFEST.get("increment", {}),
    "source_tables": "04_knowledge_graph/01_standardized_data",
    "source_annotation": "02_annotations",
    "mode": "locator_only",
    "namespace": {"instance": I, "graph": G, "ontology": "urn:dengekg:ontology:"},
    "counts": counts,
    "triples": W.n,
    "sample": {"cases": sorted(SAMPLE), "nodes": len(jgraph), "statements": len(sample)},
    "files": {f.name: {"bytes": f.stat().st_size, "sha256": fsha(f)}
              for f in (OUT / "instances.ttl", OUT / "instances.nt", OUT / "instance_vocab.ttl",
                        OUT / "graph_sample.ttl", OUT / "graph_sample.jsonld")},
}
(OUT / "graph_build_manifest.json").write_text(json.dumps(man, ensure_ascii=False, indent=2),
                                               encoding="utf-8")
print("instances.ttl", (OUT / "instances.ttl").stat().st_size)
print("instances.nt", (OUT / "instances.nt").stat().st_size)
print("DONE")
