# Knowledge Graph

This folder holds the standardized data tables and the RDF serialization of
**DRC-KG (Dengue Research Case Knowledge Graph)**, each in its own subfolder:

```
04_knowledge_graph/
├── 01_standardized_data/   12 structured tables + 2 auxiliary tables + data dictionary + release manifest (15 files)
├── 02_rdf_graph/           instance vocabulary + full Turtle + full N-Triples + subset examples + build manifest (6 files)
├── 03_code/                scripts that generate the two artefacts above (reproducible)
└── README.md
```

Both artefacts are derived from the four aggregation workbooks in `../02_annotations/`:

```
02_annotations/CN_138_classification_tables_ontology-zh.xlsx ┐
02_annotations/CN_138_classification_tables_ontology-en.xlsx ┤→ 01_standardized_data/ → 02_rdf_graph/
02_annotations/EN_123_classification_tables_ontology-zh.xlsx ┤
02_annotations/EN_123_classification_tables_ontology-en.xlsx ┘
```

The 149-row increment batch is merged into the same four workbooks: the two `-zh` workbooks carry a trailing
`批次` column (`increment_1115` on those rows, blank for the main annotation batch) and a `批次行号` column with
each row's number inside its own batch, so every count below rebuilds from these four files alone.

Chinese labels and the annotation content come from the `ontology-zh` workbooks; English labels come from the
`ontology-en` workbooks (the two variants are row-aligned; 90,103 + 53,022 cell values were compared and match
exactly). The merged increment rows carry Chinese columns only, so their English labels are the canonical terms
of the human-reviewed term mapping — sheet `统一术语映射` of `../03_ontology/ontology_bilingual.xlsx` (467 terms,
`Missing canonical translations = 0`), mirrored into the `-en` workbooks. `build_kg_tables.py` asserts that
`../03_ontology/ontology_term_map.csv`
equals that sheet (467/467) and takes **every** English class / attribute / relation label from it, with the
`-en` annotation workbooks kept as a cross-check only: 386,606 labels, **0 drift**, 0 unmapped, recorded as
`label_provenance` in the release manifest. Ontology classes, attributes and relations are resolved to stable
IDs and URIs through the same term map, with a **100% label match rate**.

---

## 1. Scale

| Item | Count |
|---|---:|
| Research cases | **261** (Chinese 138 / English 123) |
| Annotation rows | **216,442** (01: 90,176 · 02: 66,670 · 03: 53,024 · 04: 948 · 05: 1,776 · 06: 2,242 · 07: 1,606) — of which **149** come from `increment_1115` |
| Entity candidates | **72,147** (32 only from the increment batch) |
| Attribute facts | **66,670** |
| Relation statements | **53,024** |
| Transmission instances / participants / attribute records | **625 / 1,776 / 2,242** (`graph_ready` 494) |
| Rules / rule elements / rule groups | **250 / 948 / 166** |
| Knowledge units / clusters | **41,342 / 41,285** |
| Evidence references | **216,442** (= annotation rows) |
| RDF triples / subjects | **5,127,002 / 497,178** |

RDF node counts match the table row counts one to one: 261 cases, 72,147 entities, 66,670 attribute assertions,
53,024 relation assertions, 625 transmission assertions, 1,776 participants, 2,242 transmission attributes,
166 rule groups, 250 rules, 948 rule elements, 41,285 clusters, 41,342 knowledge units, 216,442 evidence nodes.

---

## 2. `01_standardized_data/` (15 files)

| File | Rows | Content |
|---|---:|---|
| `cases.csv` | 261 | case master table: title, per-sheet row counts, derived counts, `source_files`, `n_increment_rows` |
| `entities.csv` | 72,147 | deduplicated by (case, entity string, ontology class); `n_mentions` keeps the mention count, `source_batches` the batches it was seen in |
| `attributes.csv` | 66,670 | attribute facts, one row per annotation row (no aggregation) |
| `relations.csv` | 53,024 | relation statements incl. the normalized ontology relation URI |
| `transmission.csv` | 625 | aggregated by the TR instance IDs of the annotation tables; `graph_ready` is a structural criterion |
| `transmission_participants.csv` | 1,776 | transmission participants and their roles |
| `transmission_attributes.csv` | 2,242 | attribute records of transmission instances |
| `rules.csv` | 250 | rule master table (subject / conditions / result / authority, `\|`-joined) |
| `rule_elements.csv` | 948 | rule elements, one row each |
| `rule_groups.csv` | 166 | rule groups by (case, title block) |
| `knowledge_units.csv` | 41,342 | deduplicated by (case, normalized-text SHA-256); `source_rows` entries read `<batch>/<sheet>/<row>` |
| `knowledge_unit_clusters.csv` | 41,285 | cross-case clusters by text hash |
| `evidence_references.csv` | 216,442 | one evidence row per annotation row that carries a source sentence, pointing at its knowledge unit |
| `data_dictionary.csv` | 44 | field-by-field documentation |
| `release_manifest.json` | — | counts, SHA-256 of the 13 tables, the increment block, derivation rules and limits |

---

## 3. `02_rdf_graph/` (6 files)

| File | Size | Content |
|---|---:|---|
| `instance_vocab.ttl` | 4,231 B | vocabulary: 13 classes, 14 object properties, 59 datatype properties |
| `instances.ttl` | 258,591,051 B | full graph in Turtle (**5,127,002** triples) |
| `instances.nt` | 558,272,803 B | same graph in N-Triples (unsorted; for Blazegraph / Virtuoso / rdflib bulk loads) |
| `graph_sample.ttl` | 2,097,347 B | CN-001…CN-003 subset (3,883 nodes / 41,909 statements) |
| `graph_sample.jsonld` | 2,608,474 B | the same subset as JSON-LD 1.1, strictly equivalent to the Turtle file |
| `graph_build_manifest.json` | — | triple count, namespaces, increment block, per-file SHA-256 |

Namespaces: instances `urn:dengekg:instance:`, vocabulary `urn:dengekg:graph:`, ontology `urn:dengekg:ontology:`.

The graph carries the provenance datatype properties `sourceBatch`, `sourceBatches`, `sourceFile` and
`nIncrementRows`, so the batch a fact came from is queryable in SPARQL as well.

```python
import rdflib
g = rdflib.Graph()
g.parse("04_knowledge_graph/02_rdf_graph/graph_sample.ttl", format="turtle")
print(len(g))                     # 41,909
```

---

## 4. Boundaries

1. **Only locators and hashes are published**: knowledge units carry no source text, only the SHA-256 of the
   normalized text plus its length (usable for deduplication and self-checking, without disclosing the text).
2. **Entities are not disambiguated**: all are `candidate`; identical strings across papers are not merged.
3. **Transmission instances are author claims**: `graph_ready=true` only means the head and tail participants are
   both present; it does **not** mean the transmission is confirmed.
4. Rule element text is published as structured rules rather than narrative source text.
5. **The 149 increment rows carry single-annotator Chinese labels**; their English labels are the reviewed
   canonical terms (see above). Use `source_batch` to subset them out of any evaluation that requires double
   annotation.

---

## 5. Reproduction

```bash
python 04_knowledge_graph/03_code/build_kg_tables.py    # 02_annotations -> 01_standardized_data/  (~3 min)
python 04_knowledge_graph/03_code/build_kg_rdf.py       # 01_standardized_data -> 02_rdf_graph/  (~5 min, 247 MB + 532 MB)
python 04_knowledge_graph/03_code/build_papers_table.py # 01_standardized_data/cases.csv -> ../01_source_literature/
```

Verification: `01_standardized_data/release_manifest.json` and `02_rdf_graph/graph_build_manifest.json` both
record a per-file SHA-256, and `build_kg_tables.py` fails hard if the evidence count ever stops matching the
annotation row count.
