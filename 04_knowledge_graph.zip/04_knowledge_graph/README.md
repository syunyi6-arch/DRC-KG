# Knowledge Graph

This folder holds the standardized data tables and the RDF serialization of
**DRC-KG (Dengue Research Case Knowledge Graph)**, each in its own subfolder:

```
04_knowledge_graph/
├── 01_standardized_data/   12 structured tables + 2 auxiliary tables + data dictionary + release manifest (15 files)
├── 02_rdf_graph/           instance vocabulary + full Turtle + full N-Triples + subset examples + build manifest (6 files)
├── 03_code/                scripts that generate the two artefacts above (reproducible)
└── README.md
```

Both artefacts are derived from the four aggregation workbooks in `../02_annotations/`:

```
02_annotations/CN_138_classification_tables_ontology-zh.xlsx ┐
02_annotations/CN_138_classification_tables_ontology-en.xlsx ┤→ 01_standardized_data/ → 02_rdf_graph/
02_annotations/EN_123_classification_tables_ontology-zh.xlsx ┤
02_annotations/EN_123_classification_tables_ontology-en.xlsx ┘
```

The 149-row increment batch is merged into the same four workbooks: the two `-zh` workbooks
carry a trailing batch column (`increment_1115` on those rows, blank for the main annotation
batch) and a batch row-number column with each row's number inside its own batch, so every
count below rebuilds from these four files alone.

Chinese labels and the annotation content come from the `ontology-zh` workbooks; English labels come from the
`ontology-en` workbooks (the two variants are row-aligned; 90,103 + 53,022 cell values were compared and match
exactly). The merged increment rows carry Chinese columns only, so their English labels are the canonical terms
of the human-reviewed term mapping — the reviewed term-map sheet of `../03_ontology/ontology_bilingual.xlsx` (467 terms,
`Missing canonical translations = 0`), mirrored into the `-en` workbooks. `build_kg_tables.py` asserts that
`../03_ontology/ontology_term_map.csv`
equals that sheet (467/467) and takes **every** English class / attribute / relation label from it, with the
`-en` annotation workbooks kept as a cross-check only: 382,351 labels, **0 drift**, 0 unmapped, recorded as
`label_provenance` in the release manifest. Ontology classes, attributes and relations are resolved to stable
IDs and URIs through the same term map, with a **100% label match rate**.

Language convention of the tables: column headers, field names and status enums (`candidate`, `locator_only`,
`auto_single`, `true` / `false`) are English; the annotation content (`entity_raw`, `relation_raw`,
`attribute_value`, rule text) stays in the language of the source article; and every ontology label column is
bilingual (`*_zh` / `*_en`). Participant roles follow the same split: the Chinese annotation text stays in
`role_raw`, and `role_en` is its English rendering from the reviewed map
`03_code/role_en_map.json` (137 distinct roles over 1,628 rows). `build_kg_tables.py` fails if a Chinese role has
no English mapping or if any `role_en` cell still contains Chinese, so the column cannot silently regress.

---

## 1. Scale

| Item | Count |
|---|---:|
| Research cases | **261** (Chinese 138 / English 123) |
| Annotation rows | **213,851** (01: 89,020 · 02: 65,474 · 03: 52,790 · 04: 948 · 05: 1,776 · 06: 2,237 · 07: 1,606) — of which **149** come from `increment_1115` |
| Entity candidates | **72,163** (39 only from the increment batch) |
| Attribute facts | **65,474** |
| Relation statements | **52,790** |
| Transmission instances / participants / attribute records | **625 / 1,776 / 2,237** (`graph_ready` 494) |
| Rules / rule elements / rule groups | **250 / 948 / 166** |
| Knowledge units / clusters | **41,342 / 41,285** |
| Evidence references | **213,851** (= annotation rows) |
| RDF triples / subjects | **5,082,372 / 493,168** |

RDF node counts match the table row counts one to one: 261 cases, 72,163 entities, 65,474 attribute assertions,
52,790 relation assertions, 625 transmission assertions, 1,776 participants, 2,237 transmission attributes,
166 rule groups, 250 rules, 948 rule elements, 41,285 clusters, 41,342 knowledge units, 213,851 evidence nodes.

---

## 2. `01_standardized_data/` (15 files)

| File | Rows | Content |
|---|---:|---|
| `cases.csv` | 261 | case master table: title, per-sheet row counts, derived counts, `source_files`, `n_increment_rows` |
| `entities.csv` | 72,163 | deduplicated by (case, entity string, ontology class); `n_mentions` keeps the mention count, `source_batches` the batches it was seen in |
| `attributes.csv` | 65,474 | attribute facts, one row per annotation row (no aggregation) |
| `relations.csv` | 52,790 | relation statements incl. the normalized ontology relation URI |
| `transmission.csv` | 625 | aggregated by the TR instance IDs of the annotation tables; `graph_ready` is a structural criterion |
| `transmission_participants.csv` | 1,776 | transmission participants and their roles |
| `transmission_attributes.csv` | 2,237 | attribute records of transmission instances |
| `rules.csv` | 250 | rule master table (subject / conditions / result / authority, `\|`-joined) |
| `rule_elements.csv` | 948 | rule elements, one row each |
| `rule_groups.csv` | 166 | rule groups by (case, title block) |
| `knowledge_units.csv` | 41,342 | deduplicated by (case, normalized-text SHA-256); `source_rows` entries read `<batch>/<sheet>/<row>` |
| `knowledge_unit_clusters.csv` | 41,285 | cross-case clusters by text hash |
| `evidence_references.csv` | 213,851 | one evidence row per annotation row that carries a source sentence, pointing at its knowledge unit |
| `data_dictionary.csv` | 44 | field-by-field documentation, one row per field with `description_zh` and `description_en` |
| `release_manifest.json` | — | counts, SHA-256 of the 13 tables, the increment block and the derivation rules |

---

## 3. `02_rdf_graph/` (6 files)

| File | Size | Content |
|---|---:|---|
| `instance_vocab.ttl` | 4,231 B | vocabulary: 13 classes, 14 object properties, 59 datatype properties |
| `instances.ttl` | 256,238,943 B | full graph in Turtle (**5,082,372** triples) |
| `instances.nt` | 553,361,380 B | same graph in N-Triples (unsorted; for Blazegraph / Virtuoso / rdflib bulk loads) |
| `graph_sample.ttl` | 2,097,672 B | CN-001…CN-003 subset (3,883 nodes / 41,909 statements) |
| `graph_sample.jsonld` | 2,608,799 B | the same subset as JSON-LD 1.1, strictly equivalent to the Turtle file |
| `graph_build_manifest.json` | — | triple count, namespaces, increment block, per-file SHA-256 |

Namespaces: instances `urn:dengekg:instance:`, vocabulary `urn:dengekg:graph:`, ontology `urn:dengekg:ontology:`.

The graph carries the provenance datatype properties `sourceBatch`, `sourceBatches`, `sourceFile` and
`nIncrementRows`, so the batch a fact came from is queryable in SPARQL as well.

```python
import rdflib
g = rdflib.Graph()
g.parse("04_knowledge_graph/02_rdf_graph/graph_sample.ttl", format="turtle")
print(len(g))                     # 41,909
```

---

## 4. Reproduction

```bash
python 04_knowledge_graph/03_code/build_kg_tables.py    # 02_annotations -> 01_standardized_data/  (~3 min)
python 04_knowledge_graph/03_code/build_kg_rdf.py       # 01_standardized_data -> 02_rdf_graph/  (~5 min, 258 MB + 558 MB)
python 04_knowledge_graph/03_code/build_papers_table.py # 01_standardized_data/cases.csv -> ../01_source_literature/
```

Verification: `01_standardized_data/release_manifest.json` and `02_rdf_graph/graph_build_manifest.json` both
record a per-file SHA-256, and `build_kg_tables.py` fails hard if the evidence count ever stops matching the
annotation row count.
