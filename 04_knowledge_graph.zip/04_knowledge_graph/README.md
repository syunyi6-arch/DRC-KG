# Knowledge Graph

This folder holds the standardized data tables and the RDF serialization of
**DRC-KG (Dengue Research Case Knowledge Graph)**, each in its own subfolder:

```
04_knowledge_graph/
├── 01_standardized_data/   12 structured tables + 2 auxiliary tables + data dictionary + release manifest (15 files)
├── 02_rdf_graph/           instance vocabulary + full Turtle + full N-Triples + subset examples + build manifest (6 files)
├── 03_code/                scripts that generate the two artefacts above (reproducible)
└── README.md
```

Both artefacts are derived **only** from the four aggregation workbooks in `../02_annotations/`:

```
02_annotations/CN_138_classification_tables_ontology-zh.xlsx ┐
02_annotations/CN_138_classification_tables_ontology-en.xlsx ┤
02_annotations/EN_123_classification_tables_ontology-zh.xlsx ┤→ 01_standardized_data/ → 02_rdf_graph/
02_annotations/EN_123_classification_tables_ontology-en.xlsx ┘
```

Chinese labels and the annotation content come from the `ontology-zh` workbooks; English labels come from the
`ontology-en` workbooks (the two variants are row-aligned; 90,103 + 53,022 cell values were compared and match
exactly). Ontology classes, attributes and relations are then resolved to stable IDs and URIs through
`../03_ontology/ontology_term_map.csv` (467 terms), with a **100% label match rate** (0 unmapped labels).

---

## 1. Scale (measured on this build)

| Item | Count |
|---|---:|
| Research cases | **261** (Chinese 138 / English 123) |
| Annotation rows (02 aggregation) | **216,293** (01: 90,103 · 02: 66,596 · 03: 53,022 · 04: 948 · 05: 1,776 · 06: 2,242 · 07: 1,606) |
| Entity candidates | **72,115** |
| Attribute facts | **66,596** |
| Relation statements | **53,022** |
| Transmission instances / participants / attribute records | **625 / 1,776 / 2,242** (`graph_ready` 494) |
| Rules / rule elements / rule groups | **250 / 948 / 166** |
| Knowledge units / clusters | **41,277 / 41,220** |
| Evidence references | **210,669** |
| RDF triples / subjects | **4,290,647 / 491,167** |

RDF node counts match the table row counts one to one: 261 cases, 72,115 entities, 66,596 attribute assertions,
53,022 relation assertions, 625 transmission assertions, 1,776 participants, 2,242 transmission attributes,
166 rule groups, 250 rules, 948 rule elements, 41,220 clusters, 41,277 knowledge units, 210,669 evidence nodes.

---

## 2. `01_standardized_data/` (15 files)

| File | Rows | Content |
|---|---:|---|
| `cases.csv` | 261 | case master table: title, per-sheet row counts, derived counts |
| `entities.csv` | 72,115 | deduplicated by (case, entity string, ontology class); `n_mentions` keeps the mention count |
| `attributes.csv` | 66,596 | attribute facts, one row per annotation row (no aggregation) |
| `relations.csv` | 53,022 | relation statements incl. the normalized ontology relation URI |
| `transmission.csv` | 625 | aggregated by the TR instance IDs of the annotation tables; `graph_ready` is a structural criterion |
| `transmission_participants.csv` | 1,776 | transmission participants and their roles |
| `transmission_attributes.csv` | 2,242 | attribute records of transmission instances |
| `rules.csv` | 250 | rule master table (subject / conditions / result / authority, `|`-joined) |
| `rule_elements.csv` | 948 | rule elements, one row each |
| `rule_groups.csv` | 166 | rule groups by (case, title block) |
| `knowledge_units.csv` | 41,277 | deduplicated by (case, normalized-text SHA-256) |
| `knowledge_unit_clusters.csv` | 41,220 | cross-case clusters by text hash |
| `evidence_references.csv` | 210,669 | one evidence row per annotation row that carries a source sentence, pointing at its knowledge unit |
| `data_dictionary.csv` | 30 | field-by-field documentation |
| `release_manifest.json` | — | counts, SHA-256 of the 13 tables, derivation rules and limits |

---

## 3. `02_rdf_graph/` (6 files)

| File | Size | Content |
|---|---:|---|
| `instance_vocab.ttl` | 4,057 B | vocabulary: 13 classes, 14 object properties, 55 datatype properties |
| `instances.ttl` | 196,469,527 B | full graph in Turtle (**4,290,647** triples) |
| `instances.nt` | 453,618,469 B | same graph in N-Triples (unsorted; for Blazegraph / Virtuoso / rdflib bulk loads) |
| `graph_sample.ttl` | 1,612,544 B | CN-001…CN-003 subset (3,806 nodes / 34,623 statements) |
| `graph_sample.jsonld` | 2,106,908 B | the same subset as JSON-LD 1.1, strictly equivalent to the Turtle file |
| `graph_build_manifest.json` | 1,913 B | triple count, namespaces, per-file SHA-256 |

Namespaces: instances `urn:dengekg:instance:`, vocabulary `urn:dengekg:graph:`, ontology `urn:dengekg:ontology:`.

```python
import rdflib
g = rdflib.Graph()
g.parse("04_knowledge_graph/02_rdf_graph/graph_sample.ttl", format="turtle")
print(len(g))                     # 34,623
```

---

## 4. Difference from the earlier (removed) 04/05 folders

The earlier `04_standardized_data` / `05_rdf_graph` folders came from the step-5 release view of the project.
This build is regenerated entirely from the current `02_annotations`, whose annotation volume is much larger,
so the figures shift upwards:

| Metric | Earlier (step-5 release view) | This build (from current 02) |
|---|---:|---:|
| Annotation rows | 145,743 | **216,293** |
| Relation statements | 22,759 | **53,022** |
| Transmission instances | 161 | **625** |
| Entity candidates | 51,871 | **72,115** |
| Evidence references | 90,004 | **210,669** |
| Knowledge units | 42,164 | 41,277 |
| RDF triples | 5,071,441 | 4,290,647 |

Knowledge units and triples are lower because this build derives knowledge units only from the source-sentence
columns of 02 (it no longer merges the internal middleware of step 5) and does not produce the step-5-only tables
(redaction log, unresolved records). **The two versions must not be mixed.**

---

## 5. Boundaries

1. **Only locators and hashes are published**: knowledge units carry no source text, only the SHA-256 of the
   normalized text plus its length (usable for deduplication and self-checking, without disclosing the text).
2. **Entities are not disambiguated**: all are `candidate`; identical strings across papers are not merged.
3. **Transmission instances are author claims**: `graph_ready=true` only means the head and tail participants are
   both present; it does **not** mean the transmission is confirmed.
4. Rule element text is published under project decision D7 (structured rules, not narrative source text).

---

## 6. Reproduction

```bash
python 04_knowledge_graph/03_code/build_kg_tables.py   # 02 -> 01_standardized_data/  (~2 min)
python 04_knowledge_graph/03_code/build_kg_rdf.py      # 01_standardized_data -> 02_rdf_graph/  (~4 min, 196 MB + 454 MB)
```

Verification: `01_standardized_data/release_manifest.json` and `02_rdf_graph/graph_build_manifest.json` both
record a per-file SHA-256.
