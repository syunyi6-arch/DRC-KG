# 4.1 Completeness

## Result

For DRC-KG (Dengue Research Case Knowledge Graph), the 14 sheets of the 261 papers (Chinese 138,
English 123) hold 216,293 valid data rows, all of which fall inside the ontology vocabulary; 449 of
the 470 ontology terms are used and the label match rate on the annotation side is 100%. A 30-paper
reference set covers 2,825 knowledge units and 8,813 atomic facts; knowledge-unit retention is
75.54% and atomic-fact recall is 62.56%.

## Result files

| File | Content |
|---|---|
| `results/basic_statistics.json` | paper count, per-sheet row counts, static-flag classes, ontology vocabulary usage |
| `results/table_row_counts.csv` | row count of each of the 14 sheets |
| `results/ontology_vocabulary_usage.csv` | three rows (classes / attributes / semantic relations) incl. label match rate |
| `results/unused_ontology_terms_*.csv` | ontology terms that the annotations never used |
| `results/knowledge_type_coverage.csv` | papers and rows per language x sheet x knowledge type |
| `results/raw_vs_classified_surface_match.csv` | literal surface hit rate of source strings (Chinese 97.26%, English 95.38%) |
| `results/sample_freeze_info.json` | sampling seed 20261104, 1,000 general samples, 57 rule units, 30-paper reference set |
| `results/reference_set_30_summary.json` | reference-set denominator, TP/FN, three recall figures |
| `results/reference_set_30_by_language.csv` | summary split by Chinese / English |
| `results/reference_set_30_per_paper.csv` | per-paper unit and fact counts for the 30 papers |
| `results/case_index_country_year.csv` | first deterministic pass of country / year for the 261 papers |

## Code

| Script | Purpose |
|---|---|
| `00_common_code/src/analysis.py` | full static mapping check, coverage statistics, stratified sampling |
| `00_common_code/src/main.py` | stage entry point (`--stage data`) |
| `code/build_case_index.py` | country / year index (depends on `country_gazetteer.csv`, `National_extract_V1_3.csv`) |
| `code/aggregate_reference.py` | aggregates the 30 per-paper reference-set judgements |
| `code/recall_calc.py` | computes knowledge-unit and atomic-fact recall |
| `code/export_kg_rows.py` | exports graph-side rows for comparison with the reference set |
| `code/coverage_check.py` | knowledge-type coverage check |

## Scope notes

- The row count of the seven-table structure counts annotation rows; it is neither the atomic-fact count nor the
  unique-entity count.
- The literal surface hit rate is a string check: splitting, truncation and normalization all cause misses, so it
  must not be read as a miss rate of annotation.
- The reference-set denominator counts only in-scope items; title pages, affiliations, funding and references are
  excluded.
- The country / year index yields 45 candidate countries or territories (3 papers have no country code); the
  manuscript reports 45 (China plus 44 others).
