# 4.1 Completeness — Fact Recall (final TP/FN)

## Result

Completeness was measured on the 30-article reference set of the DRC-KG corpus (Dengue Research Case
Knowledge Graph): 15 Chinese-language and 15 English-language research-case articles. Verdicts follow the
author-adjudicated binary protocol — a candidate reference record counts as a true positive (TP) when the
final knowledge records contain a corresponding valid structured representation, and as a false negative
(FN) otherwise. No partial-match category is used.

Of 4,046 candidate reference records, 16 were excluded as out of scope and 321 duplicate TP records were
removed, leaving 3,709 eligible reference facts. Of these, 3,483 were matched (TP) and 226 were not (FN),
giving an overall fact recall of **93.91%** (3,483/3,709); the Chinese subset yields **93.19%**
(1,395/1,497) and the English subset **94.39%** (2,088/2,212).

| Subset | TP | FN | Eligible facts | Fact Recall |
|---|---:|---:|---:|---:|
| Chinese (n = 15 articles) | 1,395 | 102 | 1,497 | 93.19% |
| English (n = 15 articles) | 2,088 | 124 | 2,212 | 94.39% |
| **Overall (n = 30 articles)** | **3,483** | **226** | **3,709** | **93.91%** |

## Package layout

| Path | Content |
|---|---|
| `reference_set_30/` | authoritative input: the two adjudicated TP / FN workbooks and their CSV mirrors |
| `results/` | derived results, exclusion and deduplication logs, package manifest |
| `report/` | wording for the manuscript |
| `code/` | the calculation script, the package checker and their dependencies |

## Files

| File | Content |
|---|---|
| `reference_set_30/4.1_final_TP_table.xlsx` | workbook of the final TP rows: 3,483 matched reference facts |
| `reference_set_30/4.1_final_FN_table.xlsx` | workbook of the final FN rows: 226 unmatched reference facts |
| `reference_set_30/final_TP.csv` | CSV mirror of the TP table |
| `reference_set_30/final_FN.csv` | CSV mirror of the FN table; the extracted column carries the not-extracted flag |
| `reference_set_30/README.md` | column semantics, record-ID scheme and adjudication rules |
| `results/4.1_results.xlsx` | worksheets `Overall` (3 rows), `Per-paper` (30 rows) and `Notes` (7 protocol items) |
| `results/4.1_results.csv` | the three grouped rows: Chinese, English, overall |
| `results/exclusion_records.csv` | 16 out-of-scope records with the author verdict, kept out of the denominator |
| `results/dedup_records.csv` | 321 duplicate mappings: removed ID, retained ID, paper, reference fact, extracted fact |
| `results/manifest_and_checksums.json` | file inventory, byte sizes, SHA-256 values and the counts of the chain |
| `report/4.1_results_statement_en.md` | ready-to-quote English statement with the results table |

## Reference-set input files

`reference_set_30/` holds the only authoritative input: the workbooks `4.1_final_TP_table.xlsx` and
`4.1_final_FN_table.xlsx`, each carrying four columns — `id`, `reference_fact`, `extracted` and
`remarks` — and each mirrored as a CSV file. Record IDs read
`{lang}{3-digit paper}-{source}-{3-digit serial}`, for example `CN011-SF-001`; the source marker is `AUTO`
(3,508 records), `SF` (157) or `VIS` (44) over the combined TP and FN tables. An ID is unique within each
table and never appears in both tables, and the script refuses to run when either property fails.

## Code

| Script | Purpose |
|---|---|
| `code/calculate_fact_recall.py` | reads the two workbooks, validates IDs and columns, writes `results/4.1_results.xlsx` and `results/4.1_results.csv` |
| `code/verify_package.py` | re-checks the manifest SHA-256 values and the 4,046 → 3,709 → 3,483/226 chain against `results/4.1_results.csv` |

## Reproduction

```bash
pip install -r code/requirements.txt
python code/calculate_fact_recall.py
python code/verify_package.py
```

`calculate_fact_recall.py` rejects an ID that breaks the paper pattern, a duplicate ID within one table, an
ID present in both tables, a TP row without an extracted representation and an FN row that does carry one.
It then aggregates by language and by the five-character paper prefix and writes both result files.
Expected standard output:

```
TP=3483, FN=226, Recall=93.906713%
```

## Scope notes

- The counting unit is the final, deduplicated reference-fact record keyed by its ID; it is neither an
  annotation-row count nor a unique-entity count.
- The denominator contains in-scope items only. Title pages, affiliations, journal headers, funding
  statements and reference lists are excluded on bibliographic cues (16 records, see
  `results/exclusion_records.csv`) and never enter the denominator.
- Deduplication is applied only within a single article, and only when both the reference fact and the
  extracted representation are identical (321 records); nothing is deduplicated across articles.
- Within one research-case context, a relational triple, an entity attribute and a relation attribute all
  count as a match.
- The figure describes coverage over the 30 author-reviewed sample articles and must not be read as an
  exhaustive estimate of all extractable facts in the 261-article corpus.
- Verdicts were produced and confirmed by the authors as the final adjudication; they are not an
  independent third-party re-verification.
