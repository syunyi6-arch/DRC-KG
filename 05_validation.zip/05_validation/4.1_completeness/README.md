# 4.1 Completeness

```text
4.1_completeness/
├── README.md
├── code/
│   ├── requirements.txt
│   ├── calculate_fact_recall.py
│   ├── verify_package.py
│   └── resolve_annotation_pointer.py
├── reference_set_30/
│   ├── README.md
│   ├── 4.1_final_TP_table.xlsx
│   ├── 4.1_final_FN_table.xlsx
│   ├── final_TP.csv
│   ├── final_FN.csv
│   └── source_index.csv
├── report/
│   └── 4.1_results_statement_en.md
└── results/
    ├── 4.1_results.csv
    ├── 4.1_results.xlsx
    ├── dedup_records.csv
    ├── exclusion_records.csv
    └── manifest_and_checksums.json
```

## Reproduction

From `4.1_completeness/`:

```bash
python -m pip install -r code/requirements.txt
python code/calculate_fact_recall.py
python code/verify_package.py
python code/resolve_annotation_pointer.py --annotations ../../02_annotations
```

`calculate_fact_recall.py` reads `reference_set_30/4.1_final_TP_table.xlsx` and
`reference_set_30/4.1_final_FN_table.xlsx` and writes `results/4.1_results.xlsx` and
`results/4.1_results.csv`. `verify_package.py` re-checks every file listed in
`results/manifest_and_checksums.json`. `resolve_annotation_pointer.py` re-derives the `ann_key` of every
keyed TP record from `02_annotations/`.
