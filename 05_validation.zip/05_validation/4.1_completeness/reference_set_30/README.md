# reference_set_30 — authoritative TP / FN input tables

This directory holds the only authoritative input of the 4.1 fact-recall evaluation: two workbooks of
author-adjudicated verdicts, each mirrored as a CSV file.

| File | Content |
|---|---|
| `4.1_final_TP_table.xlsx` | worksheet `TP`: the 3,483 matched reference facts |
| `4.1_final_FN_table.xlsx` | worksheet `FN`: the 226 unmatched reference facts |
| `final_TP.csv` | CSV mirror of the TP table |
| `final_FN.csv` | CSV mirror of the FN table |

## Columns

| Column | Meaning |
|---|---|
| `id` | record ID, the unique key of the chain |
| `reference_fact` | the reference fact taken from the source article, as subject \| predicate \| object |
| `extracted` | the representation found in the final knowledge records; the not-extracted flag for every FN row |
| `remarks` | trace back to the evidence: paper code, PDF page, the annotation sheet and the source row |

## Record-ID scheme

`{lang}{3-digit paper}-{source}-{3-digit serial}`, for example `CN011-SF-001`.

- `lang` is `CN` or `EN`; the three-digit paper code matches the identifier used in the annotation
  workbooks, and the first five characters of an ID therefore give the paper.
- `source` marks the candidate list the record came from: `AUTO` (3,508 records), `SF` (157) or `VIS` (44)
  over the combined tables.
- The serial is unique inside one paper and one source.

An ID is unique within its own table and never appears in both tables. `code/calculate_fact_recall.py`
validates both properties, and also requires every TP row to carry an extracted representation and every FN
row to carry the not-extracted flag.

## Adjudication rules

- Binary verdicts only: a candidate is TP when a valid structured representation exists, FN otherwise; no
  partial-match class.
- Within one research-case context, a relational triple, an entity attribute and a relation attribute are
  equally acceptable representations of a reference fact.
- Out-of-scope candidates — title pages, affiliations, journal headers, funding statements, reference
  lists — are removed before adjudication and kept in `results/exclusion_records.csv`; they never enter the
  denominator.
- Duplicates are removed only inside one article, and only when the reference fact and the extracted
  representation are both identical; the 321 mappings are in `results/dedup_records.csv`.
- The verdicts are the authors' final adjudication, not an independent third-party re-verification.

## Counts

| Item | Count |
|---|---:|
| Candidate reference records | 4,046 |
| Excluded as out of scope | 16 |
| Duplicate TP records removed | 321 |
| Eligible reference facts | 3,709 |
| TP | 3,483 |
| FN | 226 |
