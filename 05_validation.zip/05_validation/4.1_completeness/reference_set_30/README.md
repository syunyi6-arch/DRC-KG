# reference_set_30

```text
reference_set_30/
├── README.md
├── 4.1_final_TP_table.xlsx
├── 4.1_final_FN_table.xlsx
├── final_TP.csv
├── final_FN.csv
└── source_index.csv
```

## Reproduction

From `reference_set_30/`:

```bash
python ../code/resolve_annotation_pointer.py --annotations ../../../02_annotations
```

From `4.1_completeness/`:

```bash
python code/calculate_fact_recall.py
python code/verify_package.py
```
