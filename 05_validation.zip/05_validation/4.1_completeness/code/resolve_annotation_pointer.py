#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""4.1 Completeness: resolve the row-number-free annotation pointer of every TP record.

Each TP record in `reference_set_30/final_TP.csv` carries, in its `remarks` column, a key of the form

    ann_key=<sheet>/<12 hex characters>

which identifies one row of the annotation workbook by content only -- no row number is involved, so
inserting, deleting or reordering rows anywhere in the sheet leaves the key valid.  The key is the first
12 hex digits of the SHA-256 of the row's *canonical string*:

    every cell value of the row, in header order, joined with U+001F (unit separator),
    skipping the bookkeeping columns `批次` and `批次行号` / `Batch` and `Batch Row No.`

`source_index.csv` lists, for every keyed record, the key, the full SHA-256 and a human-readable excerpt of
the row, so the pointer can be read without any tooling.  This script re-derives the keys from the
annotation workbooks and reports which row each pointer currently designates.

    python code/resolve_annotation_pointer.py                     # index self-check only
    python code/resolve_annotation_pointer.py --annotations ../../02_annotations
                                                                  # also re-resolve against the workbooks

Exit code 0 when every pointer resolves to exactly one row, 1 otherwise.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import re
import sys
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent
REF = BASE / "reference_set_30"
TP_CSV = REF / "final_TP.csv"
INDEX_CSV = REF / "source_index.csv"
SHEETS = ("01", "02", "03", "04", "05", "06", "07")
BOOKS = {
    "CN": ("CN_138_classification_tables_ontology-zh.xlsx", "CN_138_classification_tables_ontology-en.xlsx"),
    "EN": ("EN_123_classification_tables_ontology-en.xlsx", "EN_123_classification_tables_ontology-zh.xlsx"),
}
BOOKKEEP = {"批次", "批次行号", "Batch", "Batch Row No."}
KEY_RE = re.compile(r"ann_key=(\d{2})/([0-9a-f]{12})\b")

problems: list[str] = []


def check(ok: bool, label: str, detail: str = "") -> None:
    print(("OK   " if ok else "FAIL ") + label + (f" :: {detail}" if detail else ""))
    if not ok:
        problems.append(label)


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as fp:
        return list(csv.DictReader(fp))


def keys_of_workbook(path: Path) -> dict[str, dict[str, int]]:
    """sheet -> {ann_key: row number} for one annotation workbook."""
    import openpyxl

    out: dict[str, dict[str, int]] = {}
    wb = openpyxl.load_workbook(path, read_only=True)
    for ws in wb.worksheets:
        sheet = ws.title.split("_")[0]
        rows = ws.iter_rows(values_only=True)
        header = [str(c) if c is not None else "" for c in next(rows)]
        keep = [i for i, c in enumerate(header) if c not in BOOKKEEP]
        seen: dict[str, int] = {}
        for i, row in enumerate(rows, start=2):
            canon = "\x1f".join("" if row[j] is None else str(row[j]) for j in keep)
            key = f"{sheet}/{hashlib.sha256(canon.encode('utf-8')).hexdigest()[:12]}"
            if key in seen:
                raise SystemExit(f"{path.name}: duplicated key {key} at rows {seen[key]} and {i}")
            seen[key] = i
        out[sheet] = seen
    wb.close()
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--annotations", type=Path, default=None,
                    help="directory holding the four 02_annotations workbooks")
    args = ap.parse_args()

    tp = read_csv(TP_CSV)
    index = read_csv(INDEX_CSV)
    print(f"final_TP.csv: {len(tp)} rows; source_index.csv: {len(index)} rows")

    keyed = {r["id"]: KEY_RE.search(r["remarks"] or "") for r in tp}
    keyed = {i: m.group(0)[len("ann_key="):] for i, m in keyed.items() if m}
    check(len(index) == len(keyed), "index covers every keyed TP row",
          f"{len(index)} index rows vs {len(keyed)} keys in final_TP.csv")
    check(set(r["id"] for r in index) == set(keyed), "the same record IDs on both sides")

    by_id = {r["id"]: r for r in index}
    mismatch = [i for i, k in keyed.items() if by_id[i]["ann_key"] != k]
    check(not mismatch, "ann_key in remarks equals ann_key in source_index.csv",
          "" if not mismatch else f"{len(mismatch)} differ, e.g. {mismatch[:3]}")

    bad_sheet = [r["id"] for r in index if r["ann_key"].split("/")[0] != r["annotation_sheet"]]
    check(not bad_sheet, "the sheet inside ann_key equals the annotation_sheet column")

    if args.annotations:
        for lang, names in BOOKS.items():
            path = args.annotations / names[0]
            check(path.exists(), f"workbook present: {path.name}")
            if not path.exists():
                continue
            keys = keys_of_workbook(path)
            want = {"CN": [r for r in index if r["paper"].startswith("CN")],
                    "EN": [r for r in index if r["paper"].startswith("EN")]}[lang]
            wrong = [r["id"] for r in want if r["workbook"] != names[0]]
            check(not wrong, f"{lang}: the workbook column names the workbook the key is defined on",
                  "" if not wrong else f"{len(wrong)} rows, e.g. {wrong[:3]}")
            missing, moved = [], []
            for r in want:
                sheet, key = r["ann_key"].split("/")
                row = keys.get(sheet, {}).get(r["ann_key"])
                if row is None:
                    missing.append(r["id"])
                elif str(row) != r["annotation_row"]:
                    moved.append((r["id"], r["annotation_row"], row))
            check(not missing, f"{lang}: every ann_key resolves to exactly one row",
                  "" if not missing else f"{len(missing)} unresolved, e.g. {missing[:3]}")
            print(f"     {lang}: {len(want)} pointers; {len(moved)} resolve to a row other than the "
                  f"recorded annotation_row")
            for m in moved[:10]:
                print(f"       {m[0]}: recorded row {m[1]} -> current row {m[2]}")

    print()
    if problems:
        print(f"{len(problems)} check(s) failed")
        return 1
    print("all checks passed")
    return 0


if __name__ == "__main__":
    sys.exit(main())
