"""Sanity-check corpus coverage numbers from the deterministic case index first pass."""
import csv
from collections import Counter

rows = list(csv.DictReader(open('_work/case_index/case_index_candidates.csv', encoding='utf-8-sig')))
print('papers', len(rows))
isos = Counter(r['cand_iso3'] for r in rows if r['cand_iso3'])
print('distinct country iso3 (all candidates):', len(isos))
print(sorted(isos.items(), key=lambda x: -x[1]))
hi = [r for r in rows if r['confidence'] == 'high']
print('\nhigh-confidence papers:', len(hi))
iso_hi = Counter(r['cand_iso3'] for r in hi if r['cand_iso3'])
print('distinct country iso3 (high):', len(iso_hi))
print(sorted(iso_hi.items(), key=lambda x: -x[1]))

for lang in ('CN', 'EN'):
    ys = [int(r['outbreak_start_year']) for r in rows if r['lang'] == lang and r['outbreak_start_year'].isdigit()]
    ye = [int(r['outbreak_end_year']) for r in rows if r['lang'] == lang and r['outbreak_end_year'].isdigit()]
    print(f'\n{lang}: n={len(ys)} year range {min(ys) if ys else None}-{max(ye) if ye else None}')
ys = [int(r['outbreak_start_year']) for r in rows if r['outbreak_start_year'].isdigit()]
print('\nALL year range', min(ys), max(ys))
print('papers without year:', sum(1 for r in rows if not r['outbreak_start_year']))
