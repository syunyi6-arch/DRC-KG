#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""4.1 Completeness / Fact Recall: package checker.

Run from anywhere:
    python code/verify_package.py

Standard library only; it needs neither the workbooks nor any third-party
package. Three groups of checks:

1. every file listed in results/manifest_and_checksums.json exists and matches
   the recorded byte size and SHA-256;
2. the counting chain of the manifest is internally consistent and agrees with
   both logs: 4,046 - 16 - 321 = 3,709 = TP + FN;
3. TP / FN / denominator / recall recomputed from reference_set_30/final_TP.csv
   and final_FN.csv equal the values written in results/4.1_results.csv.

Exit code 0 when every check passes, 1 otherwise.
"""
from __future__ import annotations

import csv
import hashlib
import json
import sys
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent
MANIFEST = BASE / "results" / "manifest_and_checksums.json"
TP_CSV = BASE / "reference_set_30" / "final_TP.csv"
FN_CSV = BASE / "reference_set_30" / "final_FN.csv"
EXCL_CSV = BASE / "results" / "exclusion_records.csv"
DEDUP_CSV = BASE / "results" / "dedup_records.csv"
RESULT_CSV = BASE / "results" / "4.1_results.csv"
GROUPS = (("Chinese (n=15)", "CN"), ("English (n=15)", "EN"))
OVERALL = "Overall (n=30)"
# "not extracted" is the marker; an empty cell is accepted as well.
NOT_EXTRACTED = ("", "not extracted")

problems: list[str] = []


def check(ok: bool, label: str, detail: str = "") -> None:
    if ok:
        print(f"OK   {label}{' :: ' + detail if detail else ''}")
    else:
        problems.append(label)
        print(f"FAIL {label}{' :: ' + detail if detail else ''}")


def sha256_of(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as fp:
        for chunk in iter(lambda: fp.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as fp:
        return [
            {k.strip(): (v or "").strip() for k, v in row.items() if k is not None}
            for row in csv.DictReader(fp)
            if any((v or "").strip() for v in row.values() if isinstance(v, str))
        ]


def main() -> int:
    if not MANIFEST.is_file():
        print(f"missing manifest: {MANIFEST}")
        return 1
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    counts = manifest["counts"]

    for rel, rec in sorted(manifest["files"].items()):
        path = BASE / rel
        if not path.is_file():
            check(False, f"present {rel}")
            continue
        size = path.stat().st_size
        digest = sha256_of(path)
        check(size == rec["bytes"] and digest == rec["sha256"], f"file {rel}", f"{size} B")

    excluded_rows = read_rows(EXCL_CSV)
    dedup_rows = read_rows(DEDUP_CSV)
    tp_rows = read_rows(TP_CSV)
    fn_rows = read_rows(FN_CSV)
    ids_tp = [r["id"] for r in tp_rows]
    ids_fn = [r["id"] for r in fn_rows]

    check(len(excluded_rows) == counts["excluded"], "exclusion log rows", str(len(excluded_rows)))
    check(len(dedup_rows) == counts["deduplicated_TP"], "deduplication log rows", str(len(dedup_rows)))
    check(counts["source_candidates"] - counts["excluded"] - counts["deduplicated_TP"]
          == counts["eligible_reference_facts"], "chain: candidates - excluded - deduplicated == eligible")
    check(len(tp_rows) == counts["TP"] and len(fn_rows) == counts["FN"], "TP / FN row counts",
          f"{len(tp_rows)} / {len(fn_rows)}")
    check(counts["TP"] + counts["FN"] == counts["eligible_reference_facts"], "TP + FN == eligible")
    check(len(set(ids_tp)) == len(ids_tp) and len(set(ids_fn)) == len(ids_fn), "record IDs unique")
    check(not (set(ids_tp) & set(ids_fn)), "TP and FN tables disjoint")
    check(all(r["extracted"] not in NOT_EXTRACTED for r in tp_rows), "every TP carries an extracted value")
    check(all(r["extracted"] in NOT_EXTRACTED for r in fn_rows), "every FN carries the not-extracted flag")

    computed: dict[str, tuple[int, int]] = {}
    for label, lang in GROUPS:
        computed[label] = (sum(1 for i in ids_tp if i.startswith(lang)),
                           sum(1 for i in ids_fn if i.startswith(lang)))
    computed[OVERALL] = (len(ids_tp), len(ids_fn))

    written = {r["group"]: r for r in read_rows(RESULT_CSV)}
    for label, (tp, fn) in computed.items():
        row = written.get(label)
        if row is None:
            check(False, f"results row {label}")
            continue
        total = tp + fn
        recall = tp / total if total else 0.0
        ok = (int(row["TP"]) == tp and int(row["FN"]) == fn
              and int(row["eligible_facts"]) == total
              and abs(float(row["recall"]) - recall) < 1e-6)
        check(ok, f"results row {label}", f"TP={tp}, FN={fn}, recall={recall:.6f}")

    print()
    if problems:
        print(f"problems: {len(problems)}")
        return 1
    eligible = len(ids_tp) + len(ids_fn)
    print("problems: 0")
    print(f"fact recall = {len(ids_tp)}/{eligible} = {len(ids_tp) / eligible:.6f}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
