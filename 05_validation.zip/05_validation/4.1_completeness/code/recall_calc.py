"""Score a blind source-side reference set against DRC-KG records for the same paper.

Similarity is deliberately conservative and documented:
  * knowledge unit retained  : best-matching DRC-KG evidence text has char/word overlap >= 0.55
  * knowledge unit partial   : overlap in [0.35, 0.55)
  * atomic fact retained     : a DRC-KG row of that paper contains both subject and object
                               (normalised substring) and its predicate overlaps the fact predicate
Usage:  python _work/gold_recall.py _work/gold_pilot/gold_CN_102.json ...
"""
import json
import re
import sys
import unicodedata
from pathlib import Path

from openpyxl import load_workbook

BASE = r'1.中英文本体与标注文件成果'
BOOKS = {
    'CN': BASE + r'\中文\1026_中文登革热138篇_分类表汇总.xlsx',
    'EN': BASE + r'\英文\1026_英文登革热123篇_分类表汇总.xlsx',
}
SHEETS = ['01_普通三元组_类', '02_普通三元组_属性', '03_普通三元组_关系',
          '04_规则汇总', '05_传播关系_类', '06_传播关系_属性', '07_传播关系_关系']
EVID_COL = {'01_普通三元组_类': '文字来源', '02_普通三元组_属性': '原文', '03_普通三元组_关系': '文字来源',
            '04_规则汇总': '知识单元（原文）', '05_传播关系_类': '原文', '06_传播关系_属性': '原文',
            '07_传播关系_关系': '文字来源'}


def norm(v):
    return unicodedata.normalize('NFKC', str(v or '')).strip().casefold()


def clean(v):
    return re.sub(r'[^\w\u4e00-\u9fff]+', '', norm(v))


def ngrams(text, n=3):
    t = clean(text)
    return {t[i:i + n] for i in range(max(1, len(t) - n + 1))} if t else set()


def jaccard(a, b):
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


def load_paper_rows(lang, code):
    out = []
    wb = load_workbook(BOOKS[lang], read_only=True, data_only=True)
    for sh in SHEETS:
        ws = wb[sh]
        it = ws.iter_rows(values_only=True)
        h = next(it)
        idx = {str(v).strip(): i for i, v in enumerate(h) if v is not None}
        src_col = '文件来源' if '文件来源' in idx else '源文件'
        if src_col not in idx:
            continue
        for row in it:
            si = idx[src_col]
            src = str(row[si]).strip() if si < len(row) and row[si] is not None else ''
            if not src.startswith(code):
                continue
            d = {k: (str(row[i]).strip() if i < len(row) and row[i] is not None else '')
                 for k, i in idx.items()}
            d['_sheet'] = sh
            d['_evid'] = d.get(EVID_COL[sh], '')
            out.append(d)
    wb.close()
    return out


PRED_STOP = {'的', '了', '和', '与', '及'}


def pred_hit(p, row):
    pn = clean(p)
    if not pn:
        return False
    hay = clean(' '.join([row.get('关系', ''), row.get('属性分类', ''),
                          row.get('本体关系类型', ''), row.get('规则要素', '')]))
    if pn in hay:
        return True
    # token overlap for multi-word predicates
    toks = [t for t in re.split(r'[-_\s]+', norm(p)) if t and t not in PRED_STOP]
    return bool(toks) and all(t in hay for t in toks)


def score(gold_path):
    g = json.loads(Path(gold_path).read_text(encoding='utf-8'))
    lang = g['lang']
    code = g['paper'][:3]
    rows = load_paper_rows(lang, code)
    evid = [(r, ngrams(r['_evid'])) for r in rows]
    print(f'\n=== {g["paper"]} ===')
    print(f'  参考集：units={len(g["units"])}  facts={sum(len(u["facts"]) for u in g["units"])}')
    print(f'  DRC-KG：该论文记录 {len(rows)} 行')

    ku_ret = ku_par = ku_mis = 0
    f_tot = f_ret = 0
    for u in g['units']:
        ug = ngrams(u['text'])
        best = 0.0
        for _, rg in evid:
            s = jaccard(ug, rg)
            if s > best:
                best = s
        if best >= 0.55:
            ku_ret += 1
        elif best >= 0.35:
            ku_par += 1
        else:
            ku_mis += 1
        for f in u['facts']:
            f_tot += 1
            s_c = clean(f.get('s', ''))
            o_c = clean(f.get('o', ''))
            ok = False
            for r, _ in evid:
                hay = clean(r['_evid'] + ' ' + ' '.join(
                    str(r.get(k, '')) for k in ('实体值', '分离出来的实体', '实体/属性值',
                                                '分离出来的属性值', '规则内容')))
                if s_c and o_c and s_c in hay and o_c in hay and pred_hit(f.get('p', ''), r):
                    ok = True
                    break
            if ok:
                f_ret += 1
    n = len(g['units'])
    print(f'  知识单元：完全保留 {ku_ret} / 部分保留 {ku_par} / 未保留 {ku_mis}  (n={n})')
    print(f'    召回率（完全保留）= {ku_ret / n:.1%}；完全+部分 = {(ku_ret + ku_par) / n:.1%}')
    print(f'  原子事实：保留 {f_ret} / {f_tot}  → 召回率 {f_ret / f_tot:.1%}' if f_tot else '  原子事实：无')
    return dict(paper=g['paper'], units=n, facts=f_tot,
                ku_retained=ku_ret, ku_partial=ku_par, ku_missing=ku_mis,
                fact_retained=f_ret,
                ku_recall=ku_ret / n if n else None,
                fact_recall=f_ret / f_tot if f_tot else None)


if __name__ == '__main__':
    res = [score(p) for p in sys.argv[1:]]
    print('\n=== 汇总 ===')
    for r in res:
        print(r)
