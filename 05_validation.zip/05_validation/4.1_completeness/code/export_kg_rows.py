"""Export per-paper DRC-KG rows to CSV — one pass per workbook (fast)."""
import csv
import re
from collections import defaultdict
from pathlib import Path

from openpyxl import load_workbook

BASE = r'1.中英文本体与标注文件成果'
BOOKS = {
    'CN': BASE + r'\中文\1026_中文登革热138篇_分类表汇总.xlsx',
    'EN': BASE + r'\英文\1026_英文登革热123篇_分类表汇总.xlsx',
}
SHEETS = ['01_普通三元组_类', '02_普通三元组_属性', '03_普通三元组_关系',
          '04_规则汇总', '05_传播关系_类', '06_传播关系_属性', '07_传播关系_关系']
EVID_COL = {'01_普通三元组_类': '文字来源', '02_普通三元组_属性': '原文', '03_普通三元组_关系': '文字来源',
            '04_规则汇总': '知识单元（原文）', '05_传播关系_类': '原文', '06_传播关系_属性': '原文',
            '07_传播关系_关系': '文字来源'}
KEEP = ['实体类型', '实体值', '关系', '实体/属性类型', '实体/属性值', '本体关系类型',
        '属性分类', '分离出来的实体', '分离出来的属性值', '规则要素', '规则内容',
        '传播关系实例', '实例角色', '记录角色']

PAPERS = {
    'CN': ['102', '112', '011', '015', '031', '068', '072', '097', '041', '077',
           '082', '059', '089', '078', '019'],
    'EN': ['014', '006', '026', '101', '088', '070', '065', '021', '052', '001',
           '031', '072', '122', '099', '050'],
}

OUT = Path(r'_work\gold_pilot')
OUT.mkdir(parents=True, exist_ok=True)

for lang, path in BOOKS.items():
    wanted = set(PAPERS[lang])
    buckets = defaultdict(list)
    wb = load_workbook(path, read_only=True, data_only=True)
    for sh in SHEETS:
        ws = wb[sh]
        it = ws.iter_rows(values_only=True)
        h = next(it)
        idx = {str(v).strip(): i for i, v in enumerate(h) if v is not None}
        src_col = '文件来源' if '文件来源' in idx else '源文件'
        si = idx[src_col]
        ev = idx.get(EVID_COL[sh])
        for row in it:
            src = str(row[si]).strip() if si < len(row) and row[si] is not None else ''
            m = re.match(r'^(\d{3})', src)
            if not m or m.group(1) not in wanted:
                continue
            d = {k: (str(row[i]).strip() if i < len(row) and row[i] is not None else '')
                 for k, i in idx.items() if k in KEEP}
            d['_sheet'] = sh
            d['_evid'] = (str(row[ev]).strip() if ev is not None and ev < len(row) and row[ev] is not None else '')[:400]
            buckets[m.group(1)].append(d)
    wb.close()
    cols = ['_sheet', '_evid'] + KEEP
    for code, rows in buckets.items():
        p = OUT / f'kg_rows_{lang}_{code}.csv'
        with p.open('w', encoding='utf-8-sig', newline='') as f:
            w = csv.DictWriter(f, fieldnames=cols, extrasaction='ignore')
            w.writeheader()
            w.writerows(rows)
        print(f'{p.name}: {len(rows)} rows')
