"""Aggregate the 30-paper judge JSONs into the 4.1 completeness evidence.

Outputs
  outputs/补充证据_20261104/30篇源侧参考集_判定汇总.csv   每篇 in-scope 计数与召回
  outputs/补充证据_20261104/30篇源侧参考集_总表.json      总体召回与分母
  outputs/独立源侧金标_逐原子事实模板.csv                 逐原子事实 TP/FN 台账（管线可直接算召回）
"""
import csv
import json
from collections import Counter
from pathlib import Path

GOLD = Path(r'_work\gold_pilot')
OUT = Path(r'1104_第四章技术验证_重跑\outputs')
SUP = OUT / '补充证据_20261104'
SUP.mkdir(parents=True, exist_ok=True)

PAPERS = [(p.stem.split('_')[1], p.stem.split('_')[2]) for p in sorted(GOLD.glob('gold_*.json'))]
FIELDS = ['金标ID', '语种', '源文件', 'PDF页码', '位置类型_正文表格图注', '标题块', '原文知识单元',
          '原子事实类型', '头实体', '关系或属性', '尾实体或属性值', '时间归属', '空间归属',
          '原文不确定性限定', '表格分组及单位分母', '核对人1', '核对人2', '结论',
          '是否在现有数据正确表达_TP或FN', '现有标注对应表', '现有标注行号', '争议及整改']

per_paper = []
rows_out = []
agg = Counter()

for lang, code in PAPERS:
    gp = GOLD / f'gold_{lang}_{code}.json'
    jp = GOLD / f'judge_{lang}_{code}.json'
    if not jp.exists():
        per_paper.append(dict(语种=lang, 论文编号=code, 状态='未完成判定'))
        continue
    g = json.loads(gp.read_text(encoding='utf-8'))
    j = json.loads(jp.read_text(encoding='utf-8'))
    uv = {u['id']: u['verdict'] for u in j['units']}
    fv = {f['id']: f['verdict'] for f in j['facts']}
    uc = Counter(uv.values())
    fc = Counter(fv.values())
    per_paper.append(dict(
        语种=lang, 论文编号=code, 状态='已判定',
        知识单元总数=len(g['units']),
        单元_完全保留=uc['retained'], 单元_部分保留=uc['partial'],
        单元_未保留=uc['missing'], 单元_范围外=uc['oos'],
        原子事实总数=sum(len(u['facts']) for u in g['units']),
        事实_TP=fc['TP'], 事实_FN=fc['FN'], 事实_范围外=fc['oos'],
    ))
    for k in ('retained', 'partial', 'missing', 'oos'):
        agg['u_' + k] += uc[k]
    for k in ('TP', 'FN', 'oos'):
        agg['f_' + k] += fc[k]

    seq = 0
    for u in g['units']:
        for n, f in enumerate(u['facts'], start=1):
            seq += 1
            v = fv.get(f"{u['id']}#{n}", 'oos')
            rows_out.append({
                '金标ID': f'GOLD-{lang}-{code}-{seq:04d}',
                '语种': lang, '源文件': g['paper'],
                'PDF页码': '',
                '位置类型_正文表格图注': u.get('location', ''),
                '标题块': u.get('section', ''),
                '原文知识单元': u.get('text', ''),
                '原子事实类型': f.get('type', ''),
                '头实体': f.get('s', ''), '关系或属性': f.get('p', ''), '尾实体或属性值': f.get('o', ''),
                '时间归属': '', '空间归属': '', '原文不确定性限定': '', '表格分组及单位分母': '',
                '核对人1': '', '核对人2': '',
                '结论': 'AI辅助判定（待作者确认）',
                '是否在现有数据正确表达_TP或FN': ('TP' if v == 'TP' else 'FN') if v != 'oos' else '',
                '现有标注对应表': '', '现有标注行号': '',
                '争议及整改': '' if v != 'FN' else 'AI判定未保留；需确认是否为原文未标注',
            })

with (SUP / '30篇源侧参考集_判定汇总.csv').open('w', encoding='utf-8-sig', newline='') as f:
    w = csv.DictWriter(f, fieldnames=list(per_paper[0].keys()) if per_paper else ['语种'])
    w.writeheader()
    w.writerows(per_paper)

if rows_out:
    with (OUT / '独立源侧金标_逐原子事实模板.csv').open('w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, fieldnames=FIELDS, extrasaction='ignore')
        w.writeheader()
        w.writerows(rows_out)

u_den = agg['u_retained'] + agg['u_partial'] + agg['u_missing']
f_den = agg['f_TP'] + agg['f_FN']
summary = {
    '论文数（已判定）': sum(1 for r in per_paper if r.get('状态') == '已判定'),
    '知识单元_分母(in-scope)': u_den,
    '知识单元_完全保留': agg['u_retained'],
    '知识单元_部分保留': agg['u_partial'],
    '知识单元_未保留': agg['u_missing'],
    '知识单元召回率(完全保留)': round(agg['u_retained'] / u_den, 4) if u_den else None,
    '知识单元召回率(完全+部分)': round((agg['u_retained'] + agg['u_partial']) / u_den, 4) if u_den else None,
    '原子事实_分母(in-scope)': f_den,
    '原子事实_TP': agg['f_TP'],
    '原子事实_FN': agg['f_FN'],
    '原子事实召回率': round(agg['f_TP'] / f_den, 4) if f_den else None,
    '排除项_单元': agg['u_oos'], '排除项_事实': agg['f_oos'],
    '论文报告值': {'知识单元召回率': 0.82, '原子事实召回率': 0.68},
    '说明': '由自动化抽取脚本逐篇建立参考集，并与七分表逐条比对得出。',
}
(SUP / '30篇源侧参考集_总表.json').write_text(
    json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')

print(json.dumps(summary, ensure_ascii=False, indent=2))
print(f'\n逐篇: {len(per_paper)} 篇；逐事实台账: {len(rows_out)} 行')
