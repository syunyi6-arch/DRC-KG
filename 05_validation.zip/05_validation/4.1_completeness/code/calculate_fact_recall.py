#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""4.1 Completeness / Fact Recall: final-author-approved binary evaluation.

Run from anywhere:
    python code/calculate_fact_recall.py

Reads the final TP and FN workbooks under reference_set_30, validates record IDs
and mandatory columns, then writes results/4.1_results.xlsx and 4.1_results.csv.
"""
from __future__ import annotations

import csv
from collections import Counter
from pathlib import Path
import re

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font

BASE = Path(__file__).resolve().parent.parent
INPUT = BASE / "reference_set_30"
OUTPUT = BASE / "results"
HEADERS = ["id", "reference_fact", "extracted", "remarks"]
PAPER_PATTERN = re.compile(r"^(CN|EN)\d{3}")
WORKSHEETS = {"TP": ("TP",), "FN": ("FN",)}
NOT_EXTRACTED = {"", "not extracted"}
GROUPS = (("CN", "Chinese (n=15)"), ("EN", "English (n=15)"))


def load_rows(path: Path, candidates: tuple[str, ...]) -> list[dict[str, str]]:
    if not path.is_file():
        raise FileNotFoundError(f"Input does not exist: {path}")
    book = load_workbook(path, read_only=True, data_only=True)
    sheet = next((book[n] for n in candidates if n in book.sheetnames), None)
    if sheet is None:
        raise KeyError(f"{path.name} has none of the worksheets {candidates}")
    rows = list(sheet.iter_rows(values_only=True))
    if not rows or [str(v).strip() for v in rows[0][:4]] != HEADERS:
        raise ValueError(f"Wrong columns in {path.name}; expected {HEADERS}")
    records = []
    for ix, data in enumerate(rows[1:], start=2):
        if data is None or all(v is None or str(v).strip() == "" for v in data):
            continue
        record = {k: ("" if v is None else str(v).strip()) for k, v in zip(HEADERS, data)}
        if not record["id"] or not record["reference_fact"]:
            raise ValueError(f"{path.name}:{ix} lacks a fact ID or reference fact")
        if not PAPER_PATTERN.match(record["id"]):
            raise ValueError(f"{path.name}:{ix} unrecognized fact ID: {record['id']}")
        records.append(record)
    return records


def add_sheet(book: Workbook, title: str, header: list[str], rows: list[list],
              widths: dict[str, int], pct_column: str | None = None):
    sheet = book.create_sheet(title)
    sheet.append(header)
    for row in rows:
        sheet.append(row)
    for cell in sheet[1]:
        cell.font = Font(bold=True)
    for column, width in widths.items():
        sheet.column_dimensions[column].width = width
    sheet.freeze_panes = "A2"
    if pct_column and rows:
        for row_ix in range(2, len(rows) + 2):
            sheet[f"{pct_column}{row_ix}"].number_format = "0.00%"
    return sheet


def main() -> None:
    tp = load_rows(INPUT / "4.1_final_TP_table.xlsx", WORKSHEETS["TP"])
    fn = load_rows(INPUT / "4.1_final_FN_table.xlsx", WORKSHEETS["FN"])
    ids_tp = [r["id"] for r in tp]
    ids_fn = [r["id"] for r in fn]
    if len(set(ids_tp)) != len(ids_tp) or len(set(ids_fn)) != len(ids_fn):
        raise ValueError("Duplicate fact IDs found in input tables")
    if set(ids_tp) & set(ids_fn):
        raise ValueError("Some fact IDs appear in both TP and FN tables")
    for r in tp:
        if r["extracted"] in NOT_EXTRACTED:
            raise ValueError(f"TP without an extracted representation: {r['id']}")
    for r in fn:
        if r["extracted"] not in NOT_EXTRACTED:
            raise ValueError(f"FN with a non-empty extracted value: {r['id']}")

    group_tp = Counter(r["id"][:2] for r in tp)
    group_fn = Counter(r["id"][:2] for r in fn)
    by_paper_tp = Counter(r["id"][:5] for r in tp)
    by_paper_fn = Counter(r["id"][:5] for r in fn)

    result: list[list] = []
    for lang, label in GROUPS:
        tp_n, fn_n = group_tp[lang], group_fn[lang]
        result.append([label, tp_n, fn_n, tp_n + fn_n, tp_n / (tp_n + fn_n) if tp_n + fn_n else 0])
    total = len(tp) + len(fn)
    result.append(["Overall (n=30)", len(tp), len(fn), total, len(tp) / total if total else 0])

    papers: list[list] = []
    for paper in sorted(set(by_paper_tp) | set(by_paper_fn)):
        tp_n, fn_n = by_paper_tp[paper], by_paper_fn[paper]
        papers.append([paper, tp_n, fn_n, tp_n + fn_n, tp_n / (tp_n + fn_n) if tp_n + fn_n else 0])

    notes = [
        ["counting unit", "final, deduplicated reference-fact records keyed by their ID"],
        ["TP verdict", "the reference fact has a corresponding representation in the final extraction records"],
        ["FN verdict", "no corresponding representation was found; the extracted column carries the not-extracted flag"],
        ["recall", "TP / (TP + FN)"],
        ["excluded items", "author-excluded records are absent from both tables and never enter the denominator"],
        ["deduplication", "the TP table is already deduplicated; a duplicate ID across both tables raises an error"],
        ["result provenance", "the authors' final binary adjudication, not an independent third-party re-verification"],
    ]

    wb = Workbook()
    wb.remove(wb.active)
    add_sheet(wb, "Overall", ["group", "TP", "FN", "eligible_facts", "recall"], result,
              {"A": 22, "B": 10, "C": 10, "D": 16, "E": 12}, pct_column="E")
    add_sheet(wb, "Per-paper", ["paper", "TP", "FN", "eligible_facts", "recall"], papers,
              {"A": 12, "B": 10, "C": 10, "D": 16, "E": 12}, pct_column="E")
    add_sheet(wb, "Notes", ["item", "note"], notes, {"A": 22, "B": 110})

    OUTPUT.mkdir(parents=True, exist_ok=True)
    dest = OUTPUT / "4.1_results.xlsx"
    wb.save(dest)
    with (OUTPUT / "4.1_results.csv").open("w", encoding="utf-8-sig", newline="") as fp:
        writer = csv.writer(fp)
        writer.writerow(["group", "TP", "FN", "eligible_facts", "recall"])
        for row in result:
            writer.writerow([row[0], row[1], row[2], row[3], f"{row[4]:.6f}"])
    print(f"TP={len(tp)}, FN={len(fn)}, Recall={len(tp) / total:.6%}")
    print(f"Wrote: {dest}")


if __name__ == "__main__":
    main()
