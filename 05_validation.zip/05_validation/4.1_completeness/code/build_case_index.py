# -*- coding: utf-8 -*-
"""Build the 261-paper DRC-KG outbreak country-year index from the annotation corpus.

The output `case_index_review.csv` uses the exact schema consumed by
1030_DRC-KG_OpenDengue_外部覆盖率分析.py:

    paper_id,file_source,country_iso3,outbreak_start_year,outbreak_end_year,review_status,notes

This builder produces a DETERMINISTIC FIRST PASS. Rows it cannot resolve are left
`pending` and exported to `resolution_worklist.csv`. A review pass writes
`case_index_overrides.csv`; rerun with --overrides to merge reviewed decisions.

Hard rules encoded here:
  * outbreak year != publication year (English filenames are NNN_<pubyear>_<title>)
  * imported/overseas cases are FLAGGED, never silently mapped to the import-source country
  * full-width digits are NFKC-normalised
  * the spine is the numeric prefix (138 CN + 123 EN = 261), never the 279-row
    provenance column of the aggregate workbook.

Requirements: Python >=3.9. python-docx only for the abstract fallback.
"""
import argparse
import csv
import importlib.util
import json
import re
import sys
import unicodedata
import zipfile
import xml.etree.ElementTree as ET
from pathlib import Path

NS = '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
INDEX_COLUMNS = ['paper_id', 'file_source', 'country_iso3',
                 'outbreak_start_year', 'outbreak_end_year', 'review_status', 'notes']
REVIEWED = {'reviewed', 'confirmed', 'yes', 'true', '已确认', '确认', '1'}
CN_BLOCKS = {'摘要', '中文摘要', 'abstract'}
EN_BLOCKS = {'abstract', 'summary'}
IMPORTED_RE = re.compile(r'输入|境外|传入|外来|imported|importation|autochthonous|'
                         r'introduced|travel[- ]associated|overseas', re.I)


def load_1030(path):
    spec = importlib.util.spec_from_file_location('dengue_1030', str(path))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def norm(s):
    return unicodedata.normalize('NFKC', str(s or '')).strip()


def dedupe_text(s, max_chars=4000):
    parts = re.split(r'(?<=[。！？.!?])\s*', str(s or ''))
    seen, out = set(), []
    for p in parts:
        p = p.strip()
        if not p:
            continue
        key = p[:48]
        if key in seen:
            continue
        seen.add(key)
        out.append(p)
        if sum(len(x) for x in out) >= max_chars:
            break
    return ' '.join(out)


def read_sheets(path, only=None):
    """Return {sheet_name: [[cell,...],...]} with header as first row (stdlib only)."""
    wanted = {norm(x).lower() for x in (only or [])}
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        shared = []
        if 'xl/sharedStrings.xml' in names:
            with z.open('xl/sharedStrings.xml') as f:
                for _, el in ET.iterparse(f, events=('end',)):
                    if el.tag == NS + 'si':
                        shared.append(''.join(t.text or '' for t in el.iter(NS + 't')))
                        el.clear()
        wb = ET.fromstring(z.read('xl/workbook.xml'))
        rels = ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
        rid2t = {r.attrib['Id']: r.attrib['Target'] for r in rels}
        rns = '{http://schemas.openxmlformats.org/officeDocument/2006/relationships}'
        sheets = []
        for sh in wb.find(NS + 'sheets'):
            name = sh.attrib['name']
            if wanted and norm(name).lower() not in wanted:
                continue
            tgt = rid2t.get(sh.attrib.get(rns + 'id'), '').lstrip('/')
            if tgt:
                sheets.append((name, tgt if tgt.startswith('xl/') else 'xl/' + tgt))
        out = {}
        for name, tgt in sheets:
            rows = []
            with z.open(tgt) as f:
                for _, row in ET.iterparse(f, events=('end',)):
                    if row.tag != NS + 'row':
                        continue
                    vals = {}
                    for c in row.findall(NS + 'c'):
                        m = re.match('[A-Z]+', c.attrib.get('r', 'A1'))
                        if not m:
                            continue
                        col = 0
                        for ch in m.group():
                            col = col * 26 + ord(ch) - 64
                        v = c.find(NS + 'v')
                        t = c.attrib.get('t')
                        if t == 'inlineStr':
                            val = ''.join(x.text or '' for x in c.iter(NS + 't'))
                        elif v is None:
                            val = ''
                        elif t == 's':
                            idx = int(v.text)
                            val = shared[idx] if idx < len(shared) else ''
                        else:
                            val = v.text or ''
                        vals[col] = str(val).strip()
                    if vals:
                        rows.append([vals.get(i, '') for i in range(1, max(vals) + 1)])
                    row.clear()
            out[name] = rows
        return out


def header_index(header, names):
    for i, h in enumerate(header):
        if norm(h) in names:
            return i
    return None


def discover_spine(root):
    papers = []
    for lang, folder, docdir in [('CN', '中文', '中文138篇'), ('EN', '英文', '英文123篇')]:
        base = root / folder / '分类_七表'
        files = sorted(base.glob('*.xlsx'))
        for f in files:
            m = re.match(r'^(\d{3})_(.*)$', f.stem)
            if not m:
                continue
            num = int(m.group(1))
            docx = root / docdir / (f.stem + '.docx')
            papers.append({
                'paper_id': f'{lang}{num:03d}',
                'lang': lang,
                'num': num,
                'file_source': f.stem,
                'xlsx_path': f,
                'docx_path': docx if docx.exists() else None,
                'title': '', 'abstract': '', 'body': '',
            })
    return papers


def prefix_key(s):
    m = re.match(r'^(\d{3})', norm(s))
    return m.group(1) if m else None


def load_reannotation(root):
    """Per-prefix title + abstract + body from the reannotation workbooks."""
    texts = {}
    for lang, path in [('CN', root / '中文' / '1026_中文登革热138篇_重新标注整合_未分类.xlsx'),
                       ('EN', root / '英文' / '1026_英文登革热123篇_重新标注整合_未分类.xlsx')]:
        if not path.exists():
            continue
        sheets = read_sheets(path, only=['三元组'])
        rows = next(iter(sheets.values()), [])
        if not rows:
            continue
        h = rows[0]
        i_src = header_index(h, {'源文件'})
        i_title = header_index(h, {'研究案例'})
        i_blk = header_index(h, {'标题块'})
        i_txt = header_index(h, {'知识单元原文内容'})
        if i_src is None or i_txt is None:
            continue
        blocks = CN_BLOCKS if lang == 'CN' else EN_BLOCKS
        by = {}
        for r in rows[1:]:
            if len(r) <= max(i_src, i_txt):
                continue
            key = prefix_key(r[i_src])
            if not key:
                continue
            d = by.setdefault(key, {'title': '', 'abstract': [], 'body': [], 'seen': set()})
            if i_title is not None and len(r) > i_title and r[i_title] and not d['title']:
                title = norm(r[i_title])
                if lang == 'CN' and '_' in title:
                    title = title.rsplit('_', 1)[0]
                d['title'] = title
            blk = norm(r[i_blk]).lower() if i_blk is not None and len(r) > i_blk else ''
            txt = norm(r[i_txt])
            if not txt:
                continue
            sig = txt[:80]
            if sig in d['seen']:
                continue
            d['seen'].add(sig)
            d['body'].append(txt)
            if blk in blocks:
                d['abstract'].append(txt)
        for key, d in by.items():
            texts[(lang, key)] = {
                'title': d['title'],
                'abstract': dedupe_text(' '.join(d['abstract']), 4000),
                'body': dedupe_text(' '.join(d['body']), 6000),
            }
    return texts


def load_structured(root):
    """Per-prefix 行政区域 / 时间段 / 时间点 / event-time / travel evidence."""
    ev = {}
    for lang, path in [('CN', root / '中文' / '1026_中文登革热138篇_分类表汇总.xlsx'),
                       ('EN', root / '英文' / '1026_英文登革热123篇_分类表汇总.xlsx')]:
        if not path.exists():
            continue
        sheets = read_sheets(path, only=['01_普通三元组_类', '02_普通三元组_属性'])
        s1 = sheets.get('01_普通三元组_类', [])
        if s1:
            h = s1[0]
            i_ty = header_index(h, {'实体类型'})
            i_val = header_index(h, {'实体值'})
            i_src = header_index(h, {'文件来源'})
            if None not in (i_ty, i_val, i_src):
                for r in s1[1:]:
                    if len(r) <= max(i_ty, i_val, i_src):
                        continue
                    key = prefix_key(r[i_src])
                    if not key:
                        continue
                    d = ev.setdefault((lang, key), {'admin': [], 'span': [], 'point': []})
                    ty = norm(r[i_ty])
                    val = norm(r[i_val])
                    if not val:
                        continue
                    if ty == '行政区域' and len(d['admin']) < 40:
                        d['admin'].append(val)
                    elif ty == '时间段' and len(d['span']) < 30:
                        d['span'].append(val)
                    elif ty == '时间点' and len(d['point']) < 30:
                        d['point'].append(val)
        s2 = sheets.get('02_普通三元组_属性', [])
        if s2:
            h = s2[0]
            i_cat = header_index(h, {'属性分类'})
            i_av = header_index(h, {'分离出来的属性值'})
            i_src = header_index(h, {'源文件'})
            keep = {'事件发生时间', '时间值', '开始时间值', '结束时间值', '旅行居住史'}
            if None not in (i_cat, i_av, i_src):
                for r in s2[1:]:
                    if len(r) <= max(i_cat, i_av, i_src):
                        continue
                    key = prefix_key(r[i_src])
                    cat = norm(r[i_cat])
                    if not key or cat not in keep:
                        continue
                    d = ev.setdefault((lang, key), {'admin': [], 'span': [], 'point': []})
                    val = norm(r[i_av])
                    if not val:
                        continue
                    if cat == '旅行居住史':
                        d.setdefault('travel', []).append(val)
                    else:
                        d.setdefault('event', []).append(val)
    return ev


def docx_abstract(path):
    try:
        import docx  # python-docx
    except Exception:
        return ''
    try:
        doc = docx.Document(str(path))
    except Exception:
        return ''
    paras = [p.text.strip() for p in doc.paragraphs if p.text and p.text.strip()]
    text = '\n'.join(paras)
    if not text:
        return ''
    low = text.lower()
    for marker in ('摘要', 'abstract'):
        i = low.find(marker.lower())
        if i >= 0:
            return norm(text[i:i + 1800])
    return norm(text[:1800])


def find_years(text):
    return [int(m.group(0)) for m in re.finditer(r'(?<!\d)((?:19|20)\d{2})(?!\d)', norm(text))]


def find_range(text):
    t = norm(text)
    m = re.search(r'((?:19|20)\d{2})\s*[-–—~至到]\s*((?:19|20)?\d{2})', t)
    if not m:
        return None
    a = int(m.group(1))
    b = m.group(2)
    b = int(b) if len(b) == 4 else int(str(a)[:2] + b.zfill(2))
    if 1900 <= a <= 2100 and a <= b <= a + 30:
        return a, b
    return None


def parse_title(paper):
    stem = paper['file_source']
    pub = None
    title = stem[4:]
    if paper['lang'] == 'EN':
        m = re.match(r'^(\d{3})_(\d{4})_(.*)$', stem)
        if m:
            pub = int(m.group(2))
            title = m.group(3)
    else:
        m = re.match(r'^(\d{3})_(.*)_([^_]*)$', stem)
        if m:
            title = m.group(2)
    return norm(title), pub


def split_sentences(text):
    t = norm(text)
    parts = re.split(r'(?<=[。！？.!?;；])\s*|\n+', t)
    return [p.strip() for p in parts if p.strip()]


def first_outbreak_sentence(text):
    for s in split_sentences(text):
        if re.search(r'登革|dengue|暴发|outbreak|疫情|epidemic', s, re.I) and find_years(s):
            return s
    for s in split_sentences(text):
        if find_years(s):
            return s
    return ''


def load_gazetteer(path, odk_names):
    gaz = {}
    for name, iso in odk_names.items():
        gaz[norm(name).lower()] = (iso, 'country')
    if path.exists():
        with open(path, encoding='utf-8-sig', newline='') as f:
            for row in csv.DictReader(f):
                a = norm(row.get('alias'))
                iso = norm(row.get('iso3')).upper()
                if a and len(iso) == 3:
                    gaz[a.lower()] = (iso, norm(row.get('alias_type')) or 'alias')
    return gaz


def match_countries(text, gaz):
    t = norm(text)
    low = t.lower()
    hits = []
    for alias, (iso, typ) in gaz.items():
        if not alias:
            continue
        if alias.isascii():
            if re.search(r'(?<![a-z])' + re.escape(alias) + r'(?![a-z])', low):
                hits.append((iso, typ, alias))
        elif alias in t:
            hits.append((iso, typ, alias))
    # keep first occurrence order, dedupe iso keeping the longest alias match
    seen = {}
    for iso, typ, alias in hits:
        prev = seen.get(iso)
        if prev is None or len(alias) > len(prev[2]):
            seen[iso] = (iso, typ, alias)
    return [seen[k] for k in seen]


def choose_year(title, abstract, pub, lang):
    tr = find_range(title)
    if tr:
        return tr[0], tr[1], 'title_range'
    ty = find_years(title)
    if ty:
        if pub is not None and lang == 'EN':
            others = [y for y in ty if y != pub]
            y = others[-1] if others else ty[-1]
        else:
            y = ty[0]
        return y, y, 'title_year'
    s = first_outbreak_sentence(abstract)
    if s:
        r = find_range(s)
        if r:
            return r[0], r[1], 'abstract_range'
        ys = find_years(s)
        if ys:
            return ys[0], ys[0], 'abstract_year'
    return None, None, ''


def build_candidate(paper, text, struct, gaz, odk_iso):
    title = text.get('title') or paper['title']
    abstract = text.get('abstract') or ''
    body = text.get('body') or ''
    if not abstract and body:
        abstract = first_outbreak_sentence(body) or body[:1200]
    if not abstract and paper['docx_path']:
        abstract = docx_abstract(paper['docx_path'])
    paper['title'] = title

    manual_title, pub = parse_title(paper)
    if not title:
        title = manual_title
    flags = []
    imported = bool(IMPORTED_RE.search(title) or IMPORTED_RE.search(abstract[:1400]))
    if imported:
        flags.append('imported_case')

    # Country: title first, then abstract, then structured admin regions.
    t_hits = match_countries(title, gaz)
    src = 'title'
    if not t_hits:
        t_hits = match_countries(first_outbreak_sentence(abstract) or abstract[:600], gaz)
        src = 'abstract'
    if not t_hits:
        admin = ' ; '.join(struct.get('admin', [])[:12])
        t_hits = match_countries(admin, gaz)
        src = 'admin_region'
        if t_hits:
            flags.append('admin_region_only')
    isos = []
    for iso, typ, alias in t_hits:
        if iso not in isos:
            isos.append(iso)
    if paper['lang'] == 'CN' and not isos and not imported:
        isos = ['CHN']
        src = 'cn_default'
        flags.append('cn_default')
    if len(isos) > 1:
        flags.append('multi_country')

    y0, y1, ysrc = choose_year(title, abstract, pub, paper['lang'])
    if y0 is None and struct.get('event'):
        for v in struct['event']:
            ys = find_years(v)
            if ys:
                y0 = y1 = ys[0]
                ysrc = 'event_attribute'
                break
    if y0 is None:
        flags.append('no_year')
    if pub is not None and y0 is not None and y0 == pub:
        flags.append('title_eq_pub')

    iso = isos[0] if isos else ''
    in_odk = iso in odk_iso
    if iso and not in_odk:
        flags.append('iso_not_in_opendengue')
    if y0 is not None and iso and (iso, y0) not in odk_pairs and in_odk:
        flags.append('year_not_in_country_baseline')

    blocking = {'imported_case', 'multi_country', 'no_year', 'title_eq_pub',
                'admin_region_only', 'iso_not_in_opendengue', 'cn_default'}
    if iso and y0 and not (blocking & set(flags)):
        conf = 'high'
    elif iso and y0:
        conf = 'medium'
    else:
        conf = 'low'

    return {
        'paper_id': paper['paper_id'], 'lang': paper['lang'],
        'file_source': paper['file_source'], 'title': title, 'pub_year': pub or '',
        'cand_iso3': iso,
        'outbreak_start_year': y0 or '', 'outbreak_end_year': y1 or '',
        'evidence_source': src + ('/' + ysrc if ysrc else ''),
        'evidence_snippet': (first_outbreak_sentence(abstract) or abstract[:220]),
        'abstract_head': abstract[:700],
        'confidence': conf, 'flags': '|'.join(flags),
        'admin_regions': ' | '.join(list(dict.fromkeys(struct.get('admin', [])))[:15]),
        'time_spans': ' | '.join(list(dict.fromkeys(struct.get('span', [])))[:15]),
        'event_times': ' | '.join(list(dict.fromkeys(struct.get('event', [])))[:15]),
        'travel': ' | '.join(list(dict.fromkeys(struct.get('travel', [])))[:15]),
    }


def load_overrides(path):
    out = {}
    if not path or not path.exists():
        return out
    with open(path, encoding='utf-8-sig', newline='') as f:
        for row in csv.DictReader(f):
            pid = norm(row.get('paper_id'))
            if not pid:
                continue
            out.setdefault(pid, []).append(row)
    return out


def status_for(cand, override=None):
    if override:
        if norm(override.get('status')).lower() in REVIEWED:
            return 'reviewed'
        return 'pending'
    if cand['confidence'] == 'high':
        return 'reviewed'
    return 'pending'


def write_csv(path, rows, fields):
    with open(path, 'w', newline='', encoding='utf-8-sig') as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction='ignore')
        w.writeheader()
        w.writerows(rows)


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    here = Path(__file__).resolve().parent
    ap.add_argument('--root', type=Path, default=here.parent)
    ap.add_argument('--opendengue', type=Path, default=here / 'National_extract_V1_3.csv')
    ap.add_argument('--gazetteer', type=Path, default=here / 'country_gazetteer.csv')
    ap.add_argument('--outdir', type=Path, default=here / 'case_index')
    ap.add_argument('--overrides', type=Path, default=None)
    ap.add_argument('--start-year', type=int, default=1963)
    ap.add_argument('--end-year', type=int, default=2025)
    args = ap.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)

    m1030 = load_1030(here / '1030_DRC-KG_OpenDengue_外部覆盖率分析.py')
    od = m1030.open_dengue(args.opendengue, args.start_year, args.end_year)
    odk_iso = {iso for iso, _ in od['pairs']}
    odk_names = {v: k for k, v in od['country_names'].items()}
    global odk_pairs
    odk_pairs = od['pairs']
    gaz = load_gazetteer(args.gazetteer, odk_names)

    spine = discover_spine(args.root)
    cn = sum(1 for p in spine if p['lang'] == 'CN')
    en = sum(1 for p in spine if p['lang'] == 'EN')
    if (cn, en) != (138, 123):
        raise SystemExit(f'SPINE ERROR: expected 138 CN + 123 EN, got {cn} + {en}')
    if len({p['paper_id'] for p in spine}) != 261:
        raise SystemExit('SPINE ERROR: paper_id not unique / not 261')

    texts = load_reannotation(args.root)
    struct = load_structured(args.root)
    overrides = load_overrides(args.overrides)

    candidates, review_rows, worklist = [], [], []
    for p in spine:
        text = texts.get((p['lang'], f'{p["num"]:03d}'), {})
        st = struct.get((p['lang'], f'{p["num"]:03d}'), {})
        cand = build_candidate(p, text, st, gaz, odk_iso)
        candidates.append(cand)
        ov = overrides.get(p['paper_id'])
        if ov:
            for o in ov:
                review_rows.append({
                    'paper_id': p['paper_id'], 'file_source': p['file_source'],
                    'country_iso3': norm(o.get('country_iso3')).upper(),
                    'outbreak_start_year': norm(o.get('start')),
                    'outbreak_end_year': norm(o.get('end')) or norm(o.get('start')),
                    'review_status': status_for(cand, o),
                    'notes': 'override: ' + norm(o.get('rationale')),
                })
            continue
        review_rows.append({
            'paper_id': p['paper_id'], 'file_source': p['file_source'],
            'country_iso3': cand['cand_iso3'],
            'outbreak_start_year': cand['outbreak_start_year'],
            'outbreak_end_year': cand['outbreak_end_year'],
            'review_status': status_for(cand),
            'notes': f"auto:{cand['evidence_source']}|conf={cand['confidence']}|"
                     f"pub={cand['pub_year']}|flags={cand['flags']}",
        })
        if status_for(cand) != 'reviewed' or cand['flags']:
            worklist.append({
                'paper_id': p['paper_id'], 'lang': p['lang'],
                'file_source': p['file_source'], 'title': cand['title'],
                'cand_iso3': cand['cand_iso3'],
                'start': cand['outbreak_start_year'], 'end': cand['outbreak_end_year'],
                'confidence': cand['confidence'], 'flags': cand['flags'],
                'evidence': cand['evidence_snippet'],
            })

    cand_fields = ['paper_id', 'lang', 'file_source', 'title', 'pub_year', 'cand_iso3',
                   'outbreak_start_year', 'outbreak_end_year', 'evidence_source',
                   'evidence_snippet', 'abstract_head', 'confidence', 'flags', 'admin_regions',
                   'time_spans', 'event_times', 'travel']
    write_csv(args.outdir / 'case_index_candidates.csv', candidates, cand_fields)
    write_csv(args.outdir / 'case_index_review.csv', review_rows, INDEX_COLUMNS)
    write_csv(args.outdir / 'paper_text_compact.csv', candidates,
              ['paper_id', 'lang', 'file_source', 'title', 'pub_year', 'cand_iso3',
               'outbreak_start_year', 'outbreak_end_year', 'evidence_snippet', 'abstract_head',
               'admin_regions', 'time_spans', 'event_times', 'travel'])
    write_csv(args.outdir / 'resolution_worklist.csv', worklist,
              ['paper_id', 'lang', 'file_source', 'title', 'cand_iso3', 'start', 'end',
               'confidence', 'flags', 'evidence'])

    reviewed_papers = {r['paper_id'] for r in review_rows
                       if r['review_status'] in REVIEWED and len(str(r['country_iso3'])) == 3
                       and str(r['outbreak_start_year']).strip()}
    report = {
        'spine_cn': cn, 'spine_en': en, 'spine_total': len(spine),
        'candidate_rows': len(candidates), 'review_rows': len(review_rows),
        'reviewed_papers': len(reviewed_papers), 'pending_papers': 261 - len(reviewed_papers),
        'worklist_rows': len(worklist),
        'override_papers': len(overrides),
        'odk_countries': len(odk_iso), 'odk_country_years': len(od['pairs']),
        'warnings': od['warnings'],
    }
    with open(args.outdir / 'validation_report.json', 'w', encoding='utf-8') as f:
        json.dump(report, f, indent=2, ensure_ascii=False)
    print(json.dumps(report, indent=2, ensure_ascii=False))


if __name__ == '__main__':
    main()
