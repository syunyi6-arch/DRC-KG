"""Flatten blind gold JSONs into the pipeline's 逐原子事实 template, with TP/FN filled by the matcher.

Output: 1104_第四章技术验证_重跑/outputs/独立源侧金标_逐原子事实模板.csv
The pipeline's --stage score then computes 完整源侧召回率 from the TP/FN column.
"""
import csv
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from gold_recall import clean, load_paper_rows, pred_hit  # noqa: E402

OUT = Path(r'1104_第四章技术验证_重跑\outputs\独立源侧金标_逐原子事实模板.csv')
FIELDS = ['金标ID', '语种', '源文件', 'PDF页码', '位置类型_正文表格图注', '标题块', '原文知识单元',
          '原子事实类型', '头实体', '关系或属性', '尾实体或属性值', '时间归属', '空间归属',
          '原文不确定性限定', '表格分组及单位分母', '核对人1', '核对人2', '结论',
          '是否在现有数据正确表达_TP或FN', '现有标注对应表', '现有标注行号', '争议及整改']


def best_row(f, rows):
    s_c, o_c = clean(f.get('s', '')), clean(f.get('o', ''))
    best = None
    best_score = -1
    for r in rows:
        hay = clean(r['_evid'] + ' ' + ' '.join(
            str(r.get(k, '')) for k in ('实体值', '分离出来的实体', '实体/属性值',
                                        '分离出来的属性值', '规则内容')))
        s_hit = 1 if (s_c and s_c in hay) else 0
        o_hit = 1 if (o_c and o_c in hay) else 0
        p_hit = 1 if pred_hit(f.get('p', ''), r) else 0
        sc = s_hit * 2 + o_hit * 2 + p_hit
        if sc > best_score:
            best_score, best = sc, r
    return best, best_score


def main(paths):
    rows_out = []
    total = tp = 0
    for p in paths:
        g = json.loads(Path(p).read_text(encoding='utf-8'))
        lang, code = g['lang'], g['paper'][:3]
        drows = load_paper_rows(lang, code)
        n = 0
        for u in g['units']:
            for f in u['facts']:
                n += 1
                total += 1
                row, sc = best_row(f, drows) if drows else (None, -1)
                ok = sc >= 4 and pred_hit(f.get('p', ''), row)
                # sc>=4 means subject(2)+object(2) both found in the same row
                if ok:
                    tp += 1
                rows_out.append({
                    '金标ID': f'GOLD-{lang}-{code}-{n:04d}',
                    '语种': lang,
                    '源文件': g['paper'],
                    'PDF页码': '',
                    '位置类型_正文表格图注': u.get('location', ''),
                    '标题块': u.get('section', ''),
                    '原文知识单元': u.get('text', ''),
                    '原子事实类型': f.get('type', ''),
                    '头实体': f.get('s', ''),
                    '关系或属性': f.get('p', ''),
                    '尾实体或属性值': f.get('o', ''),
                    '时间归属': '', '空间归属': '', '原文不确定性限定': '',
                    '表格分组及单位分母': '',
                    '核对人1': '', '核对人2': '',
                    '结论': '机械匹配（待确认）',
                    '是否在现有数据正确表达_TP或FN': 'TP' if ok else 'FN',
                    '现有标注对应表': row['_sheet'] if ok else '',
                    '现有标注行号': '',
                    '争议及整改': '' if ok else '机械匹配未命中；需确认是原文未标注还是匹配口径差异',
                })
    OUT.parent.mkdir(parents=True, exist_ok=True)
    with OUT.open('w', encoding='utf-8-sig', newline='') as fh:
        w = csv.DictWriter(fh, fieldnames=FIELDS)
        w.writeheader()
        w.writerows(rows_out)
    print(f'wrote {OUT}: {len(rows_out)} 原子事实，TP={tp} FN={len(rows_out) - tp} '
          f'（机械召回率 {tp / len(rows_out):.1%}）' if rows_out else 'empty')


if __name__ == '__main__':
    main(sys.argv[1:])
