"""Recompute the TR cross-table structure statistics from the seven-sheet annotation workbooks.

A TR code is the transmission-relation instance identifier used by sheets 05, 06 and 07. For every code
the script counts in which of the three sheets it appears, whether it is reused by more than one source
file, and how many codes are missing from each sheet.

Writes results/transmission_structure_statistics.json.
"""
import json
import os
from collections import defaultdict

from openpyxl import load_workbook

HERE = os.path.dirname(os.path.abspath(__file__))
BASE = os.path.join(HERE, '..', '..', '..', '02_annotations')
OUT = os.path.join(HERE, '..', 'results', 'transmission_structure_statistics.json')

FILES = {
    'CN': os.path.join(BASE, 'CN_138_classification_tables_ontology-zh.xlsx'),
    'EN': os.path.join(BASE, 'EN_123_classification_tables_ontology-zh.xlsx'),
}

# sheet number -> English label used in the output, and the 0-based positions of the TR code column and
# of the source-file column in that sheet
SHEETS = {
    '05': ('05_transmission_class', 4, 3),
    '06': ('06_transmission_attribute', 6, 5),
    '07': ('07_transmission_relation', 8, 6),
}

report = {}
for lang, path in FILES.items():
    wb = load_workbook(path, read_only=True, data_only=True)
    by_number = {ws.title.split('_')[0]: ws for ws in wb.worksheets}
    codes = defaultdict(lambda: defaultdict(int))       # code -> sheet number -> row count
    papers = defaultdict(set)                            # code -> source files using it

    for number, (label, code_col, file_col) in SHEETS.items():
        ws = by_number[number]
        rows = ws.iter_rows(values_only=True)
        header = next(rows)
        if len(header) <= max(code_col, file_col):
            raise SystemExit(f'{ws.title}: unexpected header width {len(header)}')
        for row in rows:
            if code_col >= len(row):
                continue
            code = row[code_col]
            if not code:
                continue
            code = str(code).strip()
            codes[code][number] += 1
            if file_col < len(row) and row[file_col]:
                papers[code].add(str(row[file_col]).strip())
    wb.close()

    n = len(codes)
    labels = {number: label for number, (label, _, _) in SHEETS.items()}
    present = {labels[number]: sum(1 for c in codes if codes[c][number]) for number in SHEETS}
    missing = {labels[number]: n - present[labels[number]] for number in SHEETS}
    multi = [c for c in codes if len(papers[c]) > 1]
    absent_total = sum(missing.values())
    report[lang] = dict(
        codes=n, rows_per_sheet=present, missing_per_sheet=missing,
        absent_total=absent_total, multi_paper=len(multi),
        absent_plus_multi=absent_total + len(multi),
        only_class=sum(1 for c in codes if codes[c]['05'] and not codes[c]['07']),
        no_class=sum(1 for c in codes if not codes[c]['05']),
        no_attr=sum(1 for c in codes if not codes[c]['06']),
        no_rel=sum(1 for c in codes if not codes[c]['07']),
    )

report['TOTAL'] = {k: report['CN'][k] + report['EN'][k] for k in
                   ('codes', 'absent_total', 'multi_paper', 'absent_plus_multi',
                    'no_class', 'no_attr', 'no_rel')}

with open(OUT, 'w', encoding='utf-8', newline='\n') as fh:
    json.dump(report, fh, ensure_ascii=False, indent=2)
    fh.write('\n')

print('wrote', os.path.relpath(OUT, os.path.join(HERE, '..')))
