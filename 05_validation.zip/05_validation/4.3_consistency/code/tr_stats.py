"""Recompute TR cross-table structure statistics from the seven-sheet annotation workbooks."""
import csv
import json
import os
from collections import Counter, defaultdict
from openpyxl import load_workbook

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', '..', '02_annotations')
FILES = {
    'CN': os.path.join(BASE, 'CN_138_classification_tables_ontology-zh.xlsx'),
    'EN': os.path.join(BASE, 'EN_123_classification_tables_ontology-zh.xlsx'),
}
SHEETS = ['05_传播关系_类', '06_传播关系_属性', '07_传播关系_关系']

report = {}
for lang, path in FILES.items():
    wb = load_workbook(path, read_only=True, data_only=True)
    codes = defaultdict(lambda: defaultdict(int))   # code -> sheet -> rows
    papers = defaultdict(set)
    srcfield = {'05_传播关系_类': 3, '06_传播关系_属性': 5, '07_传播关系_关系': 6}
    for sh in SHEETS:
        ws = wb[sh]
        rows = ws.iter_rows(values_only=True)
        h = next(rows)
        idx = {str(v).strip(): i for i, v in enumerate(h) if v is not None}
        icode = idx.get('传播关系实例')
        isrc = idx.get('源文件')
        for row in rows:
            if icode is None or icode >= len(row):
                continue
            code = row[icode]
            if not code:
                continue
            code = str(code).strip()
            codes[code][sh] += 1
            if isrc is not None and isrc < len(row) and row[isrc]:
                papers[code].add(str(row[isrc]).strip())
    wb.close()

    n = len(codes)
    has = {sh: sum(1 for c in codes if codes[c][sh]) for sh in SHEETS}
    multi = [c for c in codes if len(papers[c]) > 1]
    missing = {sh: n - has[sh] for sh in SHEETS}
    # "conflict or missing link": per-code per-sheet absence + cross-paper reuse
    absent_total = sum(missing.values())
    report[lang] = dict(
        codes=n, rows_per_sheet=has, missing_per_sheet=missing,
        absent_total=absent_total, multi_paper=len(multi),
        absent_plus_multi=absent_total + len(multi),
        only_class=sum(1 for c in codes if codes[c][SHEETS[0]] and not codes[c][SHEETS[2]]),
        no_class=sum(1 for c in codes if not codes[c][SHEETS[0]]),
        no_attr=sum(1 for c in codes if not codes[c][SHEETS[1]]),
        no_rel=sum(1 for c in codes if not codes[c][SHEETS[2]]),
    )
    if lang == 'CN':
        cn_codes = codes

tot = {k: report['CN'][k] + report['EN'][k] for k in
       ('codes', 'absent_total', 'multi_paper', 'absent_plus_multi', 'no_class', 'no_attr', 'no_rel')}
report['TOTAL'] = tot
print(json.dumps(report, ensure_ascii=False, indent=2))
