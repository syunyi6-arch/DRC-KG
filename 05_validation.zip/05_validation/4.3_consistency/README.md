# 4.3 Consistency

```text
4.3_consistency/
├── README.md
├── code/
│   └── tr_stats.py
├── results/
│   ├── rdf_shacl_statistics.json
│   ├── shacl_validation_report.txt
│   ├── structure_and_transmission_shacl_shapes.ttl
│   └── transmission_structure_statistics.json
└── 4.3_cross_language_validation_EN/
```

## Reproduction

From `4.3_consistency/`:

```bash
python -m pip install openpyxl
python code/tr_stats.py
```

`tr_stats.py` reads `../../02_annotations/` and writes `results/transmission_structure_statistics.json`.

The cross-language mapping validation has its own package and instructions:
`4.3_cross_language_validation_EN/README.md`.
