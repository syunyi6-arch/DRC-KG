# 4.3 Consistency

## Result

In DRC-KG (Dengue Research Case Knowledge Graph), 216,293 annotation rows were instantiated into
2,760,972 triples covering 261 research cases and 625 TR codes; the SHACL shape validation reports
0 violations. The static mapping check reports 0 hard violations, with 35,886 surface-level heuristic
flags counted separately by class. TR cross-table structural gaps that are machine reproducible
amount to 49 items (Chinese 40, English 9).

## Result files

| File | Content |
|---|---|
| `results/rdf_shacl_statistics.json` | input rows, triple count, case count, TR count, SHACL verdict, reasoning mode |
| `results/shacl_validation_report.txt` | SHACL validation output (0 violations) |
| `results/structure_and_transmission_shacl_shapes.ttl` | SHACL shapes used for the validation |
| `results/transmission_structure_statistics.json` | 625 TR codes, language split, relation-row coverage 599 |

## Code

| Script | Purpose |
|---|---|
| `00_common_code/src/rdf_export.py` | RDF instantiation + SHACL validation |
| `00_common_code/src/analysis.py` | static mapping check, TR cross-table audit |
| `code/tr_stats.py` | TR cross-table structural-gap statistics |

The 224 MB validation graph is not copied into this folder; see
`00_common_code/graph_artifact_manifest.json` (SHA256 plus the first 1,000 lines).

## Scope notes

- SHACL uses pyshacl with RDFS inference; this is not a full OWL 2 DL consistency proof.
- Domain and range are descriptive only in the ontology; no OWL axioms are asserted from the current mapping.
- A TR code marks a transmission-related record, not a confirmed transmission chain; unconfirmed research claims
  are not promoted to confirmed facts.
- The 109 items (8 real errors) of Table 6 in the manuscript are the result of manual item-by-item checking; the
  49 machine-reproducible items are structural gaps and come from a different source, so the manuscript keeps
  109 / 8.
- All 35,886 flags are surface heuristics (19,829 source strings of head entities not located, 11,979 relation
  domain/range to verify, 2,191 English attribute values containing Chinese characters, 858 purely numeric
  entities, 720 purely numeric values used as entities, 308 attribute host classes, 1 English entity value
  containing Chinese characters) and are not included in the hard-compliance rate.

## Note on triple counts

The figure above (2,760,972) describes the internal validation graph, which keeps a source-evidence field and is
not shipped. The published graph in `04_knowledge_graph/02_rdf_graph/` is a different instantiation of the same
216,293 annotation rows and contains 4,290,647 triples without any source text. The two counts must not be
interchanged.
