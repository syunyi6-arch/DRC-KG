#!/usr/bin/env python3
"""Recalculate the cross-language validation metrics from the manual-verdict workbooks.

Usage (from this package folder): python code/run_validation.py
Requires: Python 3.10+ and openpyxl (pip install -r requirements.txt).

Inputs  (results/): 01_100_Pair_Manual_Validation.xlsx, 03_600_Record_Manual_Validation.xlsx,
                    02_4_Pair_Corrections.xlsx, 04_23_Record_Corrections.xlsx
Output  (results/): 05_Validation_Results.xlsx
"""
import json
from collections import Counter
from math import sqrt
from pathlib import Path

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / 'results'


def sheet_data(filename, sheetname, ncols, expected_rows):
    """Read the data rows below the header, trimmed to the first `ncols` columns."""
    wb = load_workbook(RES / filename, read_only=True, data_only=True)
    ws = wb[sheetname]
    rows = []
    for row in ws.iter_rows(min_row=2, max_col=ncols, values_only=True):
        if row is None or all(v is None for v in row):
            continue
        rows.append(list(row))
        if len(rows) == expected_rows:
            break
    wb.close()
    return rows


def as_int(value):
    return 0 if value is None or value == '' else int(value)


pairs = sheet_data('01_100_Pair_Manual_Validation.xlsx', 'Manual Validation - 100 Pairs', 14, 100)
records = sheet_data('03_600_Record_Manual_Validation.xlsx', 'Manual Validation - 600 Records', 18, 600)
rep4 = sheet_data('02_4_Pair_Corrections.xlsx', 'Corrections - 4 Pairs', 13, 4)
rep23 = sheet_data('04_23_Record_Corrections.xlsx', 'Corrections - 23 Records', 10, 23)

assert len(pairs) == 100 and len(records) == 600 and len(rep4) == 4 and len(rep23) == 23
assert len({r[0] for r in pairs}) == 100 and len({r[0] for r in records}) == 600

bad4 = {r[0] for r in pairs if as_int(r[12]) == 0}
bad23 = {r[0] for r in records if as_int(r[14]) == 0}
assert bad4 == {r[0] for r in rep4}, '4 correction IDs must match failed pair decisions'
assert bad23 == {r[0] for r in rep23}, '23 correction IDs must match failed record decisions'


def wilson(k, n, z=1.959963984540054):
    p = k / n
    den = 1 + z * z / n
    cen = (p + z * z / (2 * n)) / den
    hw = z * sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
    return cen - hw, cen + hw


def sum_by(rows, keys, pass_column):
    group = Counter()
    ok = Counter()
    for r in rows:
        key = tuple(r[i] for i in keys)
        group[key] += 1
        ok[key] += as_int(r[pass_column])
    return [(key, group[key], ok[key]) for key in sorted(group)]


b600 = sum_by(records, [1, 2], 14)
b100 = sum_by(pairs, [1], 12)
ok600 = sum(as_int(r[14]) for r in records)
ok100 = sum(as_int(r[12]) for r in pairs)
assert ok600 == 577 and ok100 == 96

# Fixed reference population sizes for the six sampled strata (classification-table row counts).
pop = {('CN', 'Class'): 48667, ('CN', 'Attribute'): 26888, ('CN', 'Relation'): 32797,
       ('EN', 'Class'): 41509, ('EN', 'Attribute'): 39782, ('EN', 'Relation'): 20227}
weighted = sum((k / n) * pop[key] for key, n, k in b600) / sum(pop.values())

HEADER_FILL = PatternFill('solid', fgColor='173C57')
HEADER_FONT = Font(bold=True, color='FFFFFF')
PERCENT = '0.00%'


def write_sheet(ws, rows, widths, percent_cols):
    for r in rows:
        ws.append(r)
    for cell in ws[1]:
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.alignment = Alignment(vertical='center', wrap_text=False)
    ws.row_dimensions[1].height = 30
    for idx, width in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(idx)].width = width
    for col in percent_cols:
        for r in range(2, len(rows) + 1):
            ws.cell(row=r, column=col).number_format = PERCENT
    ws.freeze_panes = 'A2'


wb = Workbook()
wb.remove(wb.active)

lo600, hi600 = wilson(ok600, 600)
lo100, hi100 = wilson(ok100, 100)

summary = [
    ['Metric', 'Value', 'Unit'],
    ['Chinese Research Cases', 138, 'articles'],
    ['English Research Cases', 123, 'articles'],
    ['Bilingual Label Correspondences', 329564, 'occurrences'],
    ['Unique Bilingual Label Pairs', 448, 'pairs'],
    ['Bidirectional Label Conflicts', 0, 'conflicts'],
    ['600-Record Sample Size', 600, 'records'],
    ['600-Record Passed', ok600, 'records'],
    ['600-Record Failed', 600 - ok600, 'records'],
    ['600-Record Pass Rate', ok600 / 600, 'proportion'],
    ['600-Record Wilson 95% CI Lower', lo600, 'proportion'],
    ['600-Record Wilson 95% CI Upper', hi600, 'proportion'],
    ['Stratum-Weighted Pass Rate', weighted, 'proportion'],
    ['100-Pair Sample Size', 100, 'pairs'],
    ['100-Pair Passed', ok100, 'pairs'],
    ['100-Pair Failed', 100 - ok100, 'pairs'],
    ['100-Pair Pass Rate', ok100 / 100, 'proportion'],
    ['100-Pair Wilson 95% CI Lower', lo100, 'proportion'],
    ['100-Pair Wilson 95% CI Upper', hi100, 'proportion'],
    ['Author-Confirmed Record Corrections', len(rep23), 'records'],
    ['Author-Confirmed Pair Corrections', len(rep4), 'pairs'],
]
write_sheet(wb.create_sheet('Summary'), summary, [40, 23, 23], [2])

strata = [['Corpus', 'Mapping Type', 'Sample Size', 'Passed', 'Failed', 'Pass Rate',
           'Wilson 95% CI Lower', 'Wilson 95% CI Upper', 'Stratum Population', 'Weighted Contribution']]
for key, n, k in b600:
    l, h = wilson(k, n)
    strata.append([key[0], key[1], n, k, n - k, k / n, l, h, pop[key], k / n * pop[key] / sum(pop.values())])
strata.append(['TOTAL', 'ALL', 600, ok600, 600 - ok600, ok600 / 600, lo600, hi600, sum(pop.values()), weighted])
write_sheet(wb.create_sheet('600-Record Strata'), strata, [25] + [23] * 9, [6, 7, 8, 10])

groups = [['Mapping Type', 'Sample Size', 'Passed', 'Failed', 'Pass Rate',
           'Wilson 95% CI Lower', 'Wilson 95% CI Upper']]
for key, n, k in b100:
    l, h = wilson(k, n)
    groups.append([key[0], n, k, n - k, k / n, l, h])
groups.append(['TOTAL', 100, ok100, 100 - ok100, ok100 / 100, lo100, hi100])
write_sheet(wb.create_sheet('100-Pair Groups'), groups, [25] + [23] * 6, [5, 6, 7])

corrections = [['Validation Group', 'Corrected Count', 'Status'],
               ['100-Pair Validation', len(rep4), 'Corrected (Author-Confirmed)'],
               ['600-Record Validation', len(rep23), 'Corrected (Author-Confirmed)']]
write_sheet(wb.create_sheet('Corrections'), corrections, [25, 23, 23], [])

out = RES / '05_Validation_Results.xlsx'
wb.save(out)

print(json.dumps({
    'sample_600': 600, 'passed_600': ok600, 'pass_rate_600': ok600 / 600,
    'CI95_600': wilson(ok600, 600),
    'sample_100': 100, 'passed_100': ok100, 'pass_rate_100': ok100 / 100,
    'CI95_100': wilson(ok100, 100),
    'weighted_600': weighted,
    'repaired_record_count': len(rep23), 'repaired_pair_count': len(rep4),
}, ensure_ascii=False, indent=2))
