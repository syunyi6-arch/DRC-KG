# -*- coding: utf-8 -*-
"""Add English companion columns to the 4.3 manual-review workbooks.

The review workbooks mixed languages inside one row: the verdict and status columns are
controlled English (Pass / Fail / Corrected (Author-Confirmed)), while the free-text
"Confirmed Issue", "Correction Details or Direction" and "Validation Notes" were Chinese.
The Chinese text is the reviewers' original wording and is kept as-is; this script adds
the reviewed English rendering next to it, so each column is now single-language and the
workbook is explicitly bilingual.

Translations live in `notes_en_map.json` (this folder), keyed by Pair ID / Sample ID.

Run:  python -X utf8 05_validation/4.3_consistency/4.3_cross_language_validation_EN/code/add_english_notes.py
"""
import copy
import json
import re
import sys
from pathlib import Path

import openpyxl
from openpyxl.utils import get_column_letter

sys.stdout.reconfigure(encoding="utf-8")

ROOT = Path(__file__).resolve().parents[4]          # .../DRC-KG
RES = ROOT / "05_validation" / "4.3_consistency" / "4.3_cross_language_validation_EN" / "results"
MAP = json.loads((Path(__file__).resolve().parent / "notes_en_map.json").read_text(encoding="utf-8"))
CJK = re.compile(r"[\u4e00-\u9fff]")

JOBS = [
    ("02_4_Pair_Corrections.xlsx", "Corrections - 4 Pairs", "Pair ID", "pairs", "issue_en",
     ["Confirmed Issue", "Correction Details or Direction"]),
    ("04_23_Record_Corrections.xlsx", "Corrections - 23 Records", "Sample ID", "records", "issue_en",
     ["Confirmed Issue", "Correction Details or Direction"]),
    ("03_600_Record_Manual_Validation.xlsx", "Manual Validation - 600 Records", "Sample ID", "records",
     "issue_en", ["Validation Notes"]),
]


def english_for(entry, column):
    """English companion of one Chinese review column."""
    if column == "Correction Details or Direction":
        return entry["direction_en"]
    return entry["issue_en"]          # Confirmed Issue == Validation Notes by construction


def main():
    for filename, sheet_name, id_col, group, _key, columns in JOBS:
        path = RES / filename
        wb = openpyxl.load_workbook(path)
        ws = wb[sheet_name]
        header = [c.value for c in ws[1]]
        idx_id = header.index(id_col) + 1
        changed = 0
        for column in columns:
            en_header = column + " (EN)"
            if en_header in header:
                print("  skip (already bilingual):", filename, en_header)
                continue
            col = header.index(column) + 1
            src_letter = get_column_letter(col)
            dst_letter = get_column_letter(col + 1)
            ws.insert_cols(col + 1)
            header_cell = ws.cell(row=1, column=col)
            new_header = ws.cell(row=1, column=col + 1, value=en_header)
            new_header._style = copy.copy(header_cell._style)
            if ws.column_dimensions[src_letter].width:
                ws.column_dimensions[dst_letter].width = ws.column_dimensions[src_letter].width
            for row in range(2, ws.max_row + 1):
                key = ws.cell(row=row, column=idx_id).value
                zh = ws.cell(row=row, column=col).value
                if zh in (None, ""):
                    continue
                entry = MAP[group].get(str(key))
                if entry is None:
                    raise SystemExit("missing translation for %s %r" % (filename, key))
                en = english_for(entry, column)
                if not en or CJK.search(en):
                    raise SystemExit("bad English for %r: %r" % (key, en))
                cell = ws.cell(row=row, column=col + 1, value=en)
                cell._style = copy.copy(ws.cell(row=row, column=col)._style)
                changed += 1
            header = [c.value for c in ws[1]]
        wb.save(path)
        wb.close()
        print("  %s: %d cells" % (filename, changed))


if __name__ == "__main__":
    main()
