# Cross-Language Semantic Mapping Validation (Section 4.3)

```text
4.3_cross_language_validation_EN/
├── README.md
├── requirements.txt
├── code/
│   ├── run_validation.py
│   ├── add_english_notes.py
│   └── notes_en_map.json
└── results/
    ├── 01_100_Pair_Manual_Validation.xlsx
    ├── 02_4_Pair_Corrections.xlsx
    ├── 03_600_Record_Manual_Validation.xlsx
    ├── 04_23_Record_Corrections.xlsx
    └── 05_Validation_Results.xlsx
```

## Reproduction

From `4.3_cross_language_validation_EN/`:

```bash
python -m pip install -r requirements.txt
python code/run_validation.py
```

`run_validation.py` reads `results/01`–`04` and writes `results/05_Validation_Results.xlsx`.
`add_english_notes.py` adds the `(EN)` columns from `code/notes_en_map.json` to the review workbooks.
