# Cross-Language Semantic Mapping Validation (Section 4.3)

## Directory Structure

```text
4.3_cross_language_validation_EN/
├── README.md
├── requirements.txt
├── code/
│   └── run_validation.py
└── results/
    ├── 01_100_Pair_Manual_Validation.xlsx
    ├── 02_4_Pair_Corrections.xlsx
    ├── 03_600_Record_Manual_Validation.xlsx
    ├── 04_23_Record_Corrections.xlsx
    └── 05_Validation_Results.xlsx
```

## Reproduction

Requirements: Python 3.10+ and `openpyxl`.

From this folder (`4.3_cross_language_validation_EN/`), run:

```bash
python -m pip install -r requirements.txt
python code/run_validation.py
```

The script reads the two manual-validation workbooks and the two correction workbooks from `results/`, checks sample counts and correction IDs, and recalculates group totals, pass rates, Wilson 95% confidence intervals, and the stratum-weighted 600-record pass rate. It writes the updated results to `results/05_Validation_Results.xlsx`.
