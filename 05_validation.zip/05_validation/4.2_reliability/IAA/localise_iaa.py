# -*- coding: utf-8 -*-
"""Put the 4.2 IAA material into the same language convention as 4.1 / 4.3 / 4.4.

Those packages use English column headers with values in the survey language; the IAA
package was Chinese-headed.  This script localises headers and the controlled status
values (source stratum, check result, agreement dimension) and leaves annotation content
(Chinese entity/relation labels, article titles, source text) exactly as recorded.

Idempotent: already-English cells are left alone.

Run:  python -X utf8 05_validation/4.2_reliability/IAA/localise_iaa.py
"""
import csv
import sys
from pathlib import Path

import openpyxl

sys.stdout.reconfigure(encoding="utf-8")

HERE = Path(__file__).resolve().parent

HEADERS = {
    "编号": "Item ID",
    "语言": "Language",
    "PDF文件": "PDF File",
    "原文": "Source Text",
    "待分类实体": "Entity to Classify",
    "本体类别": "Ontology Class",
    "待判断属性值": "Attribute Value to Judge",
    "本体属性": "Ontology Attribute",
    "承载对象原文": "Carrier Object (Source Text)",
    "端点A": "Endpoint A",
    "端点B": "Endpoint B",
    "关系原文": "Relation (Source Text)",
    "本体关系": "Ontology Relation",
    "方向": "Direction",
    "原文片段": "Source Fragment",
    "主张类型": "Claim Type",
    "来源原文": "Source (Source Text)",
    "目标原文": "Target (Source Text)",
    "证据类别": "Evidence Type",
    "证据原文": "Evidence (Source Text)",
    "确定性": "Certainty",
    "限定词原文": "Qualifier (Source Text)",
    "知识单元原文（每行一项）": "Knowledge Unit Text (one per line)",
    "原子事实（每行一项）": "Atomic Facts (one per line)",
    "维度": "Dimension",
    "一致条数": "Agreements",
    "一致率": "Agreement Rate",
    "Cohen kappa": "Cohen's kappa",
    "源汇总文件": "Source Aggregate File",
    "工作表或引用位置": "Sheet or Reference Location",
    "行号或传播实例": "Row or Transmission Instance",
    "来源分层": "Source Stratum",
    "核对结果": "Check Result",
    "编号 ": "Item ID",
    "A": "Annotator A",
    "B": "Annotator B",
}

VALUES = {
    "普通": "Ordinary",
    "现有传播候选": "Existing transmission candidate",
    "边界片段": "Boundary fragment",
    "对照候选": "Control candidate",
    "行号有效": "Row number valid",
    "传播实例存在": "Transmission instance exists",
    "片段未整格命中（截断或改写）": "Fragment not matched as a full cell (truncated or rewritten)",
    "原文未定位": "Source not located",
    "实体类别": "Entity category",
    "属性归属": "Attribute assignment",
    "关系语义与方向": "Relation semantics and direction",
    "传播主张类型": "Transmission claim type",
    "传播确定性": "Transmission certainty",
    "整体（5 维合并）": "Overall (5 dimensions pooled)",
    "证据：7 类集合完全一致": "Evidence: exact agreement of 7-class sets",
    "证据：3 大类集合": "Evidence: 3-class sets",
}
PREFIX = {"片段整格命中": "Fragment matched as a full cell"}

SHEET_NAMES = {
    "实体": "Entity",
    "属性": "Attribute",
    "关系": "Relation",
    "传播": "Transmission",
    "边界": "Boundary",
    "类_中英对照": "Classes (ZH-EN)",
    "属性_中英对照": "Attributes (ZH-EN)",
    "语义关系_中英对照": "Semantic relations (ZH-EN)",
    "统一术语映射": "Term map",
}


def localise(value):
    if not isinstance(value, str):
        return value
    text = value.strip()
    if text in VALUES:
        return VALUES[text]
    for zh, en in PREFIX.items():
        if text.startswith(zh):
            return en + text[len(zh):]
    return value


def fix_headers(ws):
    changed = 0
    for cell in ws[1]:
        if isinstance(cell.value, str) and cell.value.strip() in HEADERS:
            cell.value = HEADERS[cell.value.strip()]
            changed += 1
    return changed


def main():
    for name in ("iaa_annotator_A.xlsx", "iaa_annotator_B.xlsx"):
        wb = openpyxl.load_workbook(HERE / name)
        for sheet in ("实体", "属性", "关系", "传播", "边界"):
            if sheet in wb.sheetnames:          # absent once the sheet has been renamed
                n = fix_headers(wb[sheet])
                print(name, sheet, "headers localised:", n)
        for zh, en in SHEET_NAMES.items():
            if zh in wb.sheetnames:
                wb[zh].title = en
        wb.save(HERE / name)
        wb.close()
        titles = openpyxl.load_workbook(HERE / name, read_only=True).sheetnames
        print(name, "sheets:", titles)

    for name, columns in (("iaa_final_results.csv", ("维度",)),
                          ("disagreement_list_A_vs_B.csv", ("维度",))):
        path = HERE / name
        rows = list(csv.reader(open(path, encoding="utf-8-sig", newline="")))
        header = [HEADERS.get(h.strip(), h) for h in rows[0]]
        out = [header]
        for row in rows[1:]:
            new = list(row)
            for j, col in enumerate(rows[0]):
                if col.strip() in columns:
                    new[j] = localise(new[j])
            out.append(new)
        with open(path, "w", encoding="utf-8-sig", newline="") as f:
            csv.writer(f, lineterminator="\n").writerows(out)
        print(name, "rows:", len(out) - 1)

    path = HERE / "source_index_coordinator_only.csv"
    rows = list(csv.reader(open(path, encoding="utf-8-sig", newline="")))
    header = [HEADERS.get(h.strip(), h) for h in rows[0]]
    stratum = header.index("Source Stratum")
    result = header.index("Check Result")
    out = [header]
    for row in rows[1:]:
        new = list(row)
        new[stratum] = localise(new[stratum])
        new[result] = localise(new[result])
        out.append(new)
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        csv.writer(f, lineterminator="\n").writerows(out)
    print("source_index_coordinator_only.csv rows:", len(out) - 1)


if __name__ == "__main__":
    main()
