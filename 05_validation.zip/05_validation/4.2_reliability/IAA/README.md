# 4.2 IAA

```text
IAA/
├── README.md
├── iaa_annotator_A.xlsx
├── iaa_annotator_B.xlsx
├── score_iaa.py
├── localise_iaa.py
├── iaa_final_results.csv
├── disagreement_list_A_vs_B.csv
└── source_index_coordinator_only.csv
```

## Reproduction

From `IAA/`:

```bash
python -m pip install openpyxl
python score_iaa.py iaa_annotator_A.xlsx iaa_annotator_B.xlsx
```

`score_iaa.py` writes `IAA_最终结果表.csv`, `IAA_证据逐类目.csv` and `差异清单_A对B.csv` into the
current directory. `localise_iaa.py` rewrites the headers of `iaa_final_results.csv`,
`disagreement_list_A_vs_B.csv` and `source_index_coordinator_only.csv` to the English convention.
