# 4.2 IAA — inter-annotator agreement

Two annotators labelled the same 1,311 items independently. The package records the instruments, the
two completed workbooks, the scoring script, the agreement table and the disagreement list.

| File | Content |
|---|---|
| `iaa_annotator_A.xlsx` / `iaa_annotator_B.xlsx` | the two annotation instruments: 5 task sheets (`Entity`, `Attribute`, `Relation`, `Transmission`, `Boundary`) plus 4 bilingual ontology reference sheets (`Classes (ZH-EN)`, `Attributes (ZH-EN)`, `Semantic relations (ZH-EN)`, `Term map`) |
| `score_iaa.py` | reads both workbooks by column position and writes the agreement tables |
| `iaa_final_results.csv` | agreement and Cohen's kappa per dimension (plus the pooled row and the two evidence rows) |
| `disagreement_list_A_vs_B.csv` | every item on which A and B differ, by dimension |
| `source_index_coordinator_only.csv` | provenance of each sampled item: source aggregate file, sheet/locator, check result, and the sampling stratum (ordinary / existing transmission candidate / boundary fragment / control candidate) |

## Items and results

| Task sheet | Items | Dimension | Agreement | Cohen's kappa |
|---|---|---|---|---|
| `Entity` | 300 | entity category | 85.0% | 0.839 |
| `Attribute` | 300 | attribute assignment | 80.0% | 0.752 |
| `Relation` | 400 | relation semantics and direction | 78.0% | 0.772 |
| `Transmission` | 211 | transmission claim type | 84.8% | 0.797 |
| `Transmission` | 211 | transmission certainty | 90.5% | 0.842 |
| all five | 1,422 | overall | 82.8% | 0.823 |

Header rows are English so the package matches 4.1 / 4.3 / 4.4. The cells under them are annotation
content and stay in the language of the source article (Chinese entity and relation labels, English
relation text), exactly as the annotators recorded them.
