# -*- coding: utf-8 -*-
"""Rewrite the PDF locator column of the accuracy workbook in English.

`PDF Page / Table Location` held values such as "PDF第2页" in an otherwise English sheet;
they become "PDF p.2". Content columns (source evidence, entity values, Chinese article
titles) are left untouched: they are source data, not interface wording.

Idempotent: cells that already read "PDF p.N" are skipped.

Run:  python -X utf8 05_validation/4.2_reliability/Accuracy_Experiment/localise_pdf_pages.py
"""
import re
import sys

import openpyxl

sys.stdout.reconfigure(encoding="utf-8")

BOOK = r"D:/sc成果/DRC-KG/05_validation/4.2_reliability/Accuracy_Experiment/Accuracy_Experiment_Results.xlsx"
COLUMN = "PDF Page / Table Location"
ZH = re.compile(r"^PDF第(\d+)页$")


def main():
    wb = openpyxl.load_workbook(BOOK)
    total = 0
    for sheet in ("Correct Results", "Incorrect Results"):
        ws = wb[sheet]
        header = [c.value for c in ws[1]]
        col = header.index(COLUMN) + 1
        changed = 0
        for row in range(2, ws.max_row + 1):
            cell = ws.cell(row=row, column=col)
            value = cell.value
            if not isinstance(value, str):
                continue
            m = ZH.match(value.strip())
            if not m:
                continue
            cell.value = "PDF p.%s" % m.group(1)
            changed += 1
        print(sheet, "rewritten:", changed)
        total += changed

    # nothing may be left in the Chinese form
    for sheet in ("Correct Results", "Incorrect Results"):
        ws = wb[sheet]
        header = [c.value for c in ws[1]]
        col = header.index(COLUMN) + 1
        left = [ws.cell(row=r, column=col).value for r in range(2, ws.max_row + 1)
                if isinstance(ws.cell(row=r, column=col).value, str)
                and ZH.match(ws.cell(row=r, column=col).value.strip())]
        if left:
            raise SystemExit("unconverted locators left: %r" % left[:3])
    wb.save(BOOK)
    wb.close()
    print("total:", total)


if __name__ == "__main__":
    main()
