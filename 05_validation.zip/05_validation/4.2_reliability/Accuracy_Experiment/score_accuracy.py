#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Calculate the fact-level precision summary from the accuracy workbook.

Requires only Python 3.9+ and the standard library.
The two detail worksheets are preserved when writing Experiment Results.
"""
import argparse
from collections import defaultdict
from pathlib import Path
import math
import os
import posixpath
import re
import tempfile
from zipfile import ZipFile, ZIP_DEFLATED
from xml.etree import ElementTree as ET

NS = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'
REL = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
PKG = 'http://schemas.openxmlformats.org/package/2006/relationships'
M = '{' + NS + '}'
STRATA = [(lang, kind) for lang in ('CN','EN') for kind in
          ('Entity Classification','Attribute Fact','Relation Fact')]
SAMPLE_SIZES = {(lang, kind): (200 if kind == 'Relation Fact' else 150)
                for lang, kind in STRATA}
DETAIL_SHEETS = ('Correct Results', 'Incorrect Results')
SUMMARY_SHEET = 'Experiment Results'


def column_index(address):
    number = 0
    for letter in re.match(r'[A-Z]+', address).group(0):
        number = number * 26 + ord(letter) - 64
    return number - 1


def column_name(index):
    letters = ''
    index += 1
    while index:
        index, digit = divmod(index - 1, 26)
        letters = chr(65 + digit) + letters
    return letters


def sheet_paths(archive):
    root = ET.fromstring(archive.read('xl/workbook.xml'))
    links = ET.fromstring(archive.read('xl/_rels/workbook.xml.rels'))
    target_by_id = {item.attrib['Id']:item.attrib['Target'] for item in links}
    output = {}
    for sheet in root.findall(M+'sheets/'+M+'sheet'):
        target = target_by_id[sheet.attrib['{'+REL+'}id']]
        output[sheet.attrib['name']] = (target.lstrip('/') if target.startswith('/') else
            posixpath.normpath(posixpath.join('xl', target)))
    return output


def shared_strings(archive):
    if 'xl/sharedStrings.xml' not in archive.namelist():
        return []
    root = ET.fromstring(archive.read('xl/sharedStrings.xml'))
    return [''.join(node.text or '' for node in item.iter(M+'t'))
            for item in root.findall(M+'si')]


def cell_value(cell, strings):
    typ = cell.get('t', '')
    if typ == 'inlineStr':
        node = cell.find(M+'is')
        return ''.join(t.text or '' for t in node.iter(M+'t')) if node is not None else ''
    v = cell.find(M+'v')
    if v is None or v.text is None:
        return ''
    if typ == 's':
        return strings[int(v.text)]
    return v.text


def read_records(archive, path, strings):
    xml = ET.fromstring(archive.read(path))
    rows = []
    for row in xml.findall(M+'sheetData/'+M+'row'):
        rows.append({column_index(c.attrib['r']): cell_value(c, strings)
                     for c in row.findall(M+'c')})
    if not rows:
        return []
    fields = rows[0]
    output = []
    for row in rows[1:]:
        item = {str(fields.get(index, '')): value for index, value in row.items()}
        if str(item.get('Sample ID','')).strip():
            output.append(item)
    return output


def load_records(path, selected):
    output = []
    with ZipFile(path) as archive:
        paths = sheet_paths(archive)
        strings = shared_strings(archive)
        for name in selected:
            if name not in DETAIL_SHEETS:
                raise ValueError('Only detail worksheets can be selected: ' + ', '.join(DETAIL_SHEETS))
            if name not in paths:
                raise ValueError('Missing worksheet: ' + name)
            output.extend((name, row) for row in read_records(archive, paths[name], strings))
    return output


def calculate(records):
    counts = defaultdict(lambda: {'n':0,'correct':0,'incorrect':0,'population':None})
    seen = set()
    for sheet, row in records:
        sample_id = str(row.get('Sample ID','')).strip()
        if not sample_id or sample_id in seen:
            raise ValueError('Missing or duplicate Sample ID: ' + sample_id)
        seen.add(sample_id)
        key = (str(row.get('Language','')).strip(), str(row.get('Fact Type','')).strip())
        if key not in STRATA:
            raise ValueError('Invalid sample stratum for ' + sample_id + ': ' + str(key))
        decision = str(row.get('Decision','')).strip()
        expected = 'Correct' if sheet == 'Correct Results' else 'Incorrect'
        if decision != expected:
            raise ValueError('Decision does not match worksheet for ' + sample_id)
        group = counts[key]
        group['n'] += 1
        group[decision.lower()] += 1
        N = int(float(row.get('Stratum Population (N_h)',0)))
        if N <= 0 or group['population'] not in (None, N):
            raise ValueError('Invalid population for ' + sample_id)
        group['population'] = N

    complete = (len(records) == 1000 and
                all(counts[k]['n'] == SAMPLE_SIZES[k] and counts[k]['population']
                    for k in STRATA))
    population = sum(counts[k]['population'] or 0 for k in STRATA)
    correct = sum(counts[k]['correct'] for k in STRATA)
    incorrect = sum(counts[k]['incorrect'] for k in STRATA)
    weighted = 0.0
    variance = 0.0
    stratum_rows = []
    for lang, fact in STRATA:
        grp = counts[(lang, fact)]
        n, N = grp['n'], grp['population']
        p = grp['correct'] / n if n else None
        W = N/population if N is not None and population else None
        contribution = W*p if complete else None
        component = (W**2)*(1-n/N)*p*(1-p)/(n-1) if complete else None
        if complete:
            weighted += contribution
            variance += component
        stratum_rows.append([lang,fact,N,n,grp['correct'],grp['incorrect'],n,
                             p,W,contribution,component])
    se = math.sqrt(variance) if complete else None
    return {'rows':stratum_rows,'total':len(records),'correct':correct,
            'incorrect':incorrect,'population':population if complete else None,
            'sample_precision':correct/len(records) if len(records)==1000 else None,
            'weighted':weighted if complete else None,'se':se,
            'ci_low':max(0,weighted-1.96*se) if complete else None,
            'ci_high':min(1,weighted+1.96*se) if complete else None,
            'complete':complete}


def summary_rows(result):
    title = ['4.2 Fact-Level Precision — Accuracy Experiment']
    heading = ['Language','Fact Type','Population (N_h)','Sample (n_h)',
               'Correct','Incorrect','Evaluated','Stratum Precision','Weight (W_h)',
               'Weighted Contribution','Variance Contribution']
    overall = ['Overall','Six Strata',result['population'],result['total'],
               result['correct'],result['incorrect'],result['total'],
               result['sample_precision'],1 if result['complete'] else None,
               result['weighted'],result['se']**2 if result['complete'] else None]
    metrics = [['Metric','Value'],
       ['Total Samples',result['total']],
       ['Correct Samples',result['correct']],
       ['Incorrect Samples',result['incorrect']],
       ['Sample Precision',result['sample_precision']],
       ['Weighted Precision',result['weighted']],
       ['Approximate Standard Error',result['se']],
       ['95% CI — Lower Bound',result['ci_low']],
       ['95% CI — Upper Bound',result['ci_high']],
       ['Eligible Fact Population',result['population']],
       ['Number of Strata',6 if result['complete'] else None]]
    return [title,heading,*result['rows'],overall,[],*metrics]


def update_summary(input_path, output_path, result):
    with ZipFile(input_path) as archive:
        paths = sheet_paths(archive)
        create = SUMMARY_SHEET not in paths
        if create:
            numbers = [int(s) for s in re.findall(r'xl/worksheets/sheet(\d+)\.xml','\n'.join(archive.namelist()))]
            part = f'xl/worksheets/sheet{max(numbers,default=0)+1}.xml'
            root = ET.Element(M+'worksheet')
            ET.SubElement(root,M+'sheetData')
        else:
            part = paths[SUMMARY_SHEET]
            root = ET.fromstring(archive.read(part))
        previous = root.find(M+'sheetData')
        styles = {}
        if previous is not None:
            for cell in previous.iter(M+'c'):
                if 's' in cell.attrib:
                    styles[cell.attrib['r']] = cell.attrib['s']
        else:
            first_detail = ET.fromstring(archive.read(paths[DETAIL_SHEETS[0]]))
            first_cell = first_detail.find(M+'sheetData/'+M+'row/'+M+'c')
            if first_cell is not None and 's' in first_cell.attrib:
                styles = {'default':first_cell.attrib['s']}
        replacement = ET.Element(M+'sheetData')
        for row_idx, values in enumerate(summary_rows(result), start=1):
            if not values: continue
            row = ET.SubElement(replacement,M+'row',{'r':str(row_idx),'ht':'18','customHeight':'1'})
            for col_idx,value in enumerate(values):
                if value is None: continue
                address = column_name(col_idx)+str(row_idx)
                attrs = {'r':address}
                style = styles.get(address,styles.get('default'))
                if style is not None: attrs['s']=style
                if isinstance(value,(float,int)) and not isinstance(value,bool):
                    cell = ET.SubElement(row,M+'c',attrs)
                    ET.SubElement(cell,M+'v').text=str(value)
                else:
                    attrs['t']='inlineStr'
                    cell = ET.SubElement(row,M+'c',attrs)
                    element = ET.SubElement(ET.SubElement(cell,M+'is'),M+'t')
                    element.text=str(value)
        if previous is None:
            root.insert(0,replacement)
        else:
            index = list(root).index(previous)
            root.remove(previous)
            root.insert(index,replacement)
        replaced={part:ET.tostring(root,encoding='utf-8',xml_declaration=True)}
        if create:
            book=ET.fromstring(archive.read('xl/workbook.xml'))
            links=ET.fromstring(archive.read('xl/_rels/workbook.xml.rels'))
            types=ET.fromstring(archive.read('[Content_Types].xml'))
            sheets=book.find(M+'sheets')
            next_id=max([int(s.attrib['sheetId']) for s in sheets]+[0])+1
            relids={s.attrib['Id'] for s in links}
            rid='rId'+str(next_id)
            while rid in relids:
                next_id+=1;rid='rId'+str(next_id)
            ET.SubElement(sheets,M+'sheet',{'name':SUMMARY_SHEET,'sheetId':str(next_id),'{'+REL+'}id':rid})
            ET.SubElement(links,'{'+PKG+'}Relationship',{'Id':rid,
                'Type':'http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet',
                'Target':posixpath.relpath(part,'xl')})
            ET.SubElement(types,'{http://schemas.openxmlformats.org/package/2006/content-types}Override',
                {'PartName':'/'+part,'ContentType':'application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml'})
            replaced.update({'xl/workbook.xml':ET.tostring(book,encoding='utf-8',xml_declaration=True),
                             'xl/_rels/workbook.xml.rels':ET.tostring(links,encoding='utf-8',xml_declaration=True),
                             '[Content_Types].xml':ET.tostring(types,encoding='utf-8',xml_declaration=True)})
        output_path=Path(output_path)
        output_path.parent.mkdir(parents=True,exist_ok=True)
        fd,temp_path=tempfile.mkstemp(prefix='.accuracy_',suffix='.xlsx',dir=str(output_path.parent))
        os.close(fd)
        try:
            with ZipFile(temp_path,'w',ZIP_DEFLATED,compresslevel=6) as dest:
                for info in archive.infolist():
                    dest.writestr(info,replaced.get(info.filename,archive.read(info.filename)))
                if create:dest.writestr(part,replaced[part])
            os.replace(temp_path,output_path)
        finally:
            if os.path.exists(temp_path): os.unlink(temp_path)


def main():
    parser=argparse.ArgumentParser(description='Calculate fact-level precision for the accuracy experiment')
    parser.add_argument('--input',default='Accuracy_Experiment_Results.xlsx',help='Input workbook')
    parser.add_argument('--sheets',nargs='+',default=list(DETAIL_SHEETS),help='Detail worksheets to evaluate')
    parser.add_argument('--output',help='Output workbook (default: input workbook)')
    args=parser.parse_args()
    src=Path(args.input)
    if not src.is_file():parser.error('Input file does not exist: '+str(src))
    dest=Path(args.output) if args.output else src
    records=load_records(src,args.sheets)
    result=calculate(records)
    update_summary(src,dest,result)
    print(f"Samples: {result['total']}; correct: {result['correct']}; incorrect: {result['incorrect']}")
    if result['complete']:
        print(f"Sample precision: {result['sample_precision']:.2%}")
        print(f"Weighted precision: {result['weighted']:.2%}")
        print(f"Approximate 95% CI: {result['ci_low']:.2%}–{result['ci_high']:.2%}")
    print('Workbook:',dest)

if __name__=='__main__':main()
