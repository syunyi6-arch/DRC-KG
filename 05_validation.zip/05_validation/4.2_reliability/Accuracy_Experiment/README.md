# 4.2 Accuracy Experiment

```text
Accuracy_Experiment/
├── README.md
├── Accuracy_Experiment_Results.xlsx
├── score_accuracy.py
└── localise_pdf_pages.py
```

## Reproduction

From `Accuracy_Experiment/`:

```bash
python score_accuracy.py --input Accuracy_Experiment_Results.xlsx
```

The script reads the `Correct Results` and `Incorrect Results` worksheets and writes the summary into the
`Experiment Results` worksheet of the same workbook; `--output` writes to a separate workbook instead.

```bash
python score_accuracy.py --input Accuracy_Experiment_Results.xlsx --output Accuracy_Experiment_Results_verified.xlsx
python score_accuracy.py --input Accuracy_Experiment_Results.xlsx --sheets "Correct Results" "Incorrect Results"
```
