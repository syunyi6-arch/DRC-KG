# 4.2 Accuracy Experiment — Fact-Level Precision

This folder contains the fact-level accuracy evaluation of the dengue research-case knowledge graph (DRC-KG), with 1,000 reviewed knowledge assertions.

## 1. Files

| File | Description |
|---|---|
| `Accuracy_Experiment_Results.xlsx` | Three worksheets containing 902 correct assertions, 98 incorrect assertions, and the experimental summary |
| `score_accuracy.py` | Python script for calculating the precision metrics and writing the `Experiment Results` worksheet |
| `README.md` | File guide, field descriptions, results, and calculation method |

## 2. Worksheets and fields

**Correct Results** (902 records) and **Incorrect Results** (98 records) use the same 18 columns:

`Sample ID`, `Language`, `Fact Type`, `Input / Source Evidence`, `Knowledge Graph Output`, `Decision`, `Decision Rationale / Notes`, `Error Type`, `Source Paper`, `PDF Page / Table Location`, `Source Sheet`, `Source Row`, `Original Relation`, `Ontology Relation`, `Subject Entity (Class)`, `Object Entity / Attribute Value`, `Stratum Population (N_h)`, and `Sampling Weight (N_h/n_h)`.

The source excerpts, publication titles, and knowledge graph assertions retain their original language and terminology to preserve the underlying research evidence. All workbook headings, decision labels, summary metrics, file and directory names, and this README are in English.

**Experiment Results** presents precision across six strata, defined by language (CN/EN) and fact type (entity classification, attribute fact, relation fact), followed by overall metrics.

## 3. Experiment results

| Language | Fact type | Population (N_h) | Sample (n_h) | Correct | Incorrect | Precision |
|---|---|---:|---:|---:|---:|---:|
| CN | Entity Classification | 48,411 | 150 | 126 | 24 | 84.00% |
| CN | Attribute Fact | 25,513 | 150 | 142 | 8 | 94.67% |
| CN | Relation Fact | 32,572 | 200 | 185 | 15 | 92.50% |
| EN | Entity Classification | 40,221 | 150 | 135 | 15 | 90.00% |
| EN | Attribute Fact | 39,584 | 150 | 143 | 7 | 95.33% |
| EN | Relation Fact | 19,782 | 200 | 171 | 29 | 85.50% |
| **Total** | **Six strata** | **206,083** | **1,000** | **902** | **98** | **90.20% unweighted** |

The six-stratum weighted precision is **90.16%**, with an approximate 95% confidence interval of **88.17%–92.15%**. The eligible population is the fact-sampling frame, not the full set of RDF triples. The confidence interval does not account for clustering of facts within individual papers.

## 4. Run the analysis

Python 3.9 or later is required. No third-party packages are needed.

From this folder, run:

```bash
python score_accuracy.py --input "Accuracy_Experiment_Results.xlsx"
```

To write to a separate workbook:

```bash
python score_accuracy.py --input "Accuracy_Experiment_Results.xlsx" --output "Accuracy_Experiment_Results_verified.xlsx"
```

To specify the two data worksheets explicitly:

```bash
python score_accuracy.py --input "Accuracy_Experiment_Results.xlsx" --sheets "Correct Results" "Incorrect Results"
```

The script reads the detail records and writes the summary into the `Experiment Results` worksheet; it does not
modify the input workbook.

## 5. Calculation method

For each stratum *h*, let `N_h` be its eligible population, `n_h` its sampled fact count, and `c_h` its correct count.

- Stratum precision: `p_h = c_h / n_h`.
- Population weight: `W_h = N_h / sum(N_h)`.
- Weighted precision: `P = sum(W_h * p_h)`.
- Approximate sampling variance: `Var(P) = sum[W_h² * (1 - n_h/N_h) * p_h * (1 - p_h) / (n_h - 1)]`.
- Approximate 95% CI: `P ± 1.96 * sqrt(Var(P))`.

The inter-annotator agreement (IAA) materials are in the parent `4.2_reliability` directory and are separate from
this accuracy experiment.
