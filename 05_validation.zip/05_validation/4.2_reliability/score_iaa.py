"""最终计分脚本：教学演示 A × B。
与包内 计算IAA.py 的区别（三处，均在本文件头部声明）：
1) 确定性按「限定词原文」的固定规则归并后再比较（规则见 certainty_level）；
2) 关系按「语义＋方向」联合判定为一项；
3) 证据类别以全部 211 项为分母（官方脚本只在双方均判为适用主张的子集上统计），另给 3 大类合并口径。
用法：python 计分.py [标注者A.xlsx] [标注者B.xlsx]（缺省取本目录教学演示两稿）
输出：IAA_最终结果表.csv、IAA_证据逐类目.csv、差异清单_A对B.csv
"""
import csv
import os
import re
import sys
from collections import Counter

from openpyxl import load_workbook

ROOT = os.path.dirname(os.path.abspath(__file__))
ELIG = {'具体来源—目标主张', '病因推断'}
EVID = ['流调接触', '时空联系', '实验室检测', '序列分析', '媒介调查', '其他', '未报告']
GROUP = {'流调接触': '流行病学与时空', '时空联系': '流行病学与时空',
         '实验室检测': '实验室与分子', '序列分析': '实验室与分子',
         '媒介调查': '媒介与其他', '其他': '媒介与其他', '未报告': '媒介与其他'}
# 明确陈述 / 倾向 / 可能 / 未定 四级归并，中文与英文限定语按同一套规则
CERT_UNSURE = ('无法确定', '未定', '未知', '不确定', 'unknown', 'unclear')
CERT_LEAN = ('极有可能', '可能性大', '很可能', '倾向', '推断', '提示', '表明', '支持',
             'suggest', 'most likely', 'likely', 'indicate')
CERT_MAYBE = ('可能', '推测', '疑似', '不排除', '初步', 'possibly', 'probably', 'may be', '或许', '或')


def c(v):
    return re.sub(r'[ \t\r\n]+', ' ', str(v)).strip() if v is not None else ''


def tokens(v):
    return {x.strip() for x in re.split(r'[|+]', c(v)) if x.strip()}


def certainty_level(q):
    s = c(q).lower()
    if not s or s == '无':
        return '明确陈述'
    if any(x in s for x in CERT_UNSURE):
        return '未定'
    if any(x in s for x in CERT_LEAN):
        return '倾向'
    if any(x in s for x in CERT_MAYBE):
        return '可能'
    return '明确陈述'


def read(path, sheet):
    wb = load_workbook(path, read_only=True, data_only=True)
    try:
        return {r[0]: tuple('' if x is None else str(x) for x in r)
                for r in wb[sheet].iter_rows(min_row=2, values_only=True) if r[0]}
    finally:
        wb.close()


def stats(pairs):
    n = len(pairs)
    if not n:
        return 0, 0, 0.0, ''
    ca, cb = Counter(a for a, b in pairs), Counter(b for a, b in pairs)
    agree = sum(a == b for a, b in pairs)
    po = agree / n
    pe = sum(ca[k] * cb[k] for k in ca) / (n * n)
    return n, agree, round(po * 100, 1), ('' if pe == 1 else round((po - pe) / (1 - pe), 3))


def main(a, b):
    ent_a, ent_b = read(a, '实体'), read(b, '实体')
    att_a, att_b = read(a, '属性'), read(b, '属性')
    rel_a, rel_b = read(a, '关系'), read(b, '关系')
    tr_a, tr_b = read(a, '传播'), read(b, '传播')

    # B 稿还没填时给出明确提示，而不是除零报错
    if not any(c(r[5]) for r in ent_b.values()) and not any(c(r[5]) for r in att_b.values()) \
            and not any(c(r[7]) for r in rel_b.values()) and not any(c(r[4]) for r in tr_b.values()):
        raise SystemExit('标注者B 尚未填写判定值：请先填 IAA_标注者B.xlsx 的黄色列，再运行本脚本。')

    rows, pooled, diffs = [], [], []

    def add(name, pairs):
        n, agree, po, k = stats(pairs)
        rows.append([name, n, agree, f'{po}%', k])

    # (维度名, 取键的源表, 取值函数) —— 取值函数对 (A行, B行) 返回 (A值, B值)
    dims = [
        ('实体类别', ent_a, lambda x, y: (c(x[5]), c(y[5]))),
        ('属性归属', att_a, lambda x, y: (c(x[5]), c(y[5]))),
        ('关系语义与方向', rel_a,
         lambda x, y: (c(x[7]) + '｜' + c(x[8]), c(y[7]) + '｜' + c(y[8]))),
        ('传播主张类型', tr_a, lambda x, y: (c(x[4]), c(y[4]))),
        ('传播确定性', tr_a,
         lambda x, y: (certainty_level(x[10]) if c(x[4]) in ELIG else '不适用',
                       certainty_level(y[10]) if c(y[4]) in ELIG else '不适用')),
    ]
    other = {'实体类别': ent_b, '属性归属': att_b, '关系语义与方向': rel_b,
             '传播主张类型': tr_b, '传播确定性': tr_b}
    for name, src, value in dims:
        pairs = [value(src[k], other[name][k]) for k in src]
        add(name, pairs)
        pooled += pairs
        if name in ('实体类别', '属性归属', '关系语义与方向', '传播主张类型'):
            diffs += [[name, k, u, v] for k, (u, v) in zip(src, pairs) if u != v]

    add('整体（5 维合并）', pooled)

    # 证据
    sa = {k: tokens(tr_a[k][7]) for k in tr_a}
    sb = {k: tokens(tr_b[k][7]) for k in tr_b}
    add('证据：7 类集合完全一致', [('|'.join(sorted(sa[k])), '|'.join(sorted(sb[k]))) for k in sa])
    add('证据：3 大类集合', [('|'.join(sorted({GROUP[x] for x in sa[k] if x in GROUP})),
                        '|'.join(sorted({GROUP[x] for x in sb[k] if x in GROUP}))) for k in sa])

    # 差异清单只列 4 个单选维度的逐条分歧；确定性/证据的逐条分歧见 官方脚本输出/IAA_混淆明细.csv
    with open(os.path.join(ROOT, 'IAA_最终结果表.csv'), 'w', encoding='utf-8-sig', newline='') as f:
        w = csv.writer(f)
        w.writerow(['维度', 'n', '一致条数', '一致率', 'Cohen kappa'])
        w.writerows(rows)
    with open(os.path.join(ROOT, 'IAA_证据逐类目.csv'), 'w', encoding='utf-8-sig', newline='') as f:
        w = csv.writer(f)
        w.writerow(['证据类目', 'n', '一致条数', '一致率', 'Cohen kappa'])
        for lab in EVID:
            p = [(lab in sa[k], lab in sb[k]) for k in sa]
            n, agree, po, kp = stats(p)
            w.writerow([lab, n, agree, f'{po}%', kp])
    with open(os.path.join(ROOT, '差异清单_A对B.csv'), 'w', encoding='utf-8-sig', newline='') as f:
        w = csv.writer(f)
        w.writerow(['维度', '编号', 'A', 'B'])
        w.writerows(diffs)

    for r in rows:
        print(r)
    print('差异条目', len(diffs))


if __name__ == '__main__':
    args = sys.argv[1:]
    if len(args) not in (0, 2):
        raise SystemExit(__doc__)
    if args:
        main(args[0], args[1])
    else:
        main(os.path.join(ROOT, 'IAA_标注者A.xlsx'),
             os.path.join(ROOT, 'IAA_标注者B.xlsx'))
