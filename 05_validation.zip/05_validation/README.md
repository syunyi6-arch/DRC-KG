# 05_validation — four validation packages

Each package is self-contained: a README, the code that produced the numbers, the data it read and
the results it wrote. Every package follows the same language convention: **English headers, English
controlled verdicts, and values kept in the language of the source they describe**.

| Package | Question | Headline result |
|---|---|---|
| `4.1_completeness` | How much of the source facts is represented? | 3,483 TP / 226 FN over 30 articles, recall 93.9% (CN 93.2%, EN 94.4%) |
| `4.2_reliability` | Are the annotations reproducible and precise? | IAA kappa 0.752–0.842 across five dimensions; 902 / 1,000 sampled facts Correct (90.2%) |
| `4.3_consistency` | Is the graph structurally and semantically consistent? | SHACL: 0 violations; 96 / 100 label pairs and 577 / 600 records Pass; 27 corrections confirmed |
| `4.4_usability` | Can competency questions be answered from the graph? | 37 / 40 reviewed answers Pass with the evidence-aware representation vs 16 / 40 with plain SPO |

## 4.1 completeness

30 articles (15 Chinese, 15 English) were read against the graph; the reference set holds 3,709
deduplicated facts and the final extraction covers 3,483 of them. `reference_set_30/` holds the
authoritative TP/FN tables (author-confirmed remarks), `results/` the computed recall, exclusion and
de-duplication records, and `report/` the English results statement.

## 4.2 reliability

- **Inter-annotator agreement**: two annotators independently labelled five task sheets (300 entity
  items, 300 attribute items, 400 relation items, 211 transmission items, 100 boundary items).
  Cohen's kappa: entity category 0.839, attribute assignment 0.752, relation semantics and direction
  0.772, transmission claim type 0.797, transmission certainty 0.842; overall 82.8% agreement
  (kappa 0.823). `IAA/` holds both workbooks, the scoring script, the final table, the disagreement
  list and the provenance index.
- **Accuracy experiment**: 1,000 sampled facts stratified by language × fact type; 902 Correct and
  98 Incorrect decisions, each with a rationale and, for errors, an error type.
  `Accuracy_Experiment/` holds the workbook, the scoring script and the README.

## 4.3 consistency

- SHACL validation of the instantiated graph reports 0 violations; the internal validation graph holds
  2,762,631 triples over 216,442 annotation rows, 261 cases and 625 TR codes.
- The static mapping check reports 0 hard violations; 35,895 surface-level heuristic flags are reported
  separately by class, never mixed into the compliance rate.
- Cross-language validation: 100 bilingual label pairs (96 Pass) and 600 sampled records over the six
  language × mapping-type strata (577 Pass, 96.17%, CI 94.31–97.43%); 4 pair and 23 record corrections
  were confirmed by the authors, with 0 bidirectional conflicts over 448 unique pairs.

## 4.4 usability

40 competency-question tests over 12 CQ categories (12 baseline, 22 single-corpus, 4 second-pass and
2 paired tests). Reviewed answers: 37 / 40 Pass with the evidence-aware representation, 16 / 40 Pass
with the simplified SPO projection; field-level support is 40 / 40 for the evidence-aware view.

## Language convention in these packages

- Column headers and controlled verdicts/statuses are English (`Pass`, `Fail`, `Passed`, `Failed`,
  `Correct`, `Incorrect`, `Reviewed`, `No Correction Needed`, `Corrected (Author-Confirmed)`).
- Annotation content (source expressions, knowledge units, article titles) stays in its source language.
- The 4.3 review workbooks keep the reviewers' original notes and carry their English rendering in
  `Confirmed Issue (EN)`, `Correction Details or Direction (EN)` and `Validation Notes (EN)`; no cell
  mixes the two languages.
