# 05_validation

```text
05_validation/
├── README.md
├── 4.1_completeness/
├── 4.2_reliability/
├── 4.3_consistency/
└── 4.4_usability/
```

## Reproduction

Each package carries its own instructions:

| Package | README |
|---|---|
| 4.1 completeness | `4.1_completeness/README.md` |
| 4.2 reliability — IAA | `4.2_reliability/IAA/README.md` |
| 4.2 reliability — accuracy experiment | `4.2_reliability/Accuracy_Experiment/README.md` |
| 4.3 consistency | `4.3_consistency/README.md` |
| 4.3 cross-language validation | `4.3_consistency/4.3_cross_language_validation_EN/README.md` |
| 4.4 usability | `4.4_usability/README.md` |
