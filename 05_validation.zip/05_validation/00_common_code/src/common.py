from __future__ import annotations
import csv,hashlib,json,re,unicodedata,random
from collections import Counter,defaultdict
from pathlib import Path

CLASS_SHEETS = ['01_普通三元组_类','02_普通三元组_属性','03_普通三元组_关系','04_规则汇总','05_传播关系_类','06_传播关系_属性','07_传播关系_关系']
HEADERS={
 CLASS_SHEETS[0]:['实体类型','实体值','文字来源','文件来源'],
 CLASS_SHEETS[1]:['类类型','分离出来的实体','属性分类','分离出来的属性值','原文','源文件'],
 CLASS_SHEETS[2]:['实体类型','实体值','关系','实体/属性类型','实体/属性值','文字来源','文件来源','本体关系类型'],
 CLASS_SHEETS[3]:['源文件','研究案例','标题块','知识单元（原文）','规则要素','规则内容'],
 CLASS_SHEETS[4]:['实体类型','实体值','原文','源文件','传播关系实例','实例角色'],
 CLASS_SHEETS[5]:['类类型','分离出来的实体','属性分类','分离出来的属性值','原文','源文件','传播关系实例'],
 CLASS_SHEETS[6]:['实体类型','实体值','关系','实体/属性类型','实体/属性值','文字来源','文件来源','本体关系类型','传播关系实例','记录角色','原主表对应行号'],
}
ONTO_HEADERS={
 '类':['一级类','二级类','三级类','四级类','分类维度/依据','继承/扩展来源'],
 '属性':['所属类','属性范畴','一级属性','二级属性','分类维度/依据','取值或作用对象','说明','继承/扩展来源','统一归类及取值边界'],
 '语义关系':['语义关系','主体类','客体类','关系类别','关系说明','继承/扩展来源','原文表达与推理安全约束'],
}
SOURCE_KEYS={CLASS_SHEETS[0]:'文件来源',CLASS_SHEETS[1]:'源文件',CLASS_SHEETS[2]:'文件来源',CLASS_SHEETS[3]:'源文件',CLASS_SHEETS[4]:'源文件',CLASS_SHEETS[5]:'源文件',CLASS_SHEETS[6]:'文件来源'}
EVIDENCE_KEYS={CLASS_SHEETS[0]:'文字来源',CLASS_SHEETS[1]:'原文',CLASS_SHEETS[2]:'文字来源',CLASS_SHEETS[3]:'知识单元（原文）',CLASS_SHEETS[4]:'原文',CLASS_SHEETS[5]:'原文',CLASS_SHEETS[6]:'文字来源'}
STATUS=['正确','部分正确','错误','无法核实']
TR_CLASSES=['明确传播关联','传播关联主张/感染来源推断','证据性线索','一般机制/环境风险','无法核实']


def norm(v): return unicodedata.normalize('NFKC',str(v or '')).strip().casefold()
def same(v): return re.sub(r'\s+','',norm(v))
def cleaned_name(v):
    n=norm(v).replace('／','/').replace('：',':')
    n=re.sub(r'\.(pdf|docx?|xlsx?)$','',n)
    return re.sub(r'[^\w\u4e00-\u9fff]','',n)
def case_code(v):
    m=re.match(r'^\s*(\d{3})(?:[_\s\-]|$)',str(v or ''))
    return m.group(1) if m else ''
def source(row):return row.get(SOURCE_KEYS.get(row['_sheet'],''),'')
def evidence(row):return row.get(EVIDENCE_KEYS.get(row['_sheet'],''),'')
def tr_code(row):return row.get('传播关系实例','')
def source_key(lang,v):return lang+'|'+cleaned_name(v)
def short_hash(*args):return hashlib.sha256('|'.join(map(str,args)).encode('utf-8')).hexdigest()[:20]
def sha256(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for buf in iter(lambda:f.read(1024*1024),b''):h.update(buf)
    return h.hexdigest()

def write_csv(path,rows,columns=None):
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    rows=list(rows)
    if columns is None:
        columns=list(dict.fromkeys(k for r in rows for k in r.keys())) if rows else ['说明']
    with path.open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=columns,extrasaction='ignore');writer.writeheader();writer.writerows(rows)
    return len(rows)

def read_csv(path):
    p=Path(path)
    if not p.exists():return []
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))

def jdump(path,obj):
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(obj,ensure_ascii=False,indent=2,default=str),encoding='utf-8')

def stratum_rows(rows,sheet):
    if sheet in ('01_普通三元组_类','02_普通三元组_属性'):
        v='实体值' if sheet.startswith('01') else '分离出来的实体'
        return [r for r in rows if r.get(v) and evidence(r)]
    if sheet=='03_普通三元组_关系':return [r for r in rows if r.get('实体值') and r.get('关系') and r.get('实体/属性值') and evidence(r)]
    return []
