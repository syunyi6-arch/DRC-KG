from __future__ import annotations
import argparse,datetime,json,platform,sys
from pathlib import Path
from .common import *
from .analysis import load_inputs,issues_and_coverage,tr_audit,draw_samples,score_human
from .pdf_check import audit_pdf
from .cq import run_cqs
from .rdf_export import build_rdf


def write_report(out,stats):
    # A score-only rerun must not hide static analysis saved in previous stages.
    saved={'静态':'基础统计.json','TR':'TR结构统计.json','抽样':'样本冻结信息.json','PDF':'PDF定位统计.json','RDF':'RDF_SHACL统计.json'}
    for key,filename in saved.items():
        file=out/filename
        if key not in stats and file.exists():
            try:stats[key]=json.loads(file.read_text(encoding='utf-8'))
            except Exception:pass
    m=[
      '# 第四章技术验证：可重复运行的自动实验登记',
      '',f'生成时间：{datetime.datetime.now().isoformat(timespec="seconds")}',
      '', '**统计口径：** 原始七表行数、独立原子事实、唯一实体、TR候选编码和确认传播路径绝不混用。',
      '', '## 4.1 完整性',
      '- 语料/知识类型的分表覆盖结果见 `语料知识类型覆盖.csv`、`分表行数.csv`。',
      '- 30篇论文的源侧召回率只有在不看标注的独立金标完成、结论后才可报告。',
      '- PDF文字定位失败不能据此断言知识漏抽；扫描PDF/表格需要核对。',
      '', '## 4.2 准确性',
      '- 1000条按语种×类/属性/关系的分层样本，规则以完整知识单元抽取。',
      '- Cohen κ和严格正确率只取双评/结论的数据；结构检查不代替语义精度。',
      '- TR编码是传播相关记录，不等于确证传播链；传播路径准入需核对。',
      '', '## 4.3 一致性',
      '- Excel固定表头、术语名称映射、部分承载类及关系定义域值域已进行全量检查。',
      '- `全量静态异常清单.csv` 只记录当前仍待处理的异常；`历史已核查提示_不计入异常.csv` 独立留痕。',
      '- 2026-10-28用户确认的五类历史启发式提示仅在分类表SHA256匹配时豁免；修改输入后自动重新启用检查。',
      '- RDF生成的是带证据的研究主张图谱，未确认的研究主张不直接提升为确认事实。',
      '- SHACL在生成RDF且安装pyshacl后运行；RDFS推理不等于完整OWL2DL一致性证明。',
      '', '## 4.4 可用性',
      '- CQ1～CQ12均提供可执行的候选检索，另外提供4个SPARQL查询。',
      '- CQ6/CQ7依赖TR准入/排除分类；CQ10若缺原始表格上下文不宣称完整回答。',
      '- 答案正确率和证据追溯率须在填写独立参考答案后计算。',
      '', '## 实验状态及统计',
    ]
    for k,v in stats.items():
        if k=='初始化':continue
        m.append(f'### {k}')
        m.append('```json\n'+json.dumps(v,ensure_ascii=False,indent=2,default=str)[:18000]+'\n```')
    m+=['','## 不可预先填写为已完成的实验','- 语义准确率/源侧漏标率（未结论前）','- 传播链真实性（未经来源—目标证据裁定前）','- 完整OWL 2 DL逻辑一致性（未接入相应推理机前）','- CQ答案正确率（未提供参考答案前）']
    (out/'实验报告_自动生成.md').write_text('\n'.join(m)+'\n',encoding='utf-8')


def run():
    p=argparse.ArgumentParser(description='登革热研究案例261篇 第四章四维技术验证')
    p.add_argument('--config',default='config.json',help='JSON配置文件')
    p.add_argument('--stage',choices=['data','pdf','rdf','score','all'],default='all',help='data:静态+抽样+CQ; pdf:PDF定位; rdf:RDF+SHACL; score:评价填完后算指标')
    p.add_argument('--max-rdf-rows',type=int,default=0,help='每分表最多处理多少行(0=全部；用于首次试跑)')
    args=p.parse_args()
    cfg_file=Path(args.config).resolve()
    config=json.loads(cfg_file.read_text(encoding='utf-8-sig'))
    config['_root']=str(cfg_file.parent)
    out=(cfg_file.parent / config.get('output','outputs')).resolve()
    out.mkdir(parents=True,exist_ok=True)
    paths={k:cfg_file.parent/v for k,v in config['inputs'].items()}
    manifest=dict(UTC运行时间=datetime.datetime.now(datetime.timezone.utc).isoformat(),Python版本=sys.version,操作系统=platform.platform(),随机种子=config.get('random_seed',20261028),文件清单=[])
    for k,file in paths.items():
        manifest['文件清单'].append(dict(用途=k,文件名=file.name,存在=file.exists(),SHA256=sha256(file) if file.exists() else None,文件字节=file.stat().st_size if file.exists() else None))
    jdump(out/'输入冻结与哈希台账.json',manifest)
    stats={'初始化':{'阶段':args.stage,'输出目录':str(out)}}
    data=onto=None
    if args.stage in ('data','rdf','all'):
        print('正在读取七分表、本体及原始标注文件...',flush=True)
        paths,data,onto,raw,schemas=load_inputs(config)
        write_csv(out/'输入工作表结构异常.csv',schemas,['文件','语种','工作表','检查项','期望','实际','级别'])
        print('读取完成。',flush=True)
    if args.stage in ('data','all'):
        print('开展全量静态映射、覆盖统计、TR跨表检查、分层抽样...',flush=True)
        _,stats['静态'],_=issues_and_coverage(data,onto,raw,paths,out,config=config)
        stats['TR']=tr_audit(data,out)
        stats['抽样']=draw_samples(data,config,out)
        print('执行12项能力问题检索...',flush=True)
        cqs=run_cqs(data,out)
        stats['CQ']={'已生成问题数':len(cqs),'需确认答案数':len(cqs),'CQ6_CQ7特别说明':'定向传播核对未完成时结果为空，不等于已经判定无传播关联'}
    if args.stage in ('pdf','all'):
        print('检查本地PDF目录与来源证据候选定位...',flush=True)
        stats['PDF']=audit_pdf(config,out)
    if args.stage in ('rdf','all'):
        print('实例化RDF并进行SHACL（如已安装依赖）...',flush=True)
        stats['RDF']=build_rdf(data,onto,out,max_rows_per_sheet=args.max_rdf_rows)
    if args.stage in ('score','all','data'):
        print('仅依据已经填写的逐项结论汇总指标...',flush=True)
        stats['评价']=score_human(out)
    write_report(out,stats)
    print('完成。输出：',out,flush=True)
    print('实验报告：',out/'实验报告_自动生成.md',flush=True)

if __name__=='__main__':run()
