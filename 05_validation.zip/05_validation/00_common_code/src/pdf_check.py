"""PDF inventory and conservative page-level evidence backtracking.
No OCR is performed automatically; failed literal match is NOT treated as a false statement.
"""
from __future__ import annotations
from pathlib import Path
from collections import defaultdict
from difflib import SequenceMatcher
import re
from .common import *


def make_inventory(config,output):
    folders={'CN':Path(config['pdf_cn']),'EN':Path(config['pdf_en'])}
    inventory={}
    for lang,folder in folders.items():
        inventory[lang]=[]
        if folder.is_dir():
            inventory[lang]=sorted((p for p in folder.rglob('*') if p.is_file() and p.suffix.lower()=='.pdf'),key=lambda x:x.name)
    rows=[dict(语种=lang,PDF文件=str(p),文件名=p.name,案例编号=case_code(p.stem),SHA256=sha256(p)) for lang,files in inventory.items() for p in files]
    write_csv(output/'PDF原文清单及哈希.csv',rows,['语种','PDF文件','文件名','案例编号','SHA256'])
    return inventory


def resolve_pdf(inventory,lang,src):
    files=inventory.get(lang,[])
    exact=[p for p in files if cleaned_name(p.stem)==cleaned_name(src)]
    if len(exact)==1:return exact[0],'完整文件名匹配'
    if len(exact)>1:return None,'同名PDF不唯一'
    code=case_code(src)
    subset=[p for p in files if case_code(p.stem)==code] if code else []
    if len(subset)==1:
        a=cleaned_name(src);b=cleaned_name(subset[0].stem)
        # Filenames often differ in suffix author/year; ID alone is insufficient for asserting identity.
        score=SequenceMatcher(None,a,b).ratio()
        if score>=0.62:return subset[0],f'编号+标题相似候选({score:.2f});须确认'
        return None,f'同编号标题差异过大({score:.2f});需查找'
    if len(subset)>1:return None,f'同编号存在{len(subset)}个PDF候选'
    return None,'未找到对应PDF'


def normalize_pdf_text(s):
    s=norm(s)
    return re.sub(r'[\s\u00ad\u200b]+','',s)


def audit_pdf(config,output):
    inv=make_inventory(config,output)
    import importlib
    try: fitz=importlib.import_module('fitz')
    except ImportError:fitz=None
    requests=[]
    for r in read_csv(output/'1000条准确性核对模板.csv'):
        requests.append(dict(语种=r.get('语种',''),源文件=r.get('源文件',''),样本ID=r.get('样本ID'),原文证据=r.get('原文证据','')))
    for r in read_csv(output/'30篇独立金标论文抽样.csv'):
        requests.append(dict(语种=r.get('语种',''),源文件=r.get('源文件',''),样本ID='GOLD-PDF',原文证据=''))
    for r in read_csv(output/'TR全量核对模板.csv'):
        requests.append(dict(语种=r.get('语种',''),源文件=r.get('来源论文','').split(';')[0].strip(),样本ID=r.get('TR编码'),原文证据=r.get('原文证据摘录','')))
    pages_cache={};answers=[]
    for r in requests:
        path,status=resolve_pdf(inv,r['语种'],r['源文件'])
        row=dict(语种=r['语种'],源文件=r['源文件'],样本ID=r['样本ID'],PDF文件名=path.name if path else '',PDF匹配状态=status,自动证据定位状态='',候选PDF页码='',证据片段=r['原文证据'][:500],确认PDF身份='',确认页码='')
        if not path: row['自动证据定位状态']='PDF不可对应/未找到';answers.append(row);continue
        if not fitz: row['自动证据定位状态']='未安装pymupdf';answers.append(row);continue
        if path not in pages_cache:
            try:
                doc=fitz.open(path)
                pages_cache[path]=[normalize_pdf_text(page.get_text('text')) for page in doc]
                doc.close()
            except Exception as ex:
                pages_cache[path]=[]
                row['自动证据定位状态']='PDF解析出错:'+str(ex)[:80]
        pages=pages_cache[path]
        quote=normalize_pdf_text(r['原文证据'])
        if not quote: row['自动证据定位状态']='仅建档，等待独立全文金标'
        elif not any(pages):row['自动证据定位状态']='无可提取文本层，需查看扫描PDF'
        else:
            hit=[]
            # Long text in a row may combine table context or wrap; provide candidate only.
            for page_i,body in enumerate(pages):
                if quote in body or (len(quote)>60 and quote[:60] in body):hit.append(page_i+1)
            row['自动证据定位状态']='页面字符串候选匹配' if hit else '字符串未定位；不能自动判为错误/漏标'
            row['候选PDF页码']=';'.join(map(str,hit))
        answers.append(row)
    write_csv(output/'PDF与标注的证据定位候选.csv',answers)
    stats=dict(PDF数量={k:len(v) for k,v in inv.items()},抽样源检索数=len(answers),自动匹配成功数=sum(x['自动证据定位状态']=='页面字符串候选匹配' for x in answers),注意='PDF文本未匹配不等于语义错误或漏标；扫描版图表需核对。')
    jdump(output/'PDF定位统计.json',stats)
    return stats
