"""Streaming XLSX reader; does not modify any of the user's seven or three source sheets."""
from __future__ import annotations
from pathlib import Path
from zipfile import ZipFile
from xml.etree import ElementTree as ET
import re

MAIN = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'
REL = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
TAG = lambda name: '{'+MAIN+'}'+name


def cell_index(ref: str) -> int:
    letters = re.match('[A-Z]+', ref).group(0)
    n=0
    for ch in letters: n=n*26+ord(ch)-64
    return n-1


def workbook_names(path: Path) -> dict[str,str]:
    with ZipFile(path) as z:
        root = ET.fromstring(z.read('xl/workbook.xml'))
        rels = ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
        targets = {rel.attrib['Id']:rel.attrib['Target'] for rel in rels}
        ans = {}
        for sh in root.iter(TAG('sheet')):
            target=targets[sh.attrib['{'+REL+'}id']]
            part=target.lstrip('/') if target.startswith('/') else 'xl/'+target
            ans[sh.attrib['name']]=part
        return ans


def sheet_rows(path: Path, sheet: str):
    """Yield (Excel row number, values list), preserving original text/number strings."""
    with ZipFile(path) as z:
        names = workbook_names(path)
        if sheet not in names: raise KeyError(f'{path.name}: 找不到表 {sheet}')
        strings=[]
        if 'xl/sharedStrings.xml' in z.namelist():
            # Iterparse for large shared-string tables
            with z.open('xl/sharedStrings.xml') as stream:
                for _, elem in ET.iterparse(stream,events=('end',)):
                    if elem.tag == TAG('si'):
                        strings.append(''.join((e.text or '') for e in elem.iter(TAG('t'))))
                        elem.clear()
        with z.open(names[sheet]) as stream:
            for _, elem in ET.iterparse(stream,events=('end',)):
                if elem.tag != TAG('row'): continue
                values={}
                for cell in elem.findall(TAG('c')):
                    ix=cell_index(cell.attrib['r'])
                    v=cell.find(TAG('v'))
                    typ=cell.attrib.get('t','')
                    if typ == 'inlineStr':
                        inner=cell.find(TAG('is'))
                        val=''.join((e.text or '') for e in inner.iter(TAG('t'))) if inner is not None else ''
                    else: val=v.text if v is not None and v.text is not None else ''
                    if typ=='s' and val: val=strings[int(val)]
                    values[ix]=val
                if values:
                    arr=['']*(max(values)+1)
                    for i,val in values.items(): arr[i]=val or ''
                    yield int(elem.attrib['r']),arr
                elem.clear()


def load_sheet(path:Path, sheet:str,lang:str='',prefix:str='') -> tuple[list[str],list[dict]]:
    iterator=iter(sheet_rows(path,sheet))
    try: _,headers=next(iterator)
    except StopIteration: return [],[]
    headers=[str(h).strip() for h in headers]
    result=[]
    for rn,values in iterator:
        if not any(str(v).strip() for v in values):continue
        row={header:str(values[ix]).strip() if ix<len(values) else '' for ix,header in enumerate(headers) if header}
        row.update(_row=rn,_sheet=sheet,_lang=lang,_source_type=prefix)
        result.append(row)
    return headers,result
