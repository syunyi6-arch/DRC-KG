"""Auditable four-dimensional validation for dengue research-case corpus.
Machine suggestions are NEVER equated to independent human semantic gold labels.
"""
from __future__ import annotations
from pathlib import Path
from collections import Counter,defaultdict
from difflib import SequenceMatcher
import csv,json,random,re,statistics,math
from .xlsxio import workbook_names,load_sheet
from .common import *


def load_inputs(config):
    base=Path(config['_root'])
    paths={k:base / v for k,v in config['inputs'].items()}
    data={}; headers={}; schemas=[]
    for lang,key in [('CN','classified_cn'),('EN','classified_en')]:
        p=paths[key]
        if not p.exists():raise FileNotFoundError(str(p))
        current=workbook_names(p)
        for s in CLASS_SHEETS:
            if s not in current:
                schemas.append(dict(文件=p.name,语种=lang,工作表=s,检查项='缺少工作表',期望='存在',实际='缺失',级别='确定问题'))
                data[(lang,s)]=[];headers[(lang,s)]=[];continue
            h,rows=load_sheet(p,s,lang,'classified')
            data[(lang,s)]=rows;headers[(lang,s)]=h
            if h != HEADERS[s]:
                schemas.append(dict(文件=p.name,语种=lang,工作表=s,检查项='表头及顺序',期望=' | '.join(HEADERS[s]),实际=' | '.join(h),级别='确定问题'))
        for s in current:
            if s not in CLASS_SHEETS:schemas.append(dict(文件=p.name,语种=lang,工作表=s,检查项='额外工作表',期望='七表不增删',实际='存在',级别='需确认'))
    ontology={}
    p=paths['ontology']
    for s in ONTO_HEADERS:
        if s not in workbook_names(p):
            schemas.append(dict(文件=p.name,工作表=s,检查项='本体缺少工作表',级别='确定问题'))
            ontology[s]=[];continue
        h,rows=load_sheet(p,s,'','ontology')
        ontology[s]=rows
        if h!=ONTO_HEADERS[s]:schemas.append(dict(文件=p.name,工作表=s,检查项='表头及顺序',期望=' | '.join(ONTO_HEADERS[s]),实际=' | '.join(h),级别='确定问题'))
    # Raw workbooks are used for evidence/cross-representation checks, not to overwrite seven sheets.
    raw={}
    for lang,key in [('CN','raw_cn'),('EN','raw_en')]:
        p=paths.get(key)
        if not p or not p.exists():raw[lang]={};continue
        raw[lang]={}
        for name in ('三元组','规则','传播关系'):
            if name in workbook_names(p):
                h,rr=load_sheet(p,name,lang,'unclassified')
                raw[lang][name]=rr
        # optional audit-only sheet not used as omission gold
    return paths,data,ontology,raw,schemas


def ontology_index(onto):
    classes={};parents=defaultdict(set)
    # Indented hierarchy: children without an explicit parent use last-known node at preceding level.
    last={}
    for row in onto.get('类',[]):
        hierarchy=[norm(row.get(x,'')) for x in ('一级类','二级类','三级类','四级类')]
        for d,label in enumerate(hierarchy):
            if not label:continue
            classes[label]=row['_row']
            if d>0 and last.get(d-1):parents[label].add(last[d-1])
            last[d]=label
            for deeper in (d+1,d+2,d+3):last.pop(deeper,None)
    attrs=defaultdict(list)
    for row in onto.get('属性',[]):
        owner=norm(row.get('所属类'))
        for key in ('一级属性','二级属性'):
            label=norm(row.get(key))
            if label:attrs[label].append((owner,row['_row']))
    rels=defaultdict(list)
    for row in onto.get('语义关系',[]):
        label=norm(row.get('语义关系'))
        if label:rels[label].append(row)
    def ancestors(item):
        visited={item};stack=list(parents.get(item,()))
        while stack:
            s=stack.pop()
            if s in visited:continue
            visited.add(s);stack+=list(parents.get(s,()))
        return visited
    return dict(classes=classes,parents=parents,attrs=attrs,rels=rels,ancestors=ancestors)


def classify_domain(actual,rule,idx):
    if not actual or not rule:return '无法判定'
    options=[norm(x) for x in re.split(r'[、,，/；;]|\bor\b',rule) if norm(x)]
    a=idx['ancestors'](norm(actual))
    if any(x in a for x in options):return '匹配'
    # Domain descriptions sometimes contain logical disjunction in full natural-language statements;
    # do not claim definite ontology inconsistency without expert appraisal.
    return '建议核对'


# 2026-10-28 用户反馈：以下五种纯表面启发式提示已在本批1026版数据中核对，
# 不代表结构性错误。确认豁免必须同时与配置项、文件SHA256匹配。
REVIEWABLE_HEURISTICS = frozenset({
    '主体原文字符串未定位', '英文原文属性值含汉字', '纯数值实体',
    '纯数值被用作实体', '英文原文实体值含汉字'
})

def apply_reviewed_policy(candidates, config, paths):
    """将已核查的*历史启发式提示*与真正待处理的异常分开存档。

    不根据检查类型全局放行；必须是指定版本的两份七表文件且
    配置的SHA256逐一吻合。新增或修改数据自动撤销豁免。
    本函数不改变七分表、不修改标注，亦不将豁免推算为准确率。
    """
    policy=config.get('reviewed_heuristics',{}) if config else {}
    rules=set(policy.get('check_items',[])) & REVIEWABLE_HEURISTICS
    expected=policy.get('classified_sha256',{})
    actual={k:sha256(paths[k]) if k in paths and paths[k].is_file() else None
            for k in ('classified_cn','classified_en')}
    matching=bool(rules) and all(actual[k] and actual[k]==expected.get(k) for k in actual)
    accepted=[]; still_open=[]
    for item in candidates:
        if matching and item.get('级别')=='需核对' and item.get('检查项') in rules:
            accepted.append({**item,
                '确认状态':'已核查通过（用户确认）',
                '确认依据':policy.get('approval_basis','用户已核对并反馈无问题'),
                '确认数据版本':'1026版分类表（SHA256固定）',
                '说明':item.get('说明','')+'；此条为历史启发式提示，已从待处理异常中移出'})
        else:
            still_open.append(item)
    state={
        '策略':'只对确认通过且输入SHA256一致的五类历史启发式提示豁免',
        '版本校验通过':matching,
        '指定确认项':sorted(rules),
        '实际SHA256':actual,
        '配置SHA256':expected,
        '历史启发式提示候选数':len(candidates),
        '其中已核查通过数':len(accepted),
        '仍需处理的静态异常数':len(still_open),
        '确认依据':policy.get('approval_basis',''),
        '说明':('本次有效，只有已核查通过的启发式提示被移除。'
                  if matching else '文件已变化或未启用确认策略，未自动豁免，需重新核查。')
    }
    return still_open,accepted,state


def issues_and_coverage(data,ontology,raw,paths,output,config=None):
    idx=ontology_index(ontology)
    bad=[];used={k:set() for k in ['类','属性','语义关系']}
    coverage=Counter();papers=defaultdict(set);rowstat=Counter()
    raw_ids={}
    for lang in ('CN','EN'):
        raw_ids[lang]=set()
        for row in raw.get(lang,{}).get('三元组',[]):
            raw_ids[lang].add((source_key(lang,row.get('源文件')),str(row['_row'])))
    for (lang,sheet),rows in data.items():
        for row in rows:
            text=evidence(row)
            src=source(row)
            rid=f'{lang}/{sheet}/{row["_row"]}'
            rowstat[(lang,sheet)]+=1
            if src:papers[lang].add(cleaned_name(src))
            else:bad.append(dict(语种=lang,工作表=sheet,Excel行=row['_row'],源文件='',检查项='源文件缺失',对象='',级别='确定问题',说明='源文件字段为空'))
            if not text:
                bad.append(dict(语种=lang,工作表=sheet,Excel行=row['_row'],源文件=src,检查项='原文证据为空',对象='',级别='确定问题',说明='需从原PDF定位'))
            typ=row.get('实体类型') or row.get('类类型')
            if typ:
                used['类'].add(norm(typ))
                if norm(typ) not in idx['classes']:
                    bad.append(dict(语种=lang,工作表=sheet,Excel行=row['_row'],源文件=src,检查项='类标签未命中本体',对象=typ,级别='确定问题',说明='名称检查；不等于判断本体应该新增'))
                coverage[(lang,'类:'+typ)]+=1
            if sheet in (CLASS_SHEETS[2],CLASS_SHEETS[6]):
                second=row.get('实体/属性类型','')
                if second:
                    # second column may legitimately refer to a class or an attribute.
                    if norm(second) in idx['classes']:used['类'].add(norm(second))
                    elif norm(second) in idx['attrs']:used['属性'].add(norm(second))
                    else:
                        bad.append(dict(语种=lang,工作表=sheet,Excel行=row['_row'],源文件=src,检查项='客体类型不在类/属性词表',对象=second,级别='确定问题',说明='检查是否漏映射或需修订'))
                mapped=row.get('本体关系类型','')
                if not mapped:
                    bad.append(dict(语种=lang,工作表=sheet,Excel行=row['_row'],源文件=src,检查项='本体关系类型缺失',对象=row.get('关系',''),级别='确定问题',说明='不可用原文关系直接替代本体谓词'))
                else:
                    used['语义关系'].add(norm(mapped))
                    if norm(mapped) not in idx['rels']:
                        bad.append(dict(语种=lang,工作表=sheet,Excel行=row['_row'],源文件=src,检查项='本体关系未命中',对象=mapped,级别='确定问题',说明='需重做语义映射'))
                    else:
                        spec=idx['rels'][norm(mapped)][0]
                        res1=classify_domain(typ,spec.get('主体类',''),idx)
                        res2=classify_domain(second,spec.get('客体类',''),idx) if norm(second) in idx['classes'] else '无法判定'
                        if res1=='建议核对' or res2=='建议核对':
                            bad.append(dict(语种=lang,工作表=sheet,Excel行=row['_row'],源文件=src,检查项='关系定义域/值域需核对',对象=mapped,级别='需核对',说明=f'主体={typ}/{spec.get("主体类","")}:{res1};客体={second}/{spec.get("客体类","")}:{res2}'))
                if not row.get('关系') or not row.get('实体值') or not row.get('实体/属性值'):
                    bad.append(dict(语种=lang,工作表=sheet,Excel行=row['_row'],源文件=src,检查项='普通关系必需项缺失',对象='',级别='确定问题',说明='至少需主体、谓词、客体'))
                # Original evidence-string checks are heuristics only (not semantic adjudication).
                if text and len(text)>=10 and row.get('实体值') and same(row['实体值']) not in same(text):
                    bad.append(dict(语种=lang,工作表=sheet,Excel行=row['_row'],源文件=src,检查项='主体原文字符串未定位',对象=row['实体值'],级别='需核对',说明='可能是指代消解、排版差异或原文截断；非自动判错'))
                obj=row.get('实体/属性值','')
                if norm(second) in idx['classes'] and obj and re.fullmatch(r'[0-9.,%％]+',obj):
                    bad.append(dict(语种=lang,工作表=sheet,Excel行=row['_row'],源文件=src,检查项='纯数值被用作实体',对象=obj,级别='需核对',说明='数值通常应表达为属性，但须结合原文检查'))
            if sheet in (CLASS_SHEETS[1],CLASS_SHEETS[5]):
                attr=row.get('属性分类','')
                if attr:
                    used['属性'].add(norm(attr));coverage[(lang,'属性:'+attr)]+=1
                    if norm(attr) not in idx['attrs']:
                        bad.append(dict(语种=lang,工作表=sheet,Excel行=row['_row'],源文件=src,检查项='属性标签未命中本体',对象=attr,级别='确定问题',说明='词表精确匹配'))
                    elif typ:
                        owners={x[0] for x in idx['attrs'][norm(attr)]}
                        if not idx['ancestors'](norm(typ)).intersection(owners):
                            bad.append(dict(语种=lang,工作表=sheet,Excel行=row['_row'],源文件=src,检查项='属性承载类可能不符合本体定义',对象=f'{typ}｜{attr}',级别='需核对',说明='当前本体所属类: '+';'.join(sorted(owners))))
                if lang=='EN':
                    val=row.get('分离出来的属性值','')
                    if val and re.search('[\u4e00-\u9fff]',val):
                        bad.append(dict(语种=lang,工作表=sheet,Excel行=row['_row'],源文件=src,检查项='英文原文属性值含汉字',对象=val[:180],级别='需核对',说明='检查是否误将中文解释写入英文值'))
            if sheet in (CLASS_SHEETS[0],CLASS_SHEETS[4]):
                val=row.get('实体值','')
                if val and re.fullmatch(r'[\d.,%％]+',val):
                    bad.append(dict(语种=lang,工作表=sheet,Excel行=row['_row'],源文件=src,检查项='纯数值实体',对象=val,级别='需核对',说明='通常应为属性值'))
                if lang=='EN' and val and re.search('[\u4e00-\u9fff]',val):
                    bad.append(dict(语种=lang,工作表=sheet,Excel行=row['_row'],源文件=src,检查项='英文原文实体值含汉字',对象=val,级别='需核对',说明='核实是否中文翻译干扰原文'))
    # Vocabulary usage: defined term != ontology row count.
    vocab={
      '类':set(idx['classes']), '属性':set(idx['attrs']), '语义关系':set(idx['rels'])
    }
    vocab_report=[]
    for typ in ('类','属性','语义关系'):
        matches=used[typ] & vocab[typ]
        vocab_report.append(dict(词汇类型=typ,本体定义去重术语数=len(vocab[typ]),标注使用去重术语数=len(used[typ]),已匹配去重术语数=len(matches),未匹配使用词汇数=len(used[typ]-vocab[typ]),本体术语使用率=f'{len(matches)/len(vocab[typ]):.6f}' if vocab[typ] else '',标注词汇名称匹配率=f'{len(matches)/len(used[typ]):.6f}' if used[typ] else '',备注='仅标签匹配，不等于语义正确率'))
    for typ in ('类','属性','语义关系'):
        write_csv(output/f'未使用本体术语_{typ}.csv',[{'术语':v} for v in sorted(vocab[typ]-used[typ])],['术语'])
    # 仅对已经由用户确认核查通过、且绑定文件哈希的历史五类表面提示放行。
    # 其他本体映射、缺失字段、关系域值域与跨表检查继续执行。
    unresolved,reviewed,policy_state=apply_reviewed_policy(bad,config,paths)
    write_csv(output/'全量静态异常清单.csv',unresolved,['语种','工作表','Excel行','源文件','检查项','对象','级别','说明'])
    write_csv(output/'历史已核查提示_不计入异常.csv',reviewed,
              ['语种','工作表','Excel行','源文件','检查项','对象','级别','说明','确认状态','确认依据','确认数据版本'])
    jdump(output/'静态检查确认策略执行状态.json',policy_state)
    # This is ONLY a textual crosswalk between the supplied unclassified source and seven-sheet
    # representations; it is NOT a semantic ground-truth recall measure.
    raw_cross=[];raw_summary=[]
    for lang in ('CN','EN'):
        seen=set()
        for sheet in (CLASS_SHEETS[0],CLASS_SHEETS[1],CLASS_SHEETS[2]):
            for r in data.get((lang,sheet),[]):
                src_id=case_code(source(r)) or cleaned_name(source(r))
                if evidence(r):seen.add((src_id,same(evidence(r))))
        unique={}
        for r in raw.get(lang,{}).get('三元组',[]):
            src=r.get('源文件','');ev=r.get('知识单元原文内容','')
            if not ev:continue
            key=(case_code(src) or cleaned_name(src),same(ev))
            unique.setdefault(key,r)
        hit=sum(k in seen for k in unique)
        raw_summary.append(dict(语种=lang,未分类主表不同原文知识单元数=len(unique),七表中原文精确字符串命中数=hit,未命中需核对数=len(unique)-hit,字符串表面匹配率=f'{hit/len(unique):.6f}' if unique else '',重要说明='这是原文字符串表面检查，不是知识事实召回率；拆分、截断、规范化变化均可能造成未命中'))
        for key,r in unique.items():
            if key not in seen:
                raw_cross.append(dict(语种=lang,源文件=r.get('源文件'),原始主表行号=r['_row'],标题块=r.get('标题块',''),原文知识单元=r.get('知识单元原文内容'),自动标记='七表正文证据未按完整字符串精确匹配',确认是否真正遗漏='',备注='同一事实可能改写或拆分，必须对照原PDF与分类表后确认'))
    write_csv(output/'未分类与七分表_原文表面对应检查.csv',raw_cross)
    write_csv(output/'未分类与七分表_原文表面对应统计.csv',raw_summary)
    write_csv(output/'本体词汇使用率.csv',vocab_report)
    write_csv(output/'分表行数.csv',[dict(语种=l,工作表=s,有效数据行数=rowstat[l,s]) for l in ('CN','EN') for s in CLASS_SHEETS])
    coverage_rows=[]
    for lang in ('CN','EN'):
        for sheet in CLASS_SHEETS:
            by=defaultdict(set);count=Counter()
            for r in data[(lang,sheet)]:
                if sheet in (CLASS_SHEETS[0],CLASS_SHEETS[4]): k=r.get('实体类型')
                elif sheet in (CLASS_SHEETS[1],CLASS_SHEETS[5]): k='属性:'+r.get('属性分类','')
                elif sheet in (CLASS_SHEETS[2],CLASS_SHEETS[6]): k='关系:'+r.get('本体关系类型','')
                else: k='规则'
                if not k:continue
                count[k]+=1
                if source(r):by[k].add(case_code(source(r)) or cleaned_name(source(r)))
            for label,n in sorted(count.items()):
                coverage_rows.append(dict(语种=lang,表=sheet,知识类型=label,具备记录的不同论文数=len(by[label]),有效记录行数=n,统计说明='仅报告已有标注分布；空白不代表原文漏标'))
    write_csv(output/'语料知识类型覆盖.csv',coverage_rows)
    # Detect distinct filename variants attached to a single three-digit paper ID.
    source_forms=defaultdict(set)
    for lang,variants in papers.items():
        for v in variants:
            source_forms[(lang,case_code(v) or v)].add(v)
    write_csv(output/'论文编号与源文件命名变体.csv',[
        dict(语种=lang,论文编号=code,源文件变体数=len(forms),归一名称=' | '.join(sorted(forms)),需核对是否同一论文='是' if len(forms)>1 else '否')
        for (lang,code),forms in sorted(source_forms.items())
        if len(forms)>1
    ],['语种','论文编号','源文件变体数','归一名称','需核对是否同一论文'])
    paper_codes={lang:{case_code(x) or x for x in vals} for lang,vals in papers.items()}
    overview=dict(论文源文件名称变体数={k:len(v) for k,v in papers.items()},按三位论文编号去重篇数={k:len(v) for k,v in paper_codes.items()},分表行数={f'{k[0]}:{k[1]}':v for k,v in rowstat.items()},静态异常总数=len(unresolved),静态异常分类=dict(Counter(x['检查项'] for x in unresolved)),历史已核查提示数=len(reviewed),确认策略版本校验通过=policy_state['版本校验通过'],本体词汇=vocab_report)
    jdump(output/'基础统计.json',overview)
    return idx,overview,unresolved


def tr_audit(data,output):
    groups=defaultdict(lambda:dict(sources=set(),sheets=defaultdict(list),evidences=set()))
    for (lang,sheet),rows in data.items():
        if sheet not in CLASS_SHEETS[4:]:continue
        for r in rows:
            code=tr_code(r)
            if not code:continue
            x=groups[(lang,code)];x['sources'].add(cleaned_name(source(r)))
            x['sheets'][sheet].append(r)
            if evidence(r):x['evidences'].add(evidence(r))
    out=[];alarms=[]
    for (lang,code),g in sorted(groups.items()):
        has=[len(g['sheets'][s]) for s in CLASS_SHEETS[4:]]
        kinds=sorted(set(r.get('记录角色','') for r in g['sheets'][CLASS_SHEETS[6]] if r.get('记录角色')))
        srcs=sorted(g['sources']-set(['']))
        texts=sorted(g['evidences'],key=len,reverse=True)
        out.append(dict(语种=lang,TR编码=code,来源论文='; '.join(srcs),类行数=has[0],属性行数=has[1],关系行数=has[2],关系行角色='; '.join(kinds),来源文件是否混用='是' if len(srcs)>1 else '否',原文证据摘录=(texts[0][:1500] if texts else ''),传播主张分类='',具体来源文本='',具体目标文本='',源目标证据是否充分='',证据类型='',不确定性限定是否保留='',应有关系链接='',是否准入具体传播路径子图='',确认人1='',确认人2='',结论='',核对PDF页码='',排除原因='',整改情况=''))
        if len(srcs)>1:alarms.append(dict(语种=lang,TR编码=code,级别='确定问题',问题='同TR编码跨论文使用',来源=';'.join(srcs)))
        if not has[0]:alarms.append(dict(语种=lang,TR编码=code,级别='需核对',问题='无传播类行',来源=';'.join(srcs)))
        if not has[1]:alarms.append(dict(语种=lang,TR编码=code,级别='需核对',问题='无传播属性行',来源=';'.join(srcs)))
        if not has[2]:alarms.append(dict(语种=lang,TR编码=code,级别='需核对',问题='无传播关系行；可能设计上不需要来源目标链接，不能自动判漏',来源=';'.join(srcs)))
    path=output/'TR全量核对模板.csv'
    if not path.exists():write_csv(path,out)
    write_csv(output/'TR跨表结构异常.csv',alarms,['语种','TR编码','级别','问题','来源'])
    summary=dict(TR唯一编码数=len(groups),按语种=dict(Counter(k[0] for k in groups)),关系行覆盖的TR数=sum(bool(g['sheets'][CLASS_SHEETS[6]]) for g in groups.values()),注意='传播相关TR编码数绝不等于已证实传播链数。未出现关系行可能属于非定向研究主张。')
    jdump(output/'TR结构统计.json',summary)
    return summary


def source_catalog(data):
    grouped={}
    for (lang,sheet),rows in data.items():
        for r in rows:
            src=source(r)
            if not src:continue
            code=case_code(src)
            k=(lang,code or cleaned_name(src))
            if k not in grouped:grouped[k]=dict(语种=lang,源文件=src,案例编号=code,有效记录数=0,类别=Counter(),名称变体=Counter())
            grouped[k]['有效记录数']+=1
            grouped[k]['类别'][sheet]+=1
            grouped[k]['名称变体'][src]+=1
    for x in grouped.values():
        # Count one paper per stable (language, 3-digit file code), but preserve all variants for QA.
        x['源文件']=x['名称变体'].most_common(1)[0][0]
    return grouped


def draw_samples(data,config,output):
    seed=config.get('random_seed',20261028);rng=random.Random(seed)
    samples=[];sample_stats=[]
    for lang in ('CN','EN'):
        for sheet,n in [(CLASS_SHEETS[0],100),(CLASS_SHEETS[1],150),(CLASS_SHEETS[2],250)]:
            population=stratum_rows(data[(lang,sheet)],sheet)
            sample=rng.sample(population,min(n,len(population)))
            for r in sample:
                samples.append(dict(样本ID=f'ACC-{lang}-{len(samples)+1:05d}',语种=lang,抽样层=sheet,源文件=source(r),Excel行号=r['_row'],原文证据=evidence(r),主体或实体=r.get('实体值',r.get('分离出来的实体','')),谓词或属性=r.get('关系',r.get('属性分类','')),客体或值=r.get('实体/属性值',r.get('分离出来的属性值','')),本体映射=r.get('本体关系类型',''),抽样种子=seed,抽样层总体数=len(population),抽样层样本数=len(sample),论文PDF页码='',核对人1='',核对人2='',结论='',错误类别='',问题描述='',整改状态=''))
            sample_stats.append(dict(语种=lang,层=sheet,有效总体数=len(population),目标样本数=n,实际样本数=len(sample),抽样概率=f'{len(sample)/len(population):.8f}' if population else '',种子=seed))
    path=output/'1000条准确性核对模板.csv'
    if not path.exists():write_csv(path,samples)
    write_csv(output/'准确性分层抽样记录.csv',sample_stats)
    # Rules use complete (source, title, original knowledge unit), not one row per condition.
    rule_samples=[]
    for lang in ('CN','EN'):
        groups=defaultdict(list)
        for row in data[(lang,CLASS_SHEETS[3])]:
            key=(cleaned_name(source(row)),same(row.get('标题块')),same(evidence(row)))
            groups[key].append(row)
        keys=sorted(groups)
        chosen=rng.sample(keys,min(30,len(keys)))
        for key in chosen:
            rr=groups[key]
            contents='；'.join(f'{x.get("规则要素")}: {x.get("规则内容")}' for x in rr)
            rule_samples.append(dict(规则样本ID=f'RULE-{lang}-{len(rule_samples)+1:04d}',语种=lang,源文件=source(rr[0]),标题块=rr[0].get('标题块',''),知识单元原文=evidence(rr[0]),规则要素及内容=contents,拆分行数=len(rr),核对PDF页码='',核对人1='',核对人2='',结论='',错误类型='',说明=''))
    path=output/'规则完整单元核对模板.csv'
    if not path.exists():write_csv(path,rule_samples)
    catalog=source_catalog(data)
    selected=[]
    for lang in ('CN','EN'):
        sources=sorted((x for x in catalog.values() if x['语种']==lang),key=lambda x:cleaned_name(x['源文件']))
        picks=rng.sample(sources,min(15,len(sources)))
        for x in picks:
            selected.append(dict(语种=lang,源文件=x['源文件'],案例编号=x['案例编号'],抽样方法='语种分层简单随机；研究主题/复杂表格/传播推断需检查并记录是否补充目的抽样',论文PDF文件名='',PDF总页数='',研究类型_填写='',图表复杂程度_填写='',是否含传播推断_填写='',核对人员1='',核对人员2='',结论人='',金标是否完成='',备注=''))
    p=output/'30篇独立金标论文抽样.csv'
    if not p.exists():write_csv(p,selected)
    gold=output/'独立源侧金标_逐原子事实模板.csv'
    if not gold.exists():write_csv(gold,[],['金标ID','语种','源文件','PDF页码','位置类型_正文表格图注','标题块','原文知识单元','原子事实类型','头实体','关系或属性','尾实体或属性值','时间归属','空间归属','原文不确定性限定','表格分组及单位分母','核对人1','核对人2','结论','是否在现有数据正确表达_TP或FN','现有标注对应表','现有标注行号','争议及整改'])
    jdump(output/'样本冻结信息.json',dict(seed=seed,预期普通样本=1000,普通实际样本=len(samples),规则完整单元样本数=len(rule_samples),独立金标论文数=len(selected),提醒='独立金标必须由核对者在不看现有标注的前提下根据原PDF建立；此文件初始为空，抽样现有记录不能当作金标。'))
    return dict(准确性样本数=len(samples),规则完整样本数=len(rule_samples),独立金标论文数=len(selected))


def cohens_kappa(a,b):
    n=len(a)
    if n==0:return None
    labels=set(a)|set(b)
    po=sum(x==y for x,y in zip(a,b))/n
    p1=Counter(a);p2=Counter(b)
    pe=sum(p1[x]*p2[x] for x in labels)/n**2
    return (po-pe)/(1-pe) if pe<1 else (1.0 if po==1 else None)


def score_human(output):
    """Only nonblank adjudicated judgments produce observed accuracy/recall."""
    rows=read_csv(output/'1000条准确性核对模板.csv')
    scores=[];paired1=[];paired2=[]
    by=defaultdict(list)
    for r in rows:
        a,b,final=(r.get('核对人1','').strip(),r.get('核对人2','').strip(),r.get('结论','').strip())
        if a in STATUS and b in STATUS:paired1.append(a);paired2.append(b)
        if final in STATUS:by[(r['语种'],r['抽样层'])].append(r)
    # overall accuracy is unavailable until each stratum has an assessed sample.
    populations={}
    for r in read_csv(output/'准确性分层抽样记录.csv'):populations[(r['语种'],r['层'])]=int(r['有效总体数'])
    for k,rs in sorted(by.items()):
        valid=[r for r in rs if r['结论']!='无法核实']
        scores.append(dict(语种=k[0],抽样层=k[1],已结论数=len(rs),可核实数=len(valid),完全正确数=sum(r['结论']=='正确' for r in valid),部分正确数=sum(r['结论']=='部分正确' for r in valid),严格正确率=(sum(r['结论']=='正确' for r in valid)/len(valid)) if valid else '',层总体数=populations.get(k,'')))
    needed=set(populations);completed={k for k,rs in by.items() if any(r['结论']!='无法核实' for r in rs)}
    weighted=None
    all_completed=bool(rows) and all(r.get('核对人1') in STATUS and r.get('核对人2') in STATUS and r.get('结论') in STATUS for r in rows)
    if needed and completed>=needed and all_completed:
        numerator=denominator=0
        for r in scores:
            k=(r['语种'],r['抽样层']);n=populations[k]
            if r['严格正确率']!='':numerator+=n*r['严格正确率'];denominator+=n
        weighted=numerator/denominator if denominator else None
    gold=read_csv(output/'独立源侧金标_逐原子事实模板.csv')
    gold_judged=[r for r in gold if r.get('是否在现有数据正确表达_TP或FN','').strip().upper() in ('TP','FN')]
    tp=sum(r['是否在现有数据正确表达_TP或FN'].strip().upper()=='TP' for r in gold_judged)
    fn=len(gold_judged)-tp
    gold_closed=bool(gold_judged) and all(r.get('金标ID') and r.get('结论') for r in gold_judged)
    # The user must mark all selected documents as complete before presenting a 30-article recall rate.
    roster=read_csv(output/'30篇独立金标论文抽样.csv')
    done=roster and all(norm(x.get('金标是否完成','')) in ('是','已完成','yes','true','1') for x in roster)
    recall=(tp/(tp+fn)) if (done and gold_closed and tp+fn) else None
    out=dict(按层准确率=scores,严格分层总体加权正确率=weighted,准确性样本是否全部完成双人评估及结论=all_completed,准确性已裁定数=sum(len(v) for v in by.values()),准确性总抽样数=len(rows),双人独立核对有配对数=len(paired1),Cohen_kappa=cohens_kappa(paired1,paired2),源侧金标已填TP=tp,源侧金标已填FN=fn,金标30篇是否全部完成=bool(done),完整源侧召回率=recall,警告='未经过独立确认与结论的检查不可填为准确率；金标30篇未全部核完时不得报告总体召回。')
    # Supplementary adjudicated metrics: complete rules, transmission evidence and CQs.
    rule_rows=read_csv(output/'规则完整单元核对模板.csv')
    rule_good=[r for r in rule_rows if r.get('结论') in STATUS and r.get('结论')!='无法核实']
    rule_paired=[r for r in rule_rows if r.get('核对人1') in STATUS and r.get('核对人2') in STATUS]
    out['规则_完全正确率']=sum(r['结论']=='正确' for r in rule_good)/len(rule_good) if rule_good else None
    out['规则_可核实确认单元数']=len(rule_good)
    out['规则_双人Cohen_kappa']=cohens_kappa([r['核对人1'] for r in rule_paired],[r['核对人2'] for r in rule_paired])
    tr_rows=read_csv(output/'TR全量核对模板.csv')
    tr_done=[r for r in tr_rows if r.get('传播主张分类') in TR_CLASSES and r.get('结论')]
    tr_admitted=[r for r in tr_done if r.get('是否准入具体传播路径子图')=='是']
    tr_unverified=[r for r in tr_rows if r not in tr_done]
    tr_uncertainty=[r for r in tr_done if r.get('不确定性限定是否保留') in ('是','否')]
    tr_ev=[r for r in tr_done if r.get('源目标证据是否充分') in ('是','否')]
    out['传播核对']=dict(总TR数=len(tr_rows),完成结论数=len(tr_done),未完成结论数=len(tr_unverified),分类统计=dict(Counter(r['传播主张分类'] for r in tr_done)),已准入定向路径数=len(tr_admitted),限定词保留率=(sum(r['不确定性限定是否保留']=='是' for r in tr_uncertainty)/len(tr_uncertainty)) if tr_uncertainty else None,有充分源目标证据比例=(sum(r['源目标证据是否充分']=='是' for r in tr_ev)/len(tr_ev)) if tr_ev else None,备注='已有TR编号不等于真实传播链；若核对尚未覆盖所有编码，不得报告全量准确率')
    cq_rows=read_csv(output/'12项CQ参考答案模板.csv')
    cq_done=[r for r in cq_rows if r.get('是否正确') in ('是','否') and r.get('结论')]
    out['能力问题金答案']=dict(已经结论的答案单元数=len(cq_done),答案单元正确率=(sum(r['是否正确']=='是' for r in cq_done)/len(cq_done)) if cq_done else None,说明='仅已结论答案单元的结果；不能直接等价为12项CQ总体成功率')
    gold_by=defaultdict(list)
    for r in gold_judged:
        gold_by[(r.get('语种'),r.get('位置类型_正文表格图注'),r.get('原子事实类型'))].append(r)
    out['金标逐层已确认统计']=[dict(语种=k[0],来源位置=k[1],事实类型=k[2],已核定原子事实数=len(rs),TP=sum(r.get('是否在现有数据正确表达_TP或FN','').upper()=='TP' for r in rs),FN=sum(r.get('是否在现有数据正确表达_TP或FN','').upper()=='FN' for r in rs),来源侧召回率=(sum(r.get('是否在现有数据正确表达_TP或FN','').upper()=='TP' for r in rs)/len(rs)) if done else None) for k,rs in gold_by.items()]
    # Paper-level clustered bootstrap, only for a completed 30-paper independent reference set.
    if recall is not None:
        paper=defaultdict(lambda:Counter())
        for r in gold_judged:
            key=(r['语种'],case_code(r.get('源文件')) or cleaned_name(r.get('源文件')))
            paper[key][r['是否在现有数据正确表达_TP或FN'].strip().upper()]+=1
        rng=random.Random(20261028)
        distribution=[]
        strata={lang:[v for (l,_),v in paper.items() if l==lang] for lang in ('CN','EN')}
        for _ in range(2000):
            counts=Counter()
            for lang,rr in strata.items():
                if rr:
                    for x in rng.choices(rr,k=len(rr)): counts.update(x)
            if counts['TP']+counts['FN']:distribution.append(counts['TP']/(counts['TP']+counts['FN']))
        distribution.sort()
        out['源侧召回率_论文聚类bootstrap95%CI']=[distribution[int(0.025*(len(distribution)-1))],distribution[int(0.975*(len(distribution)-1))]] if distribution else None
    else:
        out['源侧召回率_论文聚类bootstrap95%CI']=None
    jdump(output/'评价指标_仅已核定.json',out)
    write_csv(output/'准确性逐层正式计算.csv',scores)
    return out
