"""Dengue research-case KG technical validation (four dimensions)."""
