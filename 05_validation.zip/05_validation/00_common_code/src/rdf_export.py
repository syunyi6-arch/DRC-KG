"""Conservative RDF evidence graph, controlled OWL vocabulary, and minimal SHACL checks.
Unreviewed relations, TR in particular, are represented as sourced assertions, not confirmed epidemiological transmissions.
"""
from __future__ import annotations
from pathlib import Path
from collections import defaultdict
from .common import *
from .analysis import ontology_index

SHAPES='''@prefix kg: <https://example.org/dengue-research-case/schema/> .
@prefix sh: <http://www.w3.org/ns/shacl#> .
@prefix xsd: <http://www.w3.org/2001/XMLSchema#> .

kg:RecordShape a sh:NodeShape ; sh:targetClass kg:AnnotatedRecord ;
 sh:property [ sh:path kg:sourceFile ; sh:minCount 1 ; sh:datatype xsd:string ] ;
 sh:property [ sh:path kg:sourceEvidence ; sh:minCount 1 ; sh:datatype xsd:string ] ;
 sh:property [ sh:path kg:rowNumber ; sh:minCount 1 ; sh:datatype xsd:integer ] .
kg:TRShape a sh:NodeShape ; sh:targetClass kg:TransmissionClaim ;
 sh:property [ sh:path kg:trCode ; sh:minCount 1 ; sh:datatype xsd:string ] ;
 sh:property [ sh:path kg:sourceFile ; sh:minCount 1 ; sh:maxCount 1 ] .
kg:AdmittedPathShape a sh:NodeShape ; sh:targetClass kg:AdmittedDirectionalPath ;
 sh:property [ sh:path kg:originText ; sh:minCount 1 ] ;
 sh:property [ sh:path kg:targetText ; sh:minCount 1 ] ;
 sh:property [ sh:path kg:supportEvidence ; sh:minCount 1 ] .
'''


def build_rdf(data,ontology,output,max_rows_per_sheet=0):
    try:
        from rdflib import Graph,Namespace,URIRef,Literal,RDF,RDFS,OWL,XSD
    except ImportError:
        (output/'RDF依赖缺失.txt').write_text('请安装：pip install rdflib pyshacl owlrl\n',encoding='utf-8')
        return {'状态':'依赖缺失','RDF三元组数':None}
    NS=Namespace('https://example.org/dengue-research-case/schema/')
    I=Namespace('https://example.org/dengue-research-case/id/')
    O=Namespace('https://example.org/dengue-research-case/ontology/')
    g=Graph();g.bind('kg',NS);g.bind('drc',I);g.bind('vocab',O)
    def v_uri(kind,label):return O[kind+'/'+short_hash(kind,norm(label))]
    def case_uri(lang,src):return I['case/'+short_hash(lang,case_code(src) or cleaned_name(src))]
    def mention_uri(lang,src,typ,val):return I['mention/'+short_hash(lang,case_code(src) or cleaned_name(src),norm(typ),norm(val))]
    def tr_uri(lang,code):return I['tr/'+short_hash(lang,code)]
    def lit(v):return Literal(str(v))
    def add(s,p,val):
        if val not in ('',None):g.add((s,p,lit(val)))
    idx=ontology_index(ontology)
    for typ in idx['classes']:
        u=v_uri('class',typ)
        g.add((u,RDF.type,OWL.Class));g.add((u,RDFS.label,lit(typ)))
        for parent in idx['parents'].get(typ,()):g.add((u,RDFS.subClassOf,v_uri('class',parent)))
    for typ in idx['attrs']:
        u=v_uri('attribute',typ)
        g.add((u,RDF.type,OWL.DatatypeProperty));g.add((u,RDFS.label,lit(typ)))
        for owner,_ in idx['attrs'][typ]:
            # ownership as annotation; DO NOT create strong rdfs:domain axioms from noisy mappings.
            add(u,NS.declaredOwner,owner)
    for typ,records in idx['rels'].items():
        u=v_uri('relation',typ)
        g.add((u,RDF.type,OWL.ObjectProperty));g.add((u,RDFS.label,lit(typ)))
        for row in records:
            add(u,NS.declaredDomain,row.get('主体类'))
            add(u,NS.declaredRange,row.get('客体类'))
            add(u,NS.mappingConstraint,row.get('原文表达与推理安全约束'))
    made=0;case_set=set();tr_set=set()
    for (lang,sheet),rows in data.items():
        if max_rows_per_sheet:rows=rows[:max_rows_per_sheet]
        for row in rows:
            rn=int(row['_row']);src=source(row);ev=evidence(row)
            rec=I['record/'+short_hash(lang,sheet,rn,src)]
            g.add((rec,RDF.type,NS.AnnotatedRecord))
            add(rec,NS.language,lang);add(rec,NS.sheetName,sheet)
            g.add((rec,NS.rowNumber,Literal(rn,datatype=XSD.integer)))
            add(rec,NS.sourceFile,src);add(rec,NS.sourceEvidence,ev)
            if src:
                c=case_uri(lang,src)
                if c not in case_set:
                    case_set.add(c)
                    g.add((c,RDF.type,NS.ResearchCase));add(c,NS.sourceFile,src);add(c,NS.language,lang)
                g.add((rec,NS.inResearchCase,c))
            typ=row.get('实体类型') or row.get('类类型','')
            val=row.get('实体值') or row.get('分离出来的实体','')
            if typ:add(rec,NS.annotatedClass,typ)
            if val and typ:
                m=mention_uri(lang,src,typ,val)
                g.add((m,RDF.type,NS.EntityMention))
                if norm(typ) in idx['classes']:g.add((m,RDF.type,v_uri('class',typ)))
                add(m,RDFS.label,val);g.add((rec,NS.mentionsEntity,m))
                g.add((m,NS.mentionedInCase,case_uri(lang,src)))
                add(m,NS.sourceFile,src)
            if sheet in (CLASS_SHEETS[1],CLASS_SHEETS[5]):
                add(rec,NS.annotatedAttribute,row.get('属性分类'))
                add(rec,NS.literalValue,row.get('分离出来的属性值'))
            if sheet in (CLASS_SHEETS[2],CLASS_SHEETS[6]):
                add(rec,NS.rawPredicate,row.get('关系'))
                add(rec,NS.mappedRelation,row.get('本体关系类型'))
                add(rec,NS.targetType,row.get('实体/属性类型'))
                add(rec,NS.targetText,row.get('实体/属性值'))
                # No invented direct subject->object relationship here; a claim is not its own verification.
                if row.get('本体关系类型') and norm(row['本体关系类型']) in idx['rels']:
                    g.add((rec,NS.usesRelation,v_uri('relation',row['本体关系类型'])))
            if sheet==CLASS_SHEETS[3]:
                add(rec,NS.ruleComponent,row.get('规则要素'))
                add(rec,NS.ruleText,row.get('规则内容'))
            if sheet in CLASS_SHEETS[4:]:
                code=tr_code(row)
                if code:
                    t=tr_uri(lang,code)
                    g.add((t,RDF.type,NS.TransmissionClaim))
                    add(t,NS.trCode,code)
                    add(t,NS.sourceFile,src)
                    g.add((rec,NS.refersToTR,t))
                    if ev:g.add((t,NS.supportEvidence,lit(ev)))
                    tr_set.add(t)
                add(rec,NS.trRole,row.get('实例角色') or row.get('记录角色'))
            made+=1
    admitted=0
    # Explicit adjudication is the only route for directional transmission graph admission.
    for r in read_csv(output/'TR全量核对模板.csv'):
        # The audit classification is recorded ONLY when there is an adjudicator decision.
        if r.get('结论') and r.get('传播主张分类') in TR_CLASSES:
            t=tr_uri(r['语种'],r['TR编码'])
            add(t,NS.reviewClass,r['传播主张分类'])
            add(t,NS.admissionDecision,r.get('是否准入具体传播路径子图'))
            add(t,NS.exclusionReason,r.get('排除原因'))
        if (r.get('传播主张分类')=='明确传播关联' and
            r.get('是否准入具体传播路径子图')=='是' and
            r.get('源目标证据是否充分')=='是' and
            r.get('结论') and
            r.get('具体来源文本') and r.get('具体目标文本') and r.get('原文证据摘录')):
            t=tr_uri(r['语种'],r['TR编码'])
            g.add((t,RDF.type,NS.AdmittedDirectionalPath))
            add(t,NS.originText,r['具体来源文本']);add(t,NS.targetText,r['具体目标文本'])
            add(t,NS.supportEvidence,r['原文证据摘录']);add(t,NS.certaintyQualifier,r.get('不确定性限定是否保留'))
            admitted+=1
    ttl=output/'登革热研究案例_证据可追溯图谱.ttl'
    g.serialize(destination=str(ttl),format='turtle',encoding='utf-8')
    shapes=output/'结构与传播准入_SHACL.ttl';shapes.write_text(SHAPES,encoding='utf-8')
    result=dict(状态=('RDF局部试运行；不可当作全库全库验证结果' if max_rows_per_sheet else 'RDF实例化完成；不是OWL2DL推理验证'),每分表最大处理行数=max_rows_per_sheet,已覆盖全量表行=not bool(max_rows_per_sheet),输入标注行数=made,RDF三元组数=len(g),研究案例URI数=len(case_set),TR相关URI数=len(tr_set),准入定向传播实例数=admitted,shacl_shapes文件=str(shapes.name),注意='上位类继承为RDFS；领域/值域只作说明，不据现有映射强制OWL断言；RDF中没有被确认的传播链仅是来源主张。')
    try:
        from pyshacl import validate
        conforms,report_graph,report_text=validate(g,shacl_graph=str(shapes),inference='rdfs',abort_on_first=False,allow_infos=True,allow_warnings=True)
        (output/'SHACL校验报告.txt').write_text(report_text,encoding='utf-8')
        result['SHACL通过']=bool(conforms)
        result['SHACL报告']='SHACL校验报告.txt'
        result['SHACL执行方式']='pyshacl with rdfs inference (not full OWL2DL reasoner)'
    except ImportError:
        result['SHACL通过']=None;result['SHACL报告']='未安装pyshacl，待运行'
    jdump(output/'RDF_SHACL统计.json',result)
    make_sparql(output)
    return result


def make_sparql(output):
    folder=output/'SPARQL查询示例';folder.mkdir(exist_ok=True)
    pre='PREFIX kg: <https://example.org/dengue-research-case/schema/>\nPREFIX drc: <https://example.org/dengue-research-case/id/>\n'
    queries={
      'CQ01_事件与时间.rq':'''SELECT DISTINCT ?case ?source ?event ?eventType ?time ?evidence WHERE {
 ?row a kg:AnnotatedRecord ; kg:inResearchCase ?case ; kg:annotatedClass ?eventType ;
      kg:sourceFile ?source ; kg:sourceEvidence ?evidence ; kg:mentionsEntity ?event .
 FILTER(?eventType IN ("疫情事件","疾病事件","暴露事件","调查监测事件","生物样本采集事件","实验室检测事件","防控处置事件"))
 OPTIONAL { ?link kg:mentionsEntity ?event ; kg:mappedRelation ?timePredicate ; kg:targetText ?time .
 FILTER(?timePredicate IN ("发生于时间","发病于时间","报告于时间","确诊于时间","采集于时间")) }
} LIMIT 200''',
      'CQ02_不同时间语义.rq':'''SELECT ?source ?event ?kind ?time ?evidence WHERE {
 ?row a kg:AnnotatedRecord ; kg:sourceFile ?source ; kg:sourceEvidence ?evidence ;
      kg:mappedRelation ?kind ; kg:targetText ?time .
 OPTIONAL { ?row kg:mentionsEntity ?event . }
 FILTER(?kind IN ("发病于时间","报告于时间","确诊于时间","采集于时间","采样于时间","发生于时间"))
} LIMIT 200''',
      'CQ03_疫情相关对象.rq':'''SELECT ?source ?subject ?subjectType ?predicate ?objectType ?object ?evidence WHERE {
 ?row kg:sourceFile ?source ; kg:annotatedClass ?subjectType ; kg:mappedRelation ?predicate ;
      kg:targetType ?objectType ; kg:targetText ?object ; kg:sourceEvidence ?evidence .
 OPTIONAL { ?row kg:mentionsEntity ?subject }
 FILTER(?subjectType IN ("疫情事件","人","登革病毒","病原体","媒介","行政区域") ||
        ?objectType IN ("疫情事件","人","登革病毒","病原体","媒介","空间","行政区域"))
} LIMIT 200''',
      'CQ04_病例旅行暴露.rq':'''SELECT ?source ?claim ?object ?evidence WHERE {
 ?row kg:sourceFile ?source ; kg:sourceEvidence ?evidence ; kg:rawPredicate ?claim .
 OPTIONAL { ?row kg:targetText ?object }
 FILTER(regex(?claim,"旅行|暴露|旅居|接触|travel|expos|visit","i") ||
        regex(?evidence,"旅行史|旅居史|travel history|exposure history","i"))
} LIMIT 200''',
      'CQ05_不确定性感染来源候选.rq':'''SELECT DISTINCT ?code ?source ?evidence WHERE {
 ?tr a kg:TransmissionClaim ; kg:trCode ?code ; kg:sourceFile ?source .
 ?row kg:refersToTR ?tr ; kg:sourceEvidence ?evidence .
 FILTER(regex(?evidence,"可能|疑似|推测|推断|may|might|suspect|probabl|presum|infer","i"))
} LIMIT 200''',
      'CQ06_仅准入的定向传播.rq':'''SELECT DISTINCT ?code ?origin ?target ?evidence WHERE {
 ?tr a kg:AdmittedDirectionalPath ; kg:trCode ?code ;
      kg:originText ?origin ; kg:targetText ?target ; kg:supportEvidence ?evidence .
} LIMIT 200''',
      'CQ07_已核排除的线索.rq':'''SELECT DISTINCT ?code ?source ?reason WHERE {
 ?tr a kg:TransmissionClaim ; kg:trCode ?code ; kg:sourceFile ?source ;
     kg:reviewClass "证据性线索" ; kg:admissionDecision "否" .
 OPTIONAL { ?tr kg:exclusionReason ?reason }
} LIMIT 200''',
      'CQ08_传播主张证据.rq':'''SELECT DISTINCT ?tr ?code ?source ?evidence ?mappedRel ?target WHERE {
 ?tr a kg:TransmissionClaim ; kg:trCode ?code ; kg:sourceFile ?source .
 ?row kg:refersToTR ?tr ; kg:sourceEvidence ?evidence .
 OPTIONAL { ?row kg:mappedRelation ?mappedRel ; kg:targetText ?target }
} LIMIT 200''',
      'CQ09_防控事件及时间.rq':'''SELECT DISTINCT ?source ?event ?time ?evidence WHERE {
 ?row kg:annotatedClass "防控处置事件" ; kg:sourceFile ?source ;
      kg:mentionsEntity ?event ; kg:sourceEvidence ?evidence .
 OPTIONAL { ?t kg:mentionsEntity ?event ; kg:mappedRelation ?timePred ; kg:targetText ?time .
 FILTER(?timePred IN ("发生于时间","防控实施时间")) }
} LIMIT 200''',
      'CQ10_表格统计候选.rq':'''SELECT ?source ?subject ?attribute ?value ?evidence WHERE {
 ?row a kg:AnnotatedRecord ; kg:sourceFile ?source ; kg:sourceEvidence ?evidence ;
      kg:annotatedAttribute ?attribute ; kg:literalValue ?value .
 OPTIONAL { ?row kg:mentionsEntity ?subject }
 FILTER(regex(?evidence,"Table|表[0-9]|denominator|分组","i") ||
        regex(?attribute,"病例数|人群规模|统计指标值|发病率|死亡率"))
} LIMIT 200''',
      'CQ11_病例定义或阈值规则.rq':'''SELECT ?source ?component ?text ?evidence WHERE {
 ?row kg:sourceFile ?source ; kg:ruleComponent ?component ;
      kg:ruleText ?text ; kg:sourceEvidence ?evidence .
 FILTER(regex(?evidence,"病例定义|阈值|case definition|threshold|index|BI","i") ||
        regex(?component,"条件|Condition|主体|Subject","i"))
} LIMIT 200''',
      'CQ12_跨语言同本体类_不合并实例.rq':'''SELECT ?type ?cnPapers ?enPapers WHERE {
 { SELECT ?type (COUNT(DISTINCT ?cnCase) AS ?cnPapers) WHERE {
    ?r1 kg:annotatedClass ?type ; kg:language "CN" ; kg:inResearchCase ?cnCase .
   } GROUP BY ?type }
 { SELECT ?type (COUNT(DISTINCT ?enCase) AS ?enPapers) WHERE {
    ?r2 kg:annotatedClass ?type ; kg:language "EN" ; kg:inResearchCase ?enCase .
   } GROUP BY ?type }
} LIMIT 200'''
    }
    for name,query in queries.items(): (folder/name).write_text(pre+query+'\n',encoding='utf-8')
