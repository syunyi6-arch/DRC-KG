"""Twelve CQs: retrieval candidates, explicit readiness labels, no fabricated gold accuracy."""
from __future__ import annotations
from pathlib import Path
from collections import defaultdict,Counter
import re
from .common import *

EVENTS=['疫情事件','疾病事件','暴露事件','调查监测事件','生物样本采集事件','实验室检测事件','防控处置事件']
TIME_RELS=['发生于时间','发病于时间','报告于时间','确诊于时间','采集于时间','采样于时间','数据对应时间','防控实施时间','传播时间']
TIME_RELS_STRICT=['发生于时间','发病于时间','报告于时间','确诊于时间','采集于时间','采样于时间','传播时间','防控实施时间']
TR_RELEVANT_ATTRS={'传播关联性质','支持证据','传播来源','传播目标','传播病原体','传播媒介','传播机制','断言确定性','断言极性','原文限定语','关联暴露','环境条件'}
TRAVEL=re.compile(r'旅行|旅居|暴露|接触史|travel|exposure|visited|imported|migration',re.I)
NEG_EXPOSURE=re.compile(r'(无|未|否认|没有|排除|without|no\s+|denied|negative\s+for).{0,12}(旅行|旅居|暴露|接触|外出|travel|exposure|visit|contact)',re.I)
TOTAL_RE=re.compile(r'(?:发病|报告|确诊|累计|共|收治|发现|调查)[^\d]{0,8}(\d{1,5})\s*(?:例|人)')

def has_positive_exposure(text):
    for m in TRAVEL.finditer(text):
        w=text[max(0,m.start()-20):m.end()+20]
        if not NEG_EXPOSURE.search(w):
            return True
    return False
UNCERTAIN=re.compile(r'可能|疑似|推测|可能性|推断|也许|争议|may|might|suspect|probabl|potential|presum|infer|hypothes',re.I)
TABLE=re.compile(r'表\s*\d|table\s*[1-9]|\btab\.?\s*[1-9]|分组|denominator|\b95%|n\s*=|分母',re.I)
STAT=re.compile(r'病例数|人群规模|统计指标|发病率|死亡率|百分比|样本量|罹患率|case count|rate',re.I)


def run_cqs(data,output,max_per=10000):
    record=lambda lang,sheet:data[(lang,CLASS_SHEETS[sheet])]
    result={k:[] for k in range(1,13)}
    tr_review=read_csv(output/'TR全量核对模板.csv')
    tr_status={(r.get('语种'),r.get('TR编码')):r for r in tr_review}
    for lang in ('CN','EN'):
        classes=record(lang,0);attributes=record(lang,1);relations=record(lang,2);rules=record(lang,3)
        trcls=record(lang,4);trattr=record(lang,5);trrel=record(lang,6)
        # No cross-paper instance merging; every output preserves original source field.
        time_by_name=defaultdict(list)
        for r in relations:
            if r.get('本体关系类型') in TIME_RELS_STRICT:
                time_by_name[(cleaned_name(source(r)),same(r.get('实体值')))].append(r)
                result[2].append(dict(语种=lang,源文件=source(r),时间语义类型=r.get('本体关系类型'),事件实体=r.get('实体值'),时间值=r.get('实体/属性值'),原文依据=evidence(r),原Excel行=r['_row']))
        for r in classes:
            typ=r.get('实体类型','');src=source(r)
            if typ in EVENTS:
                base=dict(语种=lang,源文件=src,事件类型=typ,事件值=r.get('实体值'),原文依据=evidence(r),原Excel行=r['_row'])
                tm=time_by_name.get((cleaned_name(src),same(r.get('实体值'))),[])
                if tm:
                    for t in tm:result[1].append(dict(**base,时间类型=t.get('本体关系类型'),时间值=t.get('实体/属性值'),时间关联原Excel行=t['_row']))
                else:result[1].append(dict(**base,时间类型='',时间值='',时间关联原Excel行='',提示='无明确相同事件值的时间链接；不能推断不存在时间信息'))
        for r in relations:
            s=source(r);left=r.get('实体类型','');right=r.get('实体/属性类型','');ot=r.get('实体/属性值','');lt=r.get('实体值','');rel=r.get('本体关系类型','');e=evidence(r)
            if any(t in (left,right) for t in ('人','病原体','登革病毒','蚊媒','媒介','空间','行政区域','疫情事件')):
                result[3].append(dict(语种=lang,源文件=s,主体类别=left,主体=lt,本体关系=rel,客体类别=right,客体=ot,原文依据=e,原Excel行=r['_row']))
            if TRAVEL.search(' '.join([rel,r.get('关系',''),e[:200]])):
                if not has_positive_exposure(e):
                    continue
                obj=r.get('实体/属性值','')
                if obj:
                    pos=e.find(obj)
                    if pos>=0 and NEG_EXPOSURE.search(e[max(0,pos-20):pos+len(obj)+20]):
                        continue
                result[4].append(dict(语种=lang,源文件=s,主体=lt,本体关系=rel,客体=ot,原文依据=e,原Excel行=r['_row'],提示='仅曝光/旅居候选，不能自动判为传播事实'))
            if ('防控处置事件' in (left,right) or re.search(r'防控|消杀|灭蚊|control|intervention|spray',rel,re.I)):
                if left=='研究问题' or lt=='目的' or rel=='定义描述':
                    continue
                tm=time_by_name.get((cleaned_name(s),same(lt)),[]) or time_by_name.get((cleaned_name(s),same(ot)),[])
                if tm:
                    for t in tm:
                        result[9].append(dict(语种=lang,源文件=s,防控相关实体=lt,本体关系=rel,相关值=ot,时间类型=t.get('本体关系类型'),时间值=t.get('实体/属性值'),时间关联原Excel行=t['_row'],原文依据=e,原Excel行=r['_row'],提示='同一事件值的时间关系'))
                else:
                    result[9].append(dict(语种=lang,源文件=s,防控相关实体=lt,本体关系=rel,相关值=ot,时间类型='',时间值='',时间关联原Excel行='',原文依据=e,原Excel行=r['_row'],提示='无明确同一事件时间关系；不能推断不存在时间信息'))
        total_cases=defaultdict(int)
        for rows0 in (classes,attributes,relations,rules):
            for r0 in rows0:
                for m in TOTAL_RE.finditer(evidence(r0)):
                    n=int(m.group(1))
                    if 1<=n<=100000:
                        total_cases[cleaned_name(source(r0))]=max(total_cases[cleaned_name(source(r0))],n)
        for r in attributes:
            if (TABLE.search(evidence(r)) or STAT.search(r.get('属性分类',''))):
                tot=total_cases.get(cleaned_name(source(r)),0)
                num=re.search(r'(\d+(?:\.\d+)?)',r.get('分离出来的属性值',''))
                ratio=f'{float(num.group(1))/tot:.1%}' if num and tot else ''
                result[10].append(dict(语种=lang,源文件=source(r),实体=r.get('分离出来的实体'),属性=r.get('属性分类'),值=r.get('分离出来的属性值'),分母候选=tot or '',占比候选=ratio,分母来源=('原文总病例数候选' if tot else ''),原文=evidence(r),原Excel行=r['_row'],单位与分母是否完整='须原表独立解析确认'))
        groups=defaultdict(list)
        for r in rules:
            groups[(cleaned_name(source(r)),same(evidence(r)))].append(r)
        for gr in groups.values():
            result[11].append(dict(语种=lang,源文件=source(gr[0]),标题块=gr[0].get('标题块',''),原文=evidence(gr[0]),规则要素='; '.join(x.get('规则要素','')+':'+x.get('规则内容','') for x in gr),完整规则分行数=len(gr)))
        tr_context=defaultdict(dict)
        for r in trattr:
            code=tr_code(r); cat=r.get('属性分类',''); val=r.get('分离出来的属性值','')
            if code and cat in ('传播来源','传播目标','传播病原体','传播媒介') and val and cat not in tr_context[(lang,code)]:
                tr_context[(lang,code)][cat]=val
        for r in trattr:
            code=tr_code(r)
            base=dict(语种=lang,源文件=source(r),TR编码=code,属性类别=r.get('属性分类'),属性值=r.get('分离出来的属性值'),原文=evidence(r),原Excel行=r['_row'])
            if r.get('属性分类','') in TR_RELEVANT_ATTRS:
                result[8].append(base)
            if UNCERTAIN.search(evidence(r)+' '+r.get('分离出来的属性值','')):
                ctx=tr_context.get((lang,code),{})
                result[5].append(dict(**base,传播来源=ctx.get('传播来源',''),传播目标=ctx.get('传播目标',''),传播病原体=ctx.get('传播病原体',''),传播媒介=ctx.get('传播媒介',''),提示='可能性限定候选；不能以关键词代替研究主张识别'))
        for r in trcls:
            if UNCERTAIN.search(evidence(r)):
                result[5].append(dict(语种=lang,源文件=source(r),TR编码=tr_code(r),属性类别='类表原文限定',属性值='',原文=evidence(r),原Excel行=r['_row'],提示='包含模态词；需确认限定作用对象'))
        # The two following CQs are strictly gated on adjudicated classifications.
        for r in tr_review:
            if r.get('语种')!=lang:continue
            approved=r.get('是否准入具体传播路径子图','').strip()
            classed=r.get('传播主张分类','').strip()
            if (classed=='明确传播关联' and approved=='是' and r.get('具体来源文本') and r.get('具体目标文本') and r.get('源目标证据是否充分')=='是'):
                result[6].append(dict(语种=lang,源文件=r.get('来源论文'),TR编码=r.get('TR编码'),具体来源=r.get('具体来源文本'),具体目标=r.get('具体目标文本'),原文依据=r.get('原文证据摘录'),证据等级=r.get('证据类型'),备注='仅根据已核准入，不由程序自动认定'))
            if classed=='证据性线索' and approved=='否':
                result[7].append(dict(语种=lang,源文件=r.get('来源论文'),TR编码=r.get('TR编码'),证据=r.get('原文证据摘录'),排除原因=r.get('排除原因'),备注='确认已排除'))
    # CQ12: unified ontology label comparisons, NEVER merge source-scoped instance identity.
    label_sources=defaultdict(lambda:defaultdict(set))
    for lang in ('CN','EN'):
        for row in record(lang,0):
            if row.get('实体类型'):
                label_sources[row['实体类型']][lang].add(cleaned_name(source(row)))
    for label,langs in sorted(label_sources.items()):
        if langs.get('CN') and langs.get('EN'):
            result[12].append(dict(本体类=label,中文论文数=len(langs['CN']),英文论文数=len(langs['EN']),语义='共享本体类名，论文实例标识不同，不断言sameAs'))
    details={
      1:('事件与时间','普通类表与时间本体关系',True,'证据返回为候选；事件—时间的准确归属需逐条确认'),
      2:('区分发病/报告/确诊/采样/发表','关系映射中的专用时间谓词',True,'未映射的发布时间不可推断为疫情事件时间'),
      3:('疫情主体/病原/媒介/地点','普通关系表','partial','召回候选；需特定疫情事件绑定'),
      4:('病例旅行史及暴露','关系检索候选','partial','关键词筛选候选并不等于语义正确'),
      5:('可能/推测/疑似感染来源','TR类属性中的限定词','partial','必须区分作用对象及否定'),
      6:('具体来源目标证据','核准TR','review','核对模板未核准则不得宣称可回答'),
      7:('被排除的线索','核准TR排除记录','review','无显式排除记录不得虚构结果'),
      8:('传播判断原文和证据','TR属性及来源','partial','返回原文不等于证据足够支持传染路径'),
      9:('防控措施及时间','普通关系＋时间关联','partial','需确认防控对象和时间是同一事件'),
      10:('表格分组数值单位分母','统计属性及原文','partial','七分表未必存储单元格地址/分母，需表格独立金标'),
      11:('病例定义与阈值规则','完整规则单元','partial','规则需要确证条件/结论及适用范围'),
      12:('中英文共享本体概念','同类跨语种统计',True,'不合并相同标签的不同论文实体'),
    }
    scores=[]
    for n,(title,path,readiness,notes) in details.items():
        rows=result[n]
        if n in (6,7):
            reviewed=any(r.get('传播主张分类') in TR_CLASSES and r.get('结论') for r in tr_review)
            status='核对尚未完成' if not reviewed else '已运行筛选条件；仍需参考答案'
        elif readiness=='partial':status='候选检索已实现；数据/语义完整性需确认'
        else:status='结构化查询已实现；结果正确性需独立参考答案比对'
        write_csv(output/f'CQ{n:02d}_查询结果候选.csv',rows)
        scores.append(dict(编号=f'CQ{n}',能力问题=title,数据路径=path,结构实现层='已定义',数据层执行状态=status,返回候选行数=len(rows),预期答案完成='',回答正确性='',证据追溯率='',备注=notes))
    write_csv(output/'12项CQ执行登记表.csv',scores)
    if not (output/'12项CQ参考答案模板.csv').exists():
        write_csv(output/'12项CQ参考答案模板.csv',[],['CQ编号','语种','测试案例','问题参数','参考答案ID','预期答案_可以为空集','证据PDF页码','确认结果','查询实际命中项ID','是否正确','遗漏或错误原因','确认者','结论'])
    return scores
