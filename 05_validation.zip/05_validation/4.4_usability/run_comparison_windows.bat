@echo off
setlocal
cd /d "%~dp0"
python -m pip install -r requirements.txt
python code\run_representation_comparison.py
pause
