#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Reproduce 40 competency-question assessments and 42 source-level SPARQL queries.

The evaluator reads the final reviewed decisions from the supplied
English CSV decision table. SPARQL results indicate retrieval of expected structured fields;
they are not used as a substitute for source-based answer adjudication.
"""
import argparse
import csv
import hashlib
import json
import posixpath
import re
from pathlib import Path
from xml.etree import ElementTree as ET
from zipfile import ZipFile

from rdflib import Graph, Namespace, RDF

ROOT = Path(__file__).resolve().parent.parent
KG = Namespace('https://example.org/dengue-research-case/schema/')
S_NS = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'
R_NS = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
P_NS = 'http://schemas.openxmlformats.org/package/2006/relationships'
S = '{' + S_NS + '}'


def read_review_table(path):
    """Load frozen evidence-aware review decisions from a UTF-8 CSV."""
    with open(path,encoding='utf-8-sig',newline='') as file:
        rows=list(csv.DictReader(file))
    return [{'Test ID':r['Test ID'],'Competency Question':r['CQ Category'],
             'Final Decision':r['Final Decision'],'Review Status':r['Review Status']} for r in rows]


def file_sha256(path):
    digest = hashlib.sha256()
    with open(path, 'rb') as file:
        while True:
            chunk = file.read(4 * 1024 * 1024)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def save_csv(path, records):
    if not records:
        raise ValueError(f'Cannot create an empty CSV file: {path}')
    with path.open('w', encoding='utf-8-sig', newline='') as file:
        writer = csv.DictWriter(file, fieldnames=list(records[0]))
        writer.writeheader()
        writer.writerows(records)


def main():
    parser = argparse.ArgumentParser(description='Reproduce 40 CQ tests and 42 source-level SPARQL queries.')
    parser.add_argument('--output', default='reproduced', help='Output directory under the package root (default: reproduced).')
    parser.add_argument('--verify-full-rdf', action='store_true', help='Verify the SHA-256 checksum of the frozen full RDF file.')
    arguments = parser.parse_args()
    output_dir = (ROOT / arguments.output).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    workbook_path = ROOT / 'data' / '40_evidence_aware_reviewed_decisions.csv'
    reviews = read_review_table(workbook_path)
    reviews_by_id = {record['Test ID']: record for record in reviews}
    if len(reviews) != 40 or len(reviews_by_id) != 40:
        raise ValueError('Exactly 40 unique reviewed test records are required.')
    for record in reviews:
        if record['Final Decision'] not in ('Passed', 'Failed'):
            raise ValueError('Unsupported final decision: ' + repr(record))

    reference = json.loads((ROOT / 'data' / '40_cq_reference_answers.json').read_text(encoding='utf-8'))
    manifest = json.loads((ROOT / 'data' / '40_cq_run_manifest.json').read_text(encoding='utf-8'))
    if len(reference) != 40 or {t['test_id'] for t in reference} != set(reviews_by_id):
        raise ValueError('The reference-answer set does not match the reviewed test IDs.')

    if arguments.verify_full_rdf:
        rdf_path = ROOT / 'data' / 'DRCKG_frozen_40CQs.ttl'
        actual_sha = file_sha256(rdf_path)
        if actual_sha != manifest['dataset_sha256']:
            raise RuntimeError('Full RDF checksum mismatch.')
        print('Full RDF SHA-256 verified:', actual_sha)

    graph = Graph()
    graph.parse(str(ROOT / 'data' / 'source_grounded_fields_40CQs.ttl'), format='turtle')
    case_graphs = {}
    for subject in graph.subjects(RDF.type, KG.SourceStructuredAssertion):
        source_file = graph.value(subject, KG.sourceFile)
        if source_file is None:
            continue
        case_graph = case_graphs.setdefault(str(source_file), Graph())
        for predicate, obj in graph.predicate_objects(subject):
            case_graph.add((subject, predicate, obj))
            if predicate == KG.hasField:
                for p2, o2 in graph.predicate_objects(obj):
                    case_graph.add((obj, p2, o2))

    query_results, test_results = [], []
    for test in reference:
        test_id, matches_all_sources = test['test_id'], True
        for source in test['sources']:
            query_name = test_id + '_' + source['language'] + str(source['page'])
            query_path = ROOT / 'queries' / (query_name + '.rq')
            source_name = source['sourceFile']
            if source_name not in case_graphs:
                raise ValueError('No structured facts found for source: ' + source_name)
            query_text = query_path.read_text(encoding='utf-8')
            returned_rows = list(case_graphs[source_name].query(query_text))
            count = len(returned_rows)
            matches_all_sources &= count > 0
            query_results.append({
                'Test ID': test_id,
                'Query File': query_name + '.rq',
                'Returned Rows': count,
                'Expected Fields Found': 'Yes' if count else 'No',
            })
        review = reviews_by_id[test_id]
        test_results.append({
            'Test ID': test_id,
            'Competency Question': review['Competency Question'],
            'Source Queries': len(test['sources']),
            'Expected Fields Found': 'Yes' if matches_all_sources else 'No',
            'Final Decision': review['Final Decision'],
            'Review Status': review['Review Status'],
        })

    if len(query_results) != 42 or len(test_results) != 40:
        raise ValueError('Expected 42 source queries and 40 test results.')

    passed = sum(row['Final Decision'] == 'Passed' for row in test_results)
    summary = {
        'competency_question_categories': len({row['Competency Question'] for row in test_results}),
        'test_instances': len(test_results),
        'source_level_queries': len(query_results),
        'source_queries_with_expected_fields': sum(row['Expected Fields Found'] == 'Yes' for row in query_results),
        'tests_with_expected_fields': sum(row['Expected Fields Found'] == 'Yes' for row in test_results),
        'reviewed_answers_passed': passed,
        'reviewed_answers_failed': len(test_results) - passed,
        'reviewed_answer_pass_rate': round(passed / len(test_results), 6),
        'failed_test_ids': [row['Test ID'] for row in test_results if row['Final Decision'] == 'Failed'],
        'evaluation_basis': 'Final decisions are read from the supplied reviewed workbook; retrieval of expected SPARQL fields is evaluated separately.',
    }
    save_csv(output_dir / '40_cq_reproduced_results.csv', test_results)
    save_csv(output_dir / '42_source_query_results.csv', query_results)
    (output_dir / 'evaluation_summary.json').write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding='utf-8')
    print('Source-level queries with results:', summary['source_queries_with_expected_fields'], '/', summary['source_level_queries'])
    print('Tests with expected fields:', summary['tests_with_expected_fields'], '/', summary['test_instances'])
    print('Reviewed answers passed:', passed)
    print('Reviewed answers failed:', len(test_results) - passed)
    print('Reviewed answer pass rate: {:.1f}%'.format(100 * passed / len(test_results)))
    print('Failed test IDs:', ', '.join(summary['failed_test_ids']))
    print('Output directory:', output_dir)


if __name__ == '__main__':
    main()
