"""Re-check the 12 predefined CQ test instances against the 11/3 annotation data."""
import csv
import io
import os
from collections import Counter

OUT = '1104_第四章技术验证_重跑/outputs'


def load(name):
    p = os.path.join(OUT, name)
    if not os.path.exists(p):
        return []
    return list(csv.DictReader(open(p, encoding='utf-8-sig')))


def find(rows, *needles):
    out = []
    for r in rows:
        blob = ' '.join(str(v) for v in r.values() if v)
        if all(n in blob for n in needles):
            out.append(r)
    return out


print('#' * 70)
print('CQ1  paper 001, 防控处置事件 = 彻底铲除伊蚊孳生地')
for r in find(load('CQ01_查询结果候选.csv'), '001_一起由输入病例')[:6]:
    print('  ', {k: r[k] for k in ('事件类型', '事件值', '时间类型', '时间值', '提示') if k in r})

print('#' * 70)
print('CQ2  paper 001, 最后1例 / 10月2日 time semantics')
for r in find(load('CQ02_查询结果候选.csv'), '001_一起由输入病例'):
    print('  ', {k: r[k] for k in ('时间语义类型', '事件实体', '时间值') if k in r})

print('#' * 70)
print('CQ3  paper 001, 登革热Ⅰ型病毒 -引起-> 本起疫情')
for r in find(load('CQ03_查询结果候选.csv'), '001_一起由输入病例'):
    if 'Ⅰ型' in str(r) or 'I型' in str(r):
        print('  ', {k: r[k] for k in ('主体类别', '主体', '本体关系', '客体类别', '客体') if k in r})

print('#' * 70)
print('CQ4  paper 001, 除首发病例外其他病例 有暴露史')
for r in find(load('CQ04_查询结果候选.csv'), '001_一起由输入病例')[:8]:
    print('  ', {k: r[k] for k in ('主体', '本体关系', '客体') if k in r}, '|', r.get('原文依据', '')[:70])

print('#' * 70)
print('CQ5  paper 085, TR-CN-085-001')
for r in find(load('CQ05_查询结果候选.csv'), 'TR-CN-085-001')[:8]:
    print('  ', {k: r[k] for k in ('TR编码', '属性类别', '属性值', '传播来源', '传播目标') if k in r})

print('#' * 70)
print('CQ8  paper 001, TR-CN-001-001')
for r in find(load('CQ08_查询结果候选.csv'), 'TR-CN-001-001')[:8]:
    print('  ', {k: r[k] for k in ('TR编码', '属性类别', '属性值') if k in r})

print('#' * 70)
print('CQ9  paper 001, 防控措施 + 时间')
for r in find(load('CQ09_查询结果候选.csv'), '001_一起由输入病例')[:10]:
    print('  ', {k: r[k] for k in ('防控相关实体', '本体关系', '相关值', '时间类型', '时间值') if k in r})

print('#' * 70)
print('CQ10 paper 001, 职业分组 农民=3例')
for r in find(load('CQ10_查询结果候选.csv'), '001_一起由输入病例'):
    if '农民' in str(r):
        print('  ', {k: r[k] for k in ('实体', '属性', '值', '分母候选', '占比候选') if k in r})

print('#' * 70)
print('CQ11 paper 016, BI 规则')
for r in find(load('CQ11_查询结果候选.csv'), '016_一起在持续高蚊媒密度'):
    print('  ', r.get('完整规则分行数'), '|', r.get('原文', '')[:100])
    print('     要素:', r.get('规则要素', '')[:220])

print('#' * 70)
print('CQ12 临床表现 counts')
for r in find(load('CQ12_查询结果候选.csv'), '临床表现'):
    print('  ', r)
