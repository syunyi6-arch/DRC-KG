"""Dump, for each CQ test instance, exactly what the 11/3 annotation returns."""
import csv
import os

OUT = '1104_第四章技术验证_重跑/outputs'
COL = {
    1: ('事件类型', '事件值', '时间类型', '时间值', '提示', '原Excel行'),
    2: ('时间语义类型', '事件实体', '时间值', '原Excel行'),
    3: ('主体类别', '主体', '本体关系', '客体类别', '客体', '原Excel行'),
    4: ('主体', '本体关系', '客体', '原Excel行'),
    5: ('TR编码', '属性类别', '属性值', '传播来源', '传播目标', '原Excel行'),
    6: ('TR编码', '具体来源', '具体目标'),
    7: ('TR编码', '证据', '排除原因'),
    8: ('TR编码', '属性类别', '属性值', '原Excel行'),
    9: ('防控相关实体', '本体关系', '相关值', '时间类型', '时间值', '原Excel行'),
    10: ('实体', '属性', '值', '分母候选', '占比候选', '原Excel行'),
    11: ('原文', '规则要素', '完整规则分行数', '原Excel行'),
    12: ('本体类', '中文论文数', '英文论文数'),
}


def rows(n):
    p = os.path.join(OUT, f'CQ{n:02d}_查询结果候选.csv')
    return list(csv.DictReader(open(p, encoding='utf-8-sig')))


def show(n, label, needles, limit=8):
    rs = [r for r in rows(n)
          if all(any(nd in str(v) for v in r.values()) for nd in needles)]
    print(f'--- CQ{n} :: {label} :: matched {len(rs)}')
    for r in rs[:limit]:
        print('    ' + ' | '.join(f'{c}={r.get(c, "")}' for c in COL[n] if c in r))


show(1, '001 防控事件', ['001_一起由输入病例'])
show(2, '001 时间语义', ['001_一起由输入病例'])
show(3, '001 病原/疫情对象', ['001_一起由输入病例'], 12)
show(4, '001 暴露', ['001_一起由输入病例'], 10)
show(5, '085 TR', ['TR-CN-085-001'], 6)
show(9, '001 防控+时间', ['001_一起由输入病例'], 12)
show(10, '001 农民', ['001_一起由输入病例', '农民'], 4)
show(11, '016 BI 规则', ['016_一起在持续高蚊媒密度'], 3)
show(12, '临床表现计数', ['临床表现'], 3)
print('\nCQ6 rows', len(rows(6)), 'CQ7 rows', len(rows(7)))
