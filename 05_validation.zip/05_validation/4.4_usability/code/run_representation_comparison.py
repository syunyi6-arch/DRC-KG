#!/usr/bin/env python3
"""Construct a source-matched SPO projection and compare answer-field recoverability.

Same 40 reference cases and same source-grounded assertions for each representation.
Queries retrieve all fields/triples in the fixed source scope, and do not filter on
expected answer values. Field-level scoring uses the published gold field values.
Reviewed answer decisions for both representations are read from the reviewer-confirmed decision tables.
"""
import csv, hashlib, json, os, re, sys, unicodedata
from collections import Counter, defaultdict
from pathlib import Path
from rdflib import Dataset, Graph, Literal, Namespace, RDF, URIRef
from rdflib.namespace import RDFS

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
sys.path.insert(0,str(ROOT/'code'))
KG=Namespace('https://example.org/dengue-research-case/schema/')
BASE='https://example.org/dengue-research-case/baseline/'

def sha(s):return hashlib.sha256(s.encode('utf-8')).hexdigest()[:24]
def save_csv(path,rows,headers=None):
    path.parent.mkdir(parents=True,exist_ok=True)
    if headers is None:headers=list(rows[0]) if rows else []
    with path.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=headers,extrasaction='ignore');w.writeheader();w.writerows(rows)
def norm(s):
    s=unicodedata.normalize('NFKC',str(s)).casefold()
    return re.sub(r'[\s\u200b\u3000\-—–_,;；、。()（）:：，/]+','',s)

def score_literal(key,val,subject,rel,obj):
    """Conservative, field-generic interpretation of an ordinary SPO triple.

    No per-CQ ID-based outcomes, no access to expert review decisions. Lexical
    inference is accepted only when the triple explicitly encodes the value.
    """
    v=str(val).strip(); ns=norm(subject); nr=norm(rel); no=norm(obj); combined=norm(subject+' '+rel+' '+obj); nv=norm(v)
    if not nv:return True,'Empty expected value'
    if nv in combined:return True,'Literal is explicit in the SPO triple'
    # Numeric values can be read only when they appear as bounded quantities.
    if re.fullmatch(r'\d+(?:\.\d+)?',v):
        if re.search(r'(?<![0-9.])'+re.escape(v)+r'(?![0-9.])',unicodedata.normalize('NFKC',subject+' '+rel+' '+obj)):
            return True,'Numeric value explicitly appears in triple text'
    neg=any(t in combined for t in ['无外出史','无缅甸出国史','notravel','否认外出','未识别','不准入','非确证','未确认','无确证'])
    if key in ('polarity','travel_status') and nv in ('否定','否认','无') and neg:
        return True,'Explicit negative travel/exposure wording'
    if key=='action_status':
        if nv=='已实施' and any(t in combined for t in ['实际实施','实施于时间','包含已实施','集中地毯式喷杀','spatial spraying','spacespraying']):
            return True,'An implementation verb is explicit in predicate/object'
        if nv=='建议' and any(t in combined for t in ['建议','被提出为预防']):
            return True,'Advisory status explicit in predicate'
    if key=='certainty' and nv=='明确陈述' and any(t in nr for t in ['实际实施','已实施']):
        return True,'Assertive implementation explicitly stated'
    if key in ('claim_status','certainty') and ('推断' in nv or '可能' in nv):
        if '推断' in nr and '可能性大' not in nv and '可能性较小' not in nv:
            return True,'Predicate explicitly marks inference'
        if nv=='可能性较小' and '可能性较小' in combined:return True,'Low likelihood explicitly stated'
    if key=='rule_type':
        if nv=='指标定义' and '定义为' in nr:return True,'Definitional predicate'
        if nv=='病例定义标准引用' and '采用定义' in nr:return True,'Explicit definition reference'
    if key=='path_admission':
        if nv in ('非确证','未证实定向传播','无确证实例','不准入') and any(t in combined for t in ['非确证','未确证','无确证','不准入','间接线索不足确证','未识别','无确证候选']):
            return True,'Explicit uncertainty/non-admission predicate or object'
    if key=='not_case_count' and nv=='是' and ('在校学生' in ns and '总体规模' in nr):
        return True,'Student population distinguished from dengue case count by predicate'
    if key=='entity_same_as' and nv=='否' and any(t in combined for t in ['不合并','不同研究案例']):
        return True,'Non-identity explicit in SPO object'
    if key=='measure_unit' and nv in ('人','例','份','persons'):
        return any(t in no for t in [norm(v),'人','例','persons']) , 'Unit text in SPO object' if any(t in no for t in [norm(v),'人','例','persons']) else 'Unit is not explicit'
    if key=='threshold_mid' and nv=='10左右' and ('约10' in combined or '10左右' in combined):
        return True,'Approximate threshold stated'
    if key=='direct_personal_route' and nv=='未证实':
        # A serotype or genomic similarity triple does NOT by itself attest a negative path conclusion.
        return False,'No source-to-target path status is represented in an ordinary SPO triple'
    return False,'Required semantic qualifier is absent from the ordinary SPO triple'

def assertion_fields(g,uri):
    result={}
    for f in g.objects(uri,KG.hasField):
        key=g.value(f,KG.fieldKey);value=g.value(f,KG.fieldValue)
        if key is not None and value is not None:result[str(key)]=str(value)
    return result

def resolve_assertion(g,t,source):
    candidates=[]
    for a in g.subjects(RDF.type, KG.SourceStructuredAssertion):
        if str(g.value(a,KG.sourceFile))!=source['sourceFile']:continue
        if str(g.value(a,KG.sourcePage))!=str(source['page']):continue
        ff=assertion_fields(g,a)
        if ff.get('fact_type')!=t['fields']['fact_type']:continue
        evidence=str(g.value(a,KG.sourceEvidence) or '')
        match=norm(source['evidence']) in norm(evidence) or norm(evidence) in norm(source['evidence'])
        # This one-time mapping resolves repeated source excerpts to a unique assertion URI;
        # output queries only use the frozen URI, never expected answer literals.
        shared=sum(ff.get(k)==v for k,v in t['fields'].items())
        candidates.append((match,shared,str(a),ff))
    if not candidates: raise RuntimeError('No eligible assertion for '+t['test_id']+' / '+source['sourceFile'])
    candidates.sort(reverse=True)
    if len(candidates)>1 and candidates[0][:2]==candidates[1][:2]:
        raise RuntimeError('Ambiguous assertion grounding for '+t['test_id'])
    return URIRef(candidates[0][2]),candidates[0][3]

def read_decisions(name):
    path=ROOT/'data'/name
    with path.open(encoding='utf-8-sig',newline='') as f:
        rows=list(csv.DictReader(f))
    decisions={}
    for row in rows:
        tid=row['Test ID']
        if tid in decisions:raise ValueError('Repeated reviewed test ID '+tid)
        if row['Final Decision'] not in ('Passed','Failed') or row['Review Status']!='Reviewed':
            raise ValueError('Reviewed decision missing for '+tid)
        decisions[tid]=row['Final Decision']
    if len(decisions)!=40:raise ValueError('Expected 40 reviewed decisions in '+name)
    return decisions

def main():
    ref=json.loads((ROOT/'data/40_cq_reference_answers.json').read_text(encoding='utf-8'))
    evidence_reviews=read_decisions('40_evidence_aware_reviewed_decisions.csv')
    spo_reviews=read_decisions('40_spo_reviewed_decisions.csv')
    g=Graph();g.parse(str(ROOT/'data/source_grounded_fields_40CQs.ttl'),format='turtle')
    ds=Dataset();qfull=ROOT/'queries_evidence_aware';qspo=ROOT/'queries_spo'
    for d in (qfull,qspo,ROOT/'results/comparison_query_outputs/evidence_aware',ROOT/'results/comparison_query_outputs/spo'):d.mkdir(parents=True,exist_ok=True)
    policy=json.loads((ROOT/'data/spo_scoring_policy.json').read_text(encoding='utf-8'))
    min_ratio=float(policy['minimum_source_field_recall'])
    essential={cq:set(v) for cq,v in policy['essential_qualifier_fields_by_cq'].items()}
    lexicon={};index=[];source_result=[];field_result=[];test_result=[];spo_statements=[]
    if len(ref)!=40:raise ValueError('Exactly 40 reference tests required')
    for t in ref:
        tid=t['test_id']; row_fields=t['fields']; per_src=[];per_src_spo=[];per_src_essential_missing=[]
        if tid not in evidence_reviews or tid not in spo_reviews:raise ValueError('Test is missing a reviewed decision: '+tid)
        for j,src in enumerate(t['sources'],start=1):
            a,field_dict=resolve_assertion(g,t,src)
            assert row_fields==field_dict,(tid,list(set(row_fields.items()) ^ set(field_dict.items())))
            slug=f'{tid}_{src["language"]}{src["page"]}'
            ctx=URIRef(BASE+'graph/'+sha(tid+'|'+str(j)+'|'+str(a)))
            spo_sub=str(field_dict.get('subject','') or '(case '+slug+')')
            spo_rel=str(field_dict.get('relation','') or '(relation)')
            spo_obj=str(field_dict.get('object',''))
            sub_uri=URIRef(BASE+'entity/'+sha(spo_sub));p_uri=URIRef(BASE+'relation/'+sha(spo_rel))
            ds.graph(ctx).add((sub_uri,p_uri,Literal(spo_obj)))
            spo_statements.append((str(ctx),str(sub_uri),str(p_uri),Literal(spo_obj).n3()))
            lexicon[str(sub_uri)]=spo_sub;lexicon[str(p_uri)]=spo_rel
            full_query=('PREFIX kg: <https://example.org/dengue-research-case/schema/>\n'
                'SELECT ?field ?value WHERE {\n  <'+str(a)+'> kg:hasField ?item .\n'
                '  ?item kg:fieldKey ?field ; kg:fieldValue ?value .\n}\nORDER BY ?field\n')
            spo_query=('SELECT ?subject ?predicate ?object WHERE {\n GRAPH <'+str(ctx)+'> { ?subject ?predicate ?object . }\n}\n')
            (qfull/(slug+'.rq')).write_text(full_query,encoding='utf-8')
            (qspo/(slug+'.rq')).write_text(spo_query,encoding='utf-8')
            frows=[{'field':str(r[0]),'value':str(r[1])} for r in g.query(full_query)]
            srows=[{'subject':str(r[0]),'predicate':str(r[1]),'object':str(r[2])} for r in ds.query(spo_query)]
            save_csv(ROOT/'results/comparison_query_outputs/evidence_aware'/(slug+'.csv'),frows,['field','value'])
            save_csv(ROOT/'results/comparison_query_outputs/spo'/(slug+'.csv'),srows,['subject','predicate','object'])
            retrieved={r['field']:r['value'] for r in frows}
            full_complete=all(retrieved.get(k)==v for k,v in row_fields.items())
            if len(srows)!=1:raise RuntimeError('Expected one SPO row for '+slug)
            spo_recovered={}
            for k,v in row_fields.items():
                if k=='fact_type':continue
                if k in ('subject','relation','object'):
                    yes=field_dict.get(k,'')==v
                    reason='Core SPO component' if yes else 'Core component missing'
                else:yes,reason=score_literal(k,v,spo_sub,spo_rel,spo_obj)
                spo_recovered[k]=yes
                field_result.append({'Test ID':tid,'CQ Category':t['cq'],'Source Query':slug,'Field':k,'Required Value':v,
                    'Evidence-aware Field Present':'Yes' if retrieved.get(k)==v else 'No',
                    'SPO Recoverable':'Yes' if yes else 'No','SPO Recovery Basis':reason})
            n_recovered=sum(spo_recovered.values());n_fields=len(spo_recovered)
            ratio=n_recovered/n_fields if n_fields else 1.0
            absent_essential=sorted(k for k in essential[t['cq']] if k in spo_recovered and not spo_recovered[k])
            absent_core=sorted(k for k in policy['core_statement_fields'] if k in spo_recovered and not spo_recovered[k])
            spo_ok=(ratio>=min_ratio and not absent_essential and not absent_core)
            per_src_spo.append(spo_ok)
            per_src_essential_missing.extend(absent_essential)
            per_src.append(full_complete)
            source_result.append({'Test ID':tid,'CQ Category':t['cq'],'Source Query':slug,'Assertion URI':str(a),'SPO Graph URI':str(ctx),
                'Source File':src['sourceFile'],'Evidence-aware Returned Fields':len(frows),'SPO Returned Triples':len(srows),
                'Evidence-aware Fields Present':'Yes' if full_complete else 'No',
                'SPO Answer Support':'Yes' if spo_ok else 'No',
                'SPO Recovered Field Share':round(ratio,4),
                'SPO Missing Essential Fields':'; '.join(absent_essential)})
            index.append({'test_id':tid,'cq':t['cq'],'source_query':slug,'source_file':src['sourceFile'],
                'assertion_uri':str(a),'spo_graph':str(ctx),'source_page':src['page']})
        full_support=all(per_src);spo_support=all(per_src_spo)
        missing_keys=sorted({r['Field'] for r in field_result if r['Test ID']==tid and r['SPO Recoverable']=='No'})
        failed_sources=[r['Source Query'] for r in source_result if r['Test ID']==tid and r['SPO Answer Support']=='No']
        # Reviewer-confirmed classifications must agree with the reproducing scorer.
        if ('Passed' if spo_support else 'Failed')!=spo_reviews[tid]:
            raise RuntimeError('SPO reviewed decision disagrees with computed answer support: '+tid)
        test_result.append({'Test ID':tid,'CQ Category':t['cq'],'Reference Answer':t['answer'],'Source Queries':len(per_src),
            'Evidence-aware Field Support':'Yes' if full_support else 'No',
            'Evidence-aware Reviewed Decision':evidence_reviews[tid],
            'SPO Answer Support':'Yes' if spo_support else 'No',
            'SPO Reviewed Decision':spo_reviews[tid],
            'SPO Missing Essential Fields':'; '.join(sorted(set(per_src_essential_missing))),
            'SPO Missing Fields':'; '.join(missing_keys),
            'SPO Unsupported Source Queries':'; '.join(failed_sources)})
    # Stable TriG output for byte-for-byte replay.
    spo_text='\n'.join('<'+c+'> {\n  <'+s+'> <'+p+'> '+o+' .\n}' for c,s,p,o in sorted(spo_statements))+'\n'
    (ROOT/'data/spo_projection_40CQs.trig').write_text(spo_text,encoding='utf-8')
    (ROOT/'data/spo_uri_lexicon.json').write_text(json.dumps(lexicon,ensure_ascii=False,indent=2),encoding='utf-8')
    (ROOT/'data/paired_assertion_index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2),encoding='utf-8')
    save_csv(ROOT/'results/40_paired_representation_comparison.csv',test_result)
    save_csv(ROOT/'results/42_paired_source_queries.csv',source_result)
    save_csv(ROOT/'results/field_level_spo_recoverability.csv',field_result)
    n=len(test_result)
    n_full_fields=sum(r['Evidence-aware Field Support']=='Yes' for r in test_result)
    n_full_review=sum(r['Evidence-aware Reviewed Decision']=='Passed' for r in test_result)
    n_spo_support=sum(r['SPO Answer Support']=='Yes' for r in test_result)
    n_spo_review=sum(r['SPO Reviewed Decision']=='Passed' for r in test_result)
    counts={}
    for cq in sorted(set(r['CQ Category'] for r in test_result)):
        rr=[r for r in test_result if r['CQ Category']==cq]
        counts[cq]={'tests':len(rr),
           'evidence_aware_field_support':sum(r['Evidence-aware Field Support']=='Yes' for r in rr),
           'evidence_aware_reviewed_passed':sum(r['Evidence-aware Reviewed Decision']=='Passed' for r in rr),
           'spo_answer_support':sum(r['SPO Answer Support']=='Yes' for r in rr),
           'spo_reviewed_passed':sum(r['SPO Reviewed Decision']=='Passed' for r in rr)}
    summary={'test_instances':n,'source_queries':len(source_result),
        'evidence_aware_field_support':{'passed':n_full_fields,'total':n,'rate':n_full_fields/n},
        'evidence_aware_reviewed_answers':{'passed':n_full_review,'total':n,'rate':n_full_review/n},
        'spo_answer_support':{'passed':n_spo_support,'total':n,'rate':n_spo_support/n},
        'spo_reviewed_answers':{'passed':n_spo_review,'total':n,'rate':n_spo_review/n},
        'scoring_policy_file':'data/spo_scoring_policy.json',
        'review_source':'Both 40-item decision files are included in data/. SPO decisions were confirmed as manually reviewed by the user; individual reviewer forms were not supplied.',
        'baseline_method':'SPO projection of the same 42 source-grounded assertions, retaining subject/predicate/object and dropping additional qualifier fields.',
        'query_scoring_protocol':'Queries retrieve all stored data in fixed source scopes; gold values are compared by Python rather than inserted into SPARQL filters. A single SPO essential-answer policy is applied.',
        'by_cq':counts}
    (ROOT/'results/representation_comparison_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(summary,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
