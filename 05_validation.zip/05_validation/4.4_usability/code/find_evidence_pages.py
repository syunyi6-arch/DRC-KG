"""Locate the passages that back each CQ reference answer, with real PDF page numbers."""
import glob
import os
import re

import fitz

BASE = r'1.中英文本体与标注文件成果\中文138篇'

TARGETS = {
    '001_': ['彻底铲除伊蚊孳生地', '最后1', '登革热Ⅰ型病毒', '本起疫情共发病', '均否认有外出史',
             '快速灭蚊', '清除蚊虫孳生地', '农民', '职业'],
    '085_': ['不排除经性传播', '不能明确归因', '刘某某', '封某某', '夫妻'],
    '016_': ['布雷图指数', 'BI', '有效控制', '散发病例'],
}

for prefix, needles in TARGETS.items():
    hits = glob.glob(os.path.join(BASE, prefix + '*.pdf'))
    if not hits:
        print('MISSING', prefix)
        continue
    path = hits[0]
    print('=' * 78)
    print(os.path.basename(path))
    doc = fitz.open(path)
    print(f'  pages={doc.page_count}')
    pages = []
    for i in range(doc.page_count):
        pages.append(doc[i].get_text('text'))
    for nd in needles:
        found = [i + 1 for i, t in enumerate(pages) if nd in t]
        print(f'  {nd!r:24s} -> pages {found}')
    doc.close()
