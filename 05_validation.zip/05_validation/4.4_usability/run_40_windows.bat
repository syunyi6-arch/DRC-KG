@echo off
cd /d "%~dp0"
python -m pip install -r requirements.txt
if errorlevel 1 exit /b 1
python code\reproduce_40_cqs.py --verify-full-rdf
pause
