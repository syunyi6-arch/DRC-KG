# 4.4 Usability

## Result

For DRC-KG (Dengue Research Case Knowledge Graph), all 12 competency questions have executable
queries and return results. Checked item by item against the source PDF, 10 answers are correct
(83.3%) and 2 are wrong (CQ2, CQ8). CQ6 and CQ7 return empty sets, which is what the question
design expects.

## Result files

| File | Content |
|---|---|
| `results/cq12_results_summary.csv` | all 12: question, SPARQL file, number of result rows, verdict |
| `results/cq12_results_per_question.csv` | per-question verdict: test instance, reference-answer points, returned result, rule applied, basis |
| `results/cq12_reference_answers.csv` | 12 reference answers, evidence page numbers, checker / conclusion signature |
| `results/01_sparql_queries/CQ01…CQ12*.rq` | 12 executable SPARQL queries |
| `results/02_query_results/CQ01…CQ12_results.csv` | the rows actually returned for each query |

## Decision rules

| Rule | Content |
|---|---|
| R1 | Answer agreement: the returned rows must contain the key fields required by the reference answer |
| R2 | Empty-set agreement: when the source really has no such knowledge, an empty result counts as correct |
| R3 | Retrieval-type questions are judged only on whether objects and associations are retrieved; relation direction is scored by the mapping check in 4.3 |
| R4 | When the source genuinely gives no time, returning an empty time with a "cannot be inferred" note counts as correct |
| R5 | Polarity: a negation in the source must not be turned into an affirmative relation |

## Code

| Script | Purpose |
|---|---|
| `00_common_code/src/cq.py` | retrieval for the 12 competency questions and SPARQL generation |
| `code/build_cq_reference.py` | builds the 12 reference answers and evidence page numbers |
| `code/find_evidence_pages.py` | locates evidence page numbers in the source PDFs |
| `code/cq_detail.py`, `code/cq_recheck.py` | per-question checking and result aggregation |

## Scope notes

- An empty set is not a wrong answer: CQ6 and CQ7 depend on the admission / exclusion classification of directed
  transmission, and any claim without a transmission-attribute verdict is kept out of the result.
- The accuracy figure is computed only over the 12 items that were verified against the source PDFs and must not
  be extrapolated to overall usability.
