# 4.4 Usability

```text
4.4_usability/
├── README.md
├── requirements.txt
├── run_40_windows.bat
├── run_40_unix.sh
├── run_comparison_windows.bat
├── run_comparison_unix.sh
├── code/
│   ├── reproduce_40_cqs.py
│   └── run_representation_comparison.py
├── data/
│   ├── DRCKG_frozen_40CQs.ttl
│   ├── source_grounded_fields_40CQs.ttl
│   ├── spo_projection_40CQs.trig
│   ├── spo_uri_lexicon.json
│   ├── spo_scoring_policy.json
│   ├── paired_representation_manifest.json
│   ├── paired_assertion_index.json
│   ├── 40_cq_reference_answers.json
│   ├── 40_cq_run_manifest.json
│   ├── 40_evidence_aware_reviewed_decisions.csv
│   └── 40_spo_reviewed_decisions.csv
├── queries/
│   └── *.rq
├── queries_evidence_aware/
│   └── *.rq
├── queries_spo/
│   └── *.rq
└── results/
    ├── 40_CQ_EvidenceAware_vs_SPO_Results.xlsx
    ├── 40_query_execution.csv
    ├── 40_source_evidence_validation.csv
    ├── 40_paired_representation_comparison.csv
    ├── 42_paired_source_queries.csv
    ├── field_level_spo_recoverability.csv
    ├── representation_comparison_summary.json
    ├── query_outputs/
    │   └── *.csv
    └── comparison_query_outputs/
        ├── evidence_aware/*.csv
        └── spo/*.csv
```

## Reproduction

From `4.4_usability/`:

```bash
python -m pip install -r requirements.txt
python code/reproduce_40_cqs.py --verify-full-rdf
python code/run_representation_comparison.py
```

On Windows run `run_40_windows.bat` and `run_comparison_windows.bat`; on Linux/macOS run
`bash run_40_unix.sh` and `bash run_comparison_unix.sh`.

`reproduce_40_cqs.py` writes its CSV and JSON outputs to `reproduced/`.
`run_representation_comparison.py` writes `results/40_paired_representation_comparison.csv`,
`results/42_paired_source_queries.csv`, `results/field_level_spo_recoverability.csv`,
`results/representation_comparison_summary.json` and `results/comparison_query_outputs/`.
