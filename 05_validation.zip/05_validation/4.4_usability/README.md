# 4.4 Usability: Competency-Question Representation Comparison

## 1. Folder Structure and File Descriptions

```text
4.4_usability/
├── README.md
├── requirements.txt
├── run_40_windows.bat
├── run_40_unix.sh
├── run_comparison_windows.bat
├── run_comparison_unix.sh
├── code/
│   ├── reproduce_40_cqs.py
│   └── run_representation_comparison.py
├── data/
│   ├── DRCKG_frozen_40CQs.ttl
│   ├── source_grounded_fields_40CQs.ttl
│   ├── spo_projection_40CQs.trig
│   ├── spo_uri_lexicon.json
│   ├── paired_representation_manifest.json
│   ├── paired_assertion_index.json
│   ├── spo_scoring_policy.json
│   ├── 40_cq_reference_answers.json
│   ├── 40_cq_run_manifest.json
│   ├── 40_evidence_aware_reviewed_decisions.csv
│   └── 40_spo_reviewed_decisions.csv
├── queries/
│   └── *.rq
├── queries_evidence_aware/
│   └── *.rq
├── queries_spo/
│   └── *.rq
└── results/
    ├── 40_CQ_EvidenceAware_vs_SPO_Results.xlsx
    ├── 40_query_execution.csv
    ├── 40_source_evidence_validation.csv
    ├── 40_paired_representation_comparison.csv
    ├── 42_paired_source_queries.csv
    ├── field_level_spo_recoverability.csv
    ├── representation_comparison_summary.json
    ├── query_outputs/
    │   └── *.csv
    └── comparison_query_outputs/
        ├── evidence_aware/*.csv
        └── spo/*.csv
```

| Path | Description |
|---|---|
| `README.md` | Folder layout and reproduction instructions. |
| `requirements.txt` | Python dependencies. |
| `run_40_windows.bat`, `run_40_unix.sh` | Replay the source-level competency-question queries. |
| `run_comparison_windows.bat`, `run_comparison_unix.sh` | Execute the paired representation comparison. |
| `code/reproduce_40_cqs.py` | Re-run original source queries and summarize the included reviewed answer decisions. |
| `code/run_representation_comparison.py` | Rebuild the paired SPO representation, execute both query sets, and check recovered answer fields against reviewed decisions. |
| `data/DRCKG_frozen_40CQs.ttl` | Frozen full DRC-KG RDF data. |
| `data/source_grounded_fields_40CQs.ttl` | Source-linked assertions used in the fixed competency-question suite. |
| `data/spo_projection_40CQs.trig` | Simplified subject–predicate–object projection. |
| `data/spo_uri_lexicon.json` | Entity and predicate labels corresponding to SPO IRIs. |
| `data/paired_representation_manifest.json`, `data/40_cq_run_manifest.json` | File checksums and run metadata. |
| `data/paired_assertion_index.json` | Source assertion identifiers and paired SPO graph identifiers. |
| `data/spo_scoring_policy.json` | The current, single SPO answer-support scoring policy. |
| `data/40_cq_reference_answers.json` | Reference answers and original-language source excerpts. |
| `data/40_evidence_aware_reviewed_decisions.csv`, `data/40_spo_reviewed_decisions.csv` | Item-level reviewed outcomes for both representations. |
| `queries/` | Original source-level SPARQL query files. |
| `queries_evidence_aware/` | Evidence-aware source-scoped SPARQL queries. |
| `queries_spo/` | Matched simplified SPO source-scoped SPARQL queries. |
| `results/40_CQ_EvidenceAware_vs_SPO_Results.xlsx` | Consolidated English results workbook. |
| `results/*.csv`, `results/*.json` | Paired-test, source-query, field-level, and summary outputs. |
| `results/query_outputs/` | Saved outputs of original source-level queries. |
| `results/comparison_query_outputs/` | Saved outputs of the two representation query suites. |

## 2. Code Reproduction

### 2.1 Requirements

Python 3.10 or later. Keep the directory layout shown above when copying this folder elsewhere.

### 2.2 Install dependencies

From the `4.4_usability/` directory:

```bash
python -m pip install -r requirements.txt
```

### 2.3 Re-run the source-level competency-question queries

```bash
python code/reproduce_40_cqs.py --verify-full-rdf
```

The optional `--verify-full-rdf` flag validates the frozen RDF file against its SHA-256 digest. The script writes CSV and JSON outputs to `reproduced/` without overwriting packaged results.

On Windows, run `run_40_windows.bat`. On Linux/macOS, run `bash run_40_unix.sh`.

### 2.4 Re-run the evidence-aware versus SPO comparison

```bash
python code/run_representation_comparison.py
```

The script regenerates the paired SPO TriG representation, both source-scoped query sets, query output CSVs, field-level checks, test-level comparisons, and JSON summary. It verifies agreement between the current SPO scoring decisions and the supplied reviewed SPO decision file.

On Windows, run `run_comparison_windows.bat`. On Linux/macOS, run `bash run_comparison_unix.sh`.

Outputs written by the comparison script:

```text
results/
├── 40_paired_representation_comparison.csv
├── 42_paired_source_queries.csv
├── field_level_spo_recoverability.csv
├── representation_comparison_summary.json
└── comparison_query_outputs/
    ├── evidence_aware/*.csv
    └── spo/*.csv
```

The formatted Excel workbook is the packaged snapshot of the same per-test and per-query results; the Python script regenerates CSV and JSON files and does not rewrite the workbook.
