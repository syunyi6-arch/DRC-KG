# DRC-KG ontology — namespace and identifiers

`Dengue_Research_Case_Ontology.ttl` (Turtle) and `Dengue_Research_Case_Ontology.owl`
(RDF/XML) are two serialisations of the same 6,884-triple graph; the Turtle is the
editable source and the RDF/XML is generated from it (the two graphs are isomorphic).

## Bilingual labels

Every term carries two `rdfs:label` values: `@en` (the canonical English term, identical to
`label_en` in `ontology_term_map.csv`) and `@zh` (the Chinese name, identical to `label_zh`).
The Chinese name and definition also appear in the `@zh` `rdfs:comment`, in its name and
definition lines; before the `@zh` labels were added, the Chinese name existed only inside
that comment, so a label-based lookup returned nothing in Chinese. 489 subjects (488 terms
plus the ontology header) now carry both labels, and
`04_knowledge_graph/03_code/add_ontology_zh_labels.py` reproduces the step from the comments.

## Namespace

All identifiers live under `urn:dengekg:ontology:`:

| Prefix | Namespace | Holds |
|---|---|---|
| `dkg` | `urn:dengekg:ontology:` | the ontology IRI itself |
| `dgoc` | `urn:dengekg:ontology:class:` | 103 classes (`DKG-C-0001`…) |
| `dgoa` | `urn:dengekg:ontology:attribute:` | 220 datatype properties (`DKG-A-0001`…) |
| `dgor` | `urn:dengekg:ontology:relation:` | 154 object properties (`DKG-R-0001`…) |
| `dgom` | `urn:dengekg:ontology:meta:` | 11 annotation properties used for provenance and mapping notes |

The class, attribute and relation identifiers are the same identifiers published in
`ontology_term_map.csv` (467 rows: 103 classes, 210 attributes, 154 relations), so an
OWL declaration, a row of the standardised tables and a graph node share one URI.

## Attribute suffixes

Three groups of attributes need identifiers beyond the 210 attribute names of the
workbooks; they stay inside `urn:dengekg:ontology:attribute:` and are derived from the
parent identifier:

- `-C####` — the same attribute name asserted for several classes (four names:
  environmental characteristics, object count, reporting timeliness, statistical group;
  seven declarations). The base identifier is kept for the first declaration and each
  further one carries the class suffix, e.g. `DKG-A-0108-C0009`.
- `-sub` — the three secondary attributes of the attribute workbook (background range of
  dengue incubation duration; number of strains included in E-gene sequence comparison;
  number of complete viral genomes successfully obtained in this study), e.g.
  `DKG-A-0070-sub`.

`ontology_term_map.csv` deliberately covers the 210 workbook attribute names rather than
these derived identifiers; the suffix rules above are the only way attribute IRIs diverge
from it.

## Version note

Identifiers were migrated from `https://example.org/dengue-research-case-bilingual#` to
the `urn:dengekg:ontology:` namespace on 2026-11-17. The migration renamed IRIs only:
labels, comments, domains, ranges, sub-class and sub-property axioms, and blank-node class
expressions are unchanged, and the graph is isomorphic to the previous version under the
IRI mapping.
