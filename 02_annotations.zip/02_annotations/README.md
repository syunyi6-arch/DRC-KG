# 02_annotations — classification workbooks

Four workbooks hold the 213,851 annotation rows behind the knowledge graph:

| File | Corpus | Mirror |
|---|---|---|
| `CN_138_classification_tables_ontology-zh.xlsx` | 138 Chinese articles | Chinese headers, Chinese ontology labels |
| `CN_138_classification_tables_ontology-en.xlsx` | 138 Chinese articles | English headers, canonical English ontology labels |
| `EN_123_classification_tables_ontology-zh.xlsx` | 123 English articles | Chinese headers, Chinese ontology labels |
| `EN_123_classification_tables_ontology-en.xlsx` | 123 English articles | English headers, canonical English ontology labels |

Each workbook has the same seven sheets, and the four books are row-aligned. The sheets are referred to
by their number throughout the release tables:

| Sheet | Content | Rows (CN / EN) |
|---|---|---|
| `01` class | entity type, entity value, source text, source file | 48,590 / 40,430 |
| `02` attribute | class, entity, attribute, value, source text | 25,692 / 39,782 |
| `03` relation | head type/value, relation, tail type/value, ontology relation | 32,785 / 20,005 |
| `04` rules | rule element, rule content | 119 / 829 |
| `05` transmission class | participants of a transmission statement and their role | 1,628 / 148 |
| `06` transmission attribute | attributes of a transmission statement | 1,956 / 281 |
| `07` transmission relation | relations inside a transmission statement | 1,505 / 101 |

## Language rules

- **Only labels are translated.** The `-en` mirror takes entity/attribute/relation labels from the
  reviewed term map (`03_ontology/ontology_bilingual.xlsx`, the reviewed mapping sheet, 467 terms); the
  annotation values themselves (entity names, relation text, rule text, article titles) stay in the
  language of the source article in both mirrors. Translation happens at label level, never at content
  level.
- The `-zh` workbooks carry a trailing batch column: a blank cell marks the main annotation batch and
  `increment_1115` marks the 11-15 increment batch (149 rows over 17 cases). The increment batch only
  has Chinese columns; its English labels are backfilled from the term map, as recorded in
  `04_knowledge_graph/01_standardized_data/release_manifest.json`.
- Sheet `05`, the instance-role column: the English mirror now carries English roles. The Chinese role
  text is kept in `role_raw` in the released table, the English rendering in `role_en`, and the
  Chinese-to-English mapping is `04_knowledge_graph/03_code/role_en_map.json`. The build fails if a
  Chinese role has no mapping, so the two columns cannot drift apart.
