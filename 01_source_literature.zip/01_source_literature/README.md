# 01_source_literature — research-case literature index

`DRC-KG_261_Research_Papers.csv` / `.xlsx` is the master index of the **261 research-case articles**
held by DRC-KG (138 Chinese / 123 English). It is both the bibliography and the per-article
"data ledger": every count column matches
`04_knowledge_graph/01_standardized_data/cases.csv` exactly.

| Column | Meaning |
|---|---|
| `case_id` | Case ID: `CN-001…CN-138` / `EN-001…EN-123`, the same prefix used as the key in every KG table |
| `language` | Corpus language: `CN` / `EN` |
| `title` `authors` `journal` `publication_year` | Bibliographic metadata, taken from the article record |
| `n_01…n_07` | Raw annotation rows this case contributes to each of the seven sheets (class / attribute / relation / rules / transmission class / transmission attribute / transmission relation) |
| `total_source_rows` | Total rows across the seven sheets |
| `has_rules` `has_transmission` | Whether the case has rule / transmission records |
| `n_entities` `n_attributes` `n_relations` `n_transmission` `n_rules` `n_knowledge_units` `n_evidence` | Entities / attributes / relations / transmission statements / rules / knowledge units / evidence records derived from this case |
| `n_increment_rows` | Rows added by the increment batch `increment_1115` (the trailing batch column of the `-zh` workbooks): 149 rows over 17 cases |

## Provenance and rebuild

- Bibliographic metadata (`title` / `authors` / `journal` / `publication_year`) is copied verbatim from
  the articles.
- Every count column is computed by `04_knowledge_graph/03_code/build_papers_table.py` from
  `04_knowledge_graph/01_standardized_data/cases.csv`, so the index can never drift from the graph data.

```bash
python 04_knowledge_graph/03_code/build_kg_tables.py    # 02_annotations + increment -> 01_standardized_data
python 04_knowledge_graph/03_code/build_papers_table.py # 01_standardized_data/cases.csv -> this folder
```

## Encoding

`*.csv` is UTF-8 with BOM (`utf-8-sig`), which Excel on a Chinese Windows opens without asking about
encoding and without mojibake; `*.xlsx` is the same table with frozen panes and column widths.
