# 01_source_literature — 研究案例文献索引

`DRC-KG_261_Research_Papers.csv` / `.xlsx` 是 DRC-KG 收录的 **261 篇研究案例文献**总表
（中文 138 篇 / 英文 123 篇）。它既是文献清单，也是该数据集在每一篇文献上的“数据量台账”：
每一行的计数列都与 `04_knowledge_graph/01_standardized_data/cases.csv` 完全一致。

| 列 | 含义 |
|---|---|
| `case_id` | 案例编号：`CN-001…CN-138` / `EN-001…EN-123`，与知识图谱各表的主键前缀一致 |
| `language` | 语种：`CN` / `EN` |
| `title` `authors` `journal` `publication_year` | 文献题录（部分条目原表即缺 `journal` / `publication_year`，未做推测补全） |
| `n_01…n_07` | 该案例在七张标注表（类 / 属性 / 关系 / 规则 / 传播类 / 传播属性 / 传播关系）中的原始标注行数 |
| `total_source_rows` | 七张表行数合计 |
| `has_rules` `has_transmission` | 该案例是否含规则表 / 传播关系表记录 |
| `n_entities` `n_attributes` `n_relations` `n_transmission` `n_rules` `n_knowledge_units` `n_evidence` | 由该案例派生到知识图谱中的实体 / 属性 / 关系 / 传播实例 / 规则 / 知识单元 / 证据条数 |
| `n_increment_rows` | 该案例在增量批次 `increment_1115`（`02_annotations` 中的 `批次` 列）里的标注行数；合计 149 行、涉及 17 个案例 |

## 数据来源与重建

- 题录元数据（`title` / `authors` / `journal` / `publication_year`）逐字取自原文，未做推测补全。
- 全部计数列由 `04_knowledge_graph/03_code/build_papers_table.py` 从
  `04_knowledge_graph/01_standardized_data/cases.csv` 计算后写回，与图谱数据保持一致。

```bash
python 04_knowledge_graph/03_code/build_kg_tables.py    # 02_annotations + 增量七分表 -> 01_standardized_data
python 04_knowledge_graph/03_code/build_papers_table.py # 01_standardized_data/cases.csv -> 本目录
```

## 编码

`*.csv` 使用 **GB18030** 编码（中文 Windows 下 Excel 双击不会乱码）；`*.xlsx` 为同一张表，
带冻结窗格与列宽，适合直接查看/筛选。
