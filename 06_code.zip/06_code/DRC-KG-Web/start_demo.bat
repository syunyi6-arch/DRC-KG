@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Run install_windows.bat first.
  pause
  exit /b 1
)
set "DENGEKG_MODE=demo"
echo Open http://127.0.0.1:7860 after the server starts. Ctrl+C stops it.
".venv\Scripts\python.exe" app.py
pause
