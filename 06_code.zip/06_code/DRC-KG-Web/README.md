# DRC-KG-Web — Gradio 交互站点

`DRC-KG-Web-HTML-JS/` 是同一套界面与数据的静态版本；本目录是它的 Python/Gradio 版本，
两者共用 `ui_text.py`（界面措辞的唯一来源）和同一份知识图谱数据。

## 三种运行模式

| 模式 | 启动 | 数据来源 |
|---|---|---|
| `demo` | `start_demo.bat` | 两个虚构演示案例（`demo_data.py`） |
| **`std`** | **`start_std.bat`** | **`../../04_knowledge_graph/01_standardized_data/`（本仓库的标准表，内部候选）** |
| `public` | `start_public.bat` | 本目录下 `public_data/`，必须通过 `release_check.py` 的发布审批校验 |

`std` 模式：`release_from_std.py` 把 04 的 13 张标准表映射成 Gradio 应用原本要求的
“发布视图”字段（`entity_name` / `owner_id` / `endpoint_status` / `certainty_original` …），
因此 `app.py`、`detail_views.py`、`graph_view.py` 的视图逻辑一行不用改。映射规则与静态站
`../DRC-KG-Web-HTML-JS/README.md` 的“Field mapping”一节完全一致。

若标准表换了路径：`set DRC_KG_STD=D:\path\to\01_standardized_data` 后再启动。

## 三点必须知道的口径（与静态站相同）

1. **实体只做案例内字面匹配**：`owner_id` / `head_id` / `tail_id` / `source_id` / `target_id` 是
   同一案例内“原始表述 → 实体编号”的字面命中，状态一律写作 `candidate`，找不到时写 `unresolved`。
   标准化表明确不做跨文献消歧，因此不存在 `resolved`。`graph_view.py` 与静态站的
   `graph.js` / `explorer.js` 都已把 `candidate` 视为可入图/可排序，否则图谱会是空的。
2. **部分字段为空**：`source_section`、`source_page`、`certainty_original`、`association_nature`、
   `assertion_polarity`、`resolution_status` 不在标准表里，一律输出空值，界面显示为“未记录/未说明”。
   这些字段要补，得回到原始标注/PDF 抽取层，不能由本体或术语表推出来。
3. **英文标签取自人工复核的本体**：`03_ontology/ontology_bilingual.xlsx`「统一术语映射」
   （467 条，`Missing canonical translations = 0`），构建脚本会逐次校验术语表与它完全一致，
   并把 `drift_vs_reviewed_map` 写进 `04_knowledge_graph/01_standardized_data/release_manifest.json`。

## 安装与运行

```bat
install_windows.bat        :: 建 .venv 并装 gradio==5.49.1 / pyvis==0.3.2
start_std.bat              :: 标准表模式，http://127.0.0.1:7860
```

自检（不需要浏览器，也不启动服务）：`python check_std.py` —— 打印 13 张表的行数、CN-011 的
传播/属性/规则视图、关系与传播的证据回溯条数、以及前 40 个案例里是否存在空图谱。

依赖：`requirements.txt`（gradio 5.49.1、pyvis 0.3.2）。

## 说明

本目录的应用代码是 `DengeKG/DengeKG-Web` 的移植（同一作者维护），差异只有：
新增 `std` 模式（`release_from_std.py`）、`graph_view.py` 的 `candidate` 判据、
以及 `ui_text.py` 增加 `mode_standardized` 一条措辞（静态站的 `i18n-data.js` 由它生成）。
