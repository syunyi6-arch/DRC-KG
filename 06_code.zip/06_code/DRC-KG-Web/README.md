# DRC-KG-Web — Gradio interactive site

`DRC-KG-Web-HTML-JS/` is the static twin of this folder; this one is the Python / Gradio version.
Both share `ui_text.py` (the single source of interface wording) and the same knowledge-graph data.

## Three run modes

| Mode | Start | Data source |
|---|---|---|
| `demo` | `start_demo.bat` | two fictional demonstration cases (`demo_data.py`) |
| **`std`** | **`start_std.bat`** | **`../../04_knowledge_graph/01_standardized_data/` (the released standard tables)** |
| `public` | `start_public.bat` | `public_data/`, which must pass the release check in `release_check.py` |

In `std` mode `release_from_std.py` maps the 13 standard tables onto the release-view fields the Gradio
app expects (`entity_name` / `owner_id` / `endpoint_status` / `certainty_original` …), so `app.py`,
`detail_views.py` and `graph_view.py` need no changes. The mapping rules are identical to the
"Field mapping" section of `../DRC-KG-Web-HTML-JS/README.md`.

To point at another directory: `set DRC_KG_STD=D:\\path\\to\\01_standardized_data` before starting.

## Three conventions you must know (same as the static site)

1. **Entities are matched only by literal name inside a case**: `owner_id` / `head_id` / `tail_id` /
   `source_id` / `target_id` are case-local literal hits from the raw name to an entity ID, written as
   `candidate`; `unresolved` when nothing matches. The standard tables deliberately perform no
   cross-paper disambiguation, so `resolved` never occurs. `graph_view.py` (and `graph.js` /
   `explorer.js` on the static site) accept `candidate` as drawable and rankable; otherwise the graph
   would be empty.
2. **Some fields are empty**: `source_section`, `source_page`, `certainty_original`,
   `association_nature`, `assertion_polarity` and `resolution_status` are not in the standard tables and
   are always emitted empty, shown as "not recorded / not stated". Filling them requires going back to
   the annotation / PDF extraction layer; they cannot be derived from the ontology or the term map.
3. **English labels come from the reviewed ontology**: `03_ontology/ontology_bilingual.xlsx`, the
   reviewed mapping sheet (467 terms, `Missing canonical translations = 0`). The build verifies the term
   map against that sheet and records `drift_vs_reviewed_map` in
   `04_knowledge_graph/01_standardized_data/release_manifest.json`.

## Interface language

Every interface string exists in Chinese and English (`ui_text.py`), and the page switch changes language
without a reload. Controlled status values from the data (`candidate`, `unresolved`, `true` / `false`)
are interface wording, not content: `enum_text()` translates them for display (the Chinese interface
shows the Chinese equivalents, the English interface keeps the canonical term). The data files
themselves are never rewritten by the interface.

## Install and run

```bat
install_windows.bat        :: create .venv and install gradio==5.49.1 / pyvis==0.3.2
start_std.bat              :: standard-table mode, http://127.0.0.1:7860
```

Self-check (no browser, no server): `python check_std.py` prints the row counts of the 13 tables, the
transmission / attribute / rule views of CN-011, the evidence-trace counts for relations and
transmission statements, and whether any of the first 40 cases has an empty graph.

Dependencies: `requirements.txt` (gradio 5.49.1, pyvis 0.3.2).

## Notes

This app is a port of `DengeKG/DengeKG-Web` (same maintainer). The differences are: the added `std`
mode (`release_from_std.py`), the `candidate` criterion in `graph_view.py`, the `mode_standardized`
message in `ui_text.py`, and the status-enum display helper added for language consistency.
