"""Readable PyVis viewer. Presentation only; source records stay unchanged."""
from __future__ import annotations

import html
import json
import re

from pyvis.network import Network

from ui_text import enum_text, t

CSS = r'''
html,body{margin:0!important;padding:0!important;background:white;font-family:"Microsoft YaHei",Arial,sans-serif;color:#183347}
.card{border:0!important}.card-body{padding:0!important}
#mynetwork{width:100%!important;height:calc(100vh - 160px)!important;min-height:440px;border:0!important;background:#fff;float:none!important;display:block}
#loadingBar{display:none!important}
#kg-tools{display:flex;gap:8px;align-items:center;flex-wrap:wrap;padding:12px;background:#f5f9fc;border-bottom:1px solid #d4e1ea}
#kg-tools button,#kg-tools select{font:14px "Microsoft YaHei",Arial,sans-serif;border:1px solid #bed0dc;background:#fff;border-radius:6px;padding:8px 10px;color:#173b53}
#kg-tools button:hover{background:#dfedf6}#kg-tools button:focus-visible,#kg-tools select:focus-visible{outline:2px solid #247bad}
#kg-tools label{font-size:13px}#kg-focus{max-width:290px}#kg-status{padding:8px 14px;font-size:13px;line-height:1.5;color:#456276}
#kg-tools label.kg-check{display:inline-flex;align-items:center;gap:6px;padding:7px 10px;border:1px solid #bed0dc;background:#fff;border-radius:6px;cursor:pointer;font-size:13px;color:#173b53}
#kg-tools label.kg-check input{margin:0;accent-color:#247bad;cursor:pointer}
#kg-detail{position:absolute;right:18px;bottom:62px;max-width:330px;max-height:200px;overflow:auto;white-space:pre-wrap;background:#fffffff2;border:1px solid #c6d8e5;border-radius:8px;padding:12px;font-size:14px;line-height:1.6;display:none;box-shadow:0 3px 14px #16354c18}
#kg-hint{padding:6px 14px;font-size:12px;color:#587183;border-top:1px solid #e3edf3}
@media(max-width:700px){#kg-focus{max-width:180px}#kg-tools{gap:5px;padding:8px}#mynetwork{height:calc(100vh - 220px)!important}#kg-detail{max-width:240px}}
'''

TOOLBAR_TEMPLATE = r'''
<div id="kg-tools" role="toolbar" aria-label="{aria}">
 <label>{scope_label} <select id="kg-limit" aria-label="{scope_label}"><option value="12">{scope_clear}</option><option value="24">{scope_extended}</option><option value="all" selected>{scope_all}</option></select></label>
 <label class="kg-check"><input type="checkbox" id="kg-attrs"> {show_attrs}</label>
 <label>{center_label} <select id="kg-focus" aria-label="{center_label}"></select></label>
 <button id="kg-refocus" type="button">{focus}</button>
 <button id="kg-in" type="button" aria-label="{zoom_in_aria}">{zoom_in}</button>
 <button id="kg-out" type="button" aria-label="{zoom_out_aria}">{zoom_out}</button>
 <button id="kg-fit" type="button">{fit}</button>
 <button id="kg-readable" type="button">{readable}</button>
 <button id="kg-radial" type="button">{radial}</button>
 <button id="kg-font" type="button">{font}</button>
 <button id="kg-full" type="button">{fullscreen}</button>
</div><div id="kg-status" role="status"></div>
'''

SCRIPT = r'''
(function(){
 'use strict';
 const T=__TEXT__;
 const fill=(text,values)=>text.replace(/%(\d)/g,(m,i)=>String(values[Number(i)-1]));
 const esc=(value)=>String(value).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
 const short=(value,max)=>String(value).length>max?String(value).slice(0,max-1)+'…':String(value);
 const ATTRS=window.KG_ATTRIBUTES||{};
 const ATTR_LIMIT=240;
 let attrInfo=new Map();
 const allNodes=nodes.get(),allEdges=edges.get();
 const nodeMap=new Map(allNodes.map(n=>[n.id,n]));
 const degree=new Map(allNodes.map(n=>[n.id,0]));
 const adjacency=new Map(allNodes.map(n=>[n.id,new Set()]));
 const structural=allEdges.filter(e=>e.kgKind!=='case_membership');
 for(const e of structural){
   if(!nodeMap.has(e.from)||!nodeMap.has(e.to))continue;
   degree.set(e.from,degree.get(e.from)+1); degree.set(e.to,degree.get(e.to)+1);
   adjacency.get(e.from).add(e.to);adjacency.get(e.to).add(e.from);
 }
 const rank=(a,b)=>(degree.get(b)||0)-(degree.get(a)||0)||String(a).localeCompare(String(b));
 const ranked=allNodes.map(n=>n.id).sort(rank);
 let root=ranked[0],fontSize=20,currentFont=20,stabilizationToken=0;
 const focus=document.getElementById('kg-focus'),limit=document.getElementById('kg-limit');
 const status=document.getElementById('kg-status'),detail=document.getElementById('kg-detail');
 for(const n of [...allNodes].sort((a,b)=>String(a.kgLabel).localeCompare(String(b.kgLabel)))){
   const o=document.createElement('option');o.value=String(n.id);o.textContent=n.kgLabel+'  ['+n.id+']';focus.appendChild(o);
 }
 focus.value=String(root);
 function subset(center,cap){
   if(cap==='all')return new Set(ranked);
   const selected=new Set([center]),queue=[center],max=Number(cap);
   while(queue.length&&selected.size<max){
     const id=queue.shift();
     for(const other of [...(adjacency.get(id)||[])].sort(rank)){
       if(selected.size>=max)break;
       if(!selected.has(other)){selected.add(other);queue.push(other);}
     }
   }
   // Include other components when the selected component has fewer nodes.
   for(const id of ranked){if(selected.size>=max)break;selected.add(id);}
   return selected;
 }
 function positionOf(id){return network.getPositions([id])[id]||{x:0,y:0};}
 function readableZoom(){network.moveTo({position:positionOf(root),scale:0.95,animation:{duration:220,easingFunction:'easeInOutQuad'}});}
 // Connected components of the displayed subgraph, largest first.
 function components(ids,adj){
   const idSet=new Set(ids),seen=new Set(),out=[];
   for(const id of ids){
     if(seen.has(id))continue;
     const comp=[],queue=[id];seen.add(id);
     while(queue.length){
       const cur=queue.shift();comp.push(cur);
       for(const nb of (adj.get(cur)||[])){
         if(idSet.has(nb)&&!seen.has(nb)){seen.add(nb);queue.push(nb);}
       }
     }
     out.push(comp);
   }
   return out.sort((a,b)=>b.length-a.length);
 }
 // One component drawn as rings: root in the middle, BFS depth decides the ring.
 // A ring is given enough circumference for every node on it, so nothing overlaps.
 function ringPositions(comp,spacing,adj){
   const idSet=new Set(comp),rootId=[...comp].sort(rank)[0];
   const level=new Map([[rootId,0]]),levels=new Map([[0,[rootId]]]),queue=[rootId];
   while(queue.length){
     const cur=queue.shift();
     for(const nb of [...(adj.get(cur)||[])].filter(n=>idSet.has(n)&&!level.has(n)).sort(rank)){
       const depth=level.get(cur)+1;
       level.set(nb,depth);queue.push(nb);
       if(!levels.has(depth))levels.set(depth,[]);
       levels.get(depth).push(nb);
     }
   }
   const maxLevel=Math.max(...levels.keys());
   const radius=new Map([[0,0]]);
   let r=0;
   for(let l=1;l<=maxLevel;l++){
     const needed=((levels.get(l)||[]).length*spacing)/(2*Math.PI);
     r=Math.max(r+spacing*0.85,needed);
     radius.set(l,r);
   }
   const pos=new Map();
   for(const [l,list] of levels){
     const R=radius.get(l)||0,step=2*Math.PI/Math.max(1,list.length);
     const offset=(l%2)?0:step/2;
     list.forEach((id,i)=>{
       const angle=-Math.PI/2+step*i+offset;
       pos.set(id,{x:R*Math.cos(angle),y:R*Math.sin(angle)});
     });
   }
   return pos;
 }
 // Pack every component into shelves so separate clusters never sit on top of each other.
 function spreadAll(ids,spacing,adj){
   const boxes=components(ids,adj).map(comp=>{
     const pos=ringPositions(comp,spacing,adj);
     let minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity;
     for(const p of pos.values()){
       minX=Math.min(minX,p.x);maxX=Math.max(maxX,p.x);
       minY=Math.min(minY,p.y);maxY=Math.max(maxY,p.y);
     }
     if(!isFinite(minX)){minX=maxX=minY=maxY=0;}
     return {pos,minX,minY,w:maxX-minX+spacing,h:maxY-minY+spacing};
   });
   const area=boxes.reduce((sum,b)=>sum+b.w*b.h,0);
   const targetWidth=Math.max(3*spacing,Math.sqrt(area)*1.15);
   const gap=spacing*0.55;
   const placement=new Map();
   let x=0,y=0,rowHeight=0;
   for(const box of boxes){
     if(x>0&&x+box.w>targetWidth){x=0;y+=rowHeight+gap;rowHeight=0;}
     const dx=x-box.minX+spacing/2,dy=y-box.minY+spacing/2;
     for(const [id,p] of box.pos)placement.set(id,{x:p.x+dx,y:p.y+dy});
     x+=box.w+gap;rowHeight=Math.max(rowHeight,box.h);
   }
   return placement;
 }
 // Edges currently on screen; attribute edges are added at apply() time, so the layout
 // has to read the live dataset instead of the edge list built at load time.
 function layoutAdjacency(){
   const adj=new Map(network.body.data.nodes.getIds().map(id=>[id,new Set()]));
   for(const edge of network.body.data.edges.get()){
     if(!adj.has(edge.from)||!adj.has(edge.to))continue;
     adj.get(edge.from).add(edge.to);adj.get(edge.to).add(edge.from);
   }
   return adj;
 }
 function radial(){
   // Deterministic spread for every size: hub-and-spoke rings per cluster, clusters packed side by side.
   const ids=network.body.data.nodes.getIds();
   if(!ids.length)return;
   const spacing=Math.max(110,Math.round(currentFont*9));
   const placement=spreadAll(ids,spacing,layoutAdjacency());
   network.setOptions({physics:{enabled:false}});
   network.body.data.nodes.update([...placement.entries()].map(([id,p])=>({id:id,x:p.x,y:p.y,physics:false})));
   network.fit({animation:false});
 }
 // Attribute values of the displayed entities; only drawn when the toolbar box is ticked.
 function attributeExtras(selected,size){
   const out={nodes:[],edges:[],info:new Map(),count:0};
   const toggle=document.getElementById('kg-attrs');
   if(!toggle||!toggle.checked)return out;
   const seen=new Set();
   for(const id of selected){
     for(const attr of (ATTRS[id]||[])){
       if(out.count>=ATTR_LIMIT)return out;
       const nodeId='ATTR::'+attr.id;
       if(seen.has(nodeId))continue;
       seen.add(nodeId);
       const details=fill(T.attr_node,[attr.t,attr.v,id]);
       out.nodes.push({id:nodeId,label:short(attr.v,24),
         title:esc(details).replace(/\n/g,'<br>'),
         shape:'box',
         color:{background:'#f4f6f8',border:'#b9c6cf',highlight:{background:'#e6eef5',border:'#7f9cb0'}},
         margin:6,borderWidth:1,widthConstraint:{minimum:24,maximum:150},
         font:{size:Math.max(9,size-5),face:'Microsoft YaHei, Arial',color:'#33475b'},
         kgDetails:details});
       out.edges.push({id:'display-attr-'+attr.id,from:id,to:nodeId,label:'',
         arrows:{to:{enabled:false}},color:'#b9c6cf',dashes:[2,4],width:1,
         font:{size:9,color:'#6b7f90'},kgKind:'attribute',kgDetails:details});
       out.info.set(nodeId,{kgDetails:details});
       out.count+=1;
     }
   }
   return out;
 }
 function apply(){
   root=nodeMap.has(focus.value)?focus.value:root;detail.style.display='none';
   const selected=subset(root,limit.value);
   const shown=selected.size;
   // Dense views use a smaller face so the layout can stay compact without overlaps.
   currentFont=shown>150?Math.min(fontSize,14):shown>60?Math.min(fontSize,16):fontSize;
   const ns=allNodes.filter(n=>selected.has(n.id)).map(n=>({...n,font:{...n.font,size:currentFont}}));
   const es=allEdges.filter(e=>selected.has(e.from)&&selected.has(e.to)).map(e=>({...e,font:{...e.font,size:Math.max(12,currentFont-3)}}));
   const extras=attributeExtras(selected,currentFont);
   const baseNodes=ns.length,baseEdges=es.length;
   for(const node of extras.nodes)ns.push(node);
   for(const edge of extras.edges)es.push(edge);
   attrInfo=extras.info;
   const token=++stabilizationToken;
   network.setData({nodes:new vis.DataSet(ns),edges:new vis.DataSet(es)});
   network.setOptions({physics:{enabled:true},nodes:{font:{size:currentFont}},edges:{font:{size:Math.max(12,currentFont-3)}}});
   status.textContent=fill(T.showing,[baseNodes,allNodes.length,baseEdges,allEdges.length]);
   if(extras.count){status.textContent+=fill(T.attributes,[extras.count]);}
   function finish(){
     if(token!==stabilizationToken)return;   // a newer apply() already owns the view
     radial();
     // Leave a margin so nodes on the circle are not clipped at the edge.
     if(network.body.data.nodes.length<=60){network.moveTo({scale:network.getScale()*0.9,animation:false});}
     network.selectNodes([root],false);
     status.textContent+=T.arranged_suffix;
   }
   if(ns.length>60){
     // Spread large views directly; waiting for the physics blob only wastes time.
     finish();
     return;
   }
   let done=false;
   function settle(){
     if(done||token!==stabilizationToken)return;done=true;
     network.setOptions({physics:{enabled:false}});
     finish();
   }
   network.once('stabilizationIterationsDone',settle);
   window.setTimeout(settle,1800);
 }
 limit.addEventListener('change',apply);
 document.getElementById('kg-refocus').addEventListener('click',apply);
 document.getElementById('kg-in').addEventListener('click',()=>network.moveTo({scale:Math.min(4,network.getScale()*1.25),animation:{duration:160}}));
 document.getElementById('kg-out').addEventListener('click',()=>network.moveTo({scale:Math.max(.18,network.getScale()/1.25),animation:{duration:160}}));
 document.getElementById('kg-fit').addEventListener('click',()=>network.fit({animation:{duration:200}}));
 document.getElementById('kg-readable').addEventListener('click',readableZoom);
 document.getElementById('kg-radial').addEventListener('click',function(){
   radial();status.textContent=T.arranged_status;
 });
 document.getElementById('kg-font').addEventListener('click',function(){
   fontSize=fontSize>=28?20:fontSize+4;this.textContent=fill(T.font,[fontSize]);
   currentFont=fontSize;
   network.body.data.nodes.update(network.body.data.nodes.get().map(n=>({id:n.id,font:{...n.font,size:currentFont}})));
   network.body.data.edges.update(network.body.data.edges.get().map(e=>({id:e.id,font:{...e.font,size:Math.max(12,currentFont-3)}})));
 });
 document.getElementById('kg-full').addEventListener('click',async()=>{
   try{if(document.fullscreenElement){await document.exitFullscreen();}else{await document.documentElement.requestFullscreen();}}
   catch(e){status.textContent+=T.fullscreen_denied;}
 });
 document.getElementById('kg-attrs').addEventListener('change',apply);
 network.on('click',p=>{
   if(p.nodes.length){
     const id=p.nodes[0],n=nodeMap.get(id)||attrInfo.get(id);
     if(!n){return;}
     if(nodeMap.has(id)){focus.value=String(id);}
     detail.textContent=n.kgDetails;detail.style.display='block';
     if(nodeMap.has(id)){const related=network.getConnectedNodes(id);network.selectNodes([id,...related],false);}
   }else if(p.edges.length){
     const e=allEdges.find(e=>e.id===p.edges[0]);detail.textContent=e?e.kgDetails:'';detail.style.display=e?'block':'none';
   }else{detail.style.display='none';}
 });
 network.on('doubleClick',p=>{if(p.nodes.length&&nodeMap.has(p.nodes[0])){focus.value=String(p.nodes[0]);apply();}});
 window.addEventListener('resize',()=>network.redraw());
 // Expose display state for diagnostics; no additional records are created.
 window.kgDisplayState=()=>({nodes:network.body.data.nodes.getIds(),edges:network.body.data.edges.getIds(),scale:network.getScale(),root:root});
 apply();
})();
'''


def wrap_label(value, width=12):
    """Wrap canvas labels without HTML; Latin breaks at word boundaries, CJK per character."""
    import textwrap
    text = str(value or '')
    lines=[]
    for paragraph in text.splitlines() or ['']:
        if not paragraph:
            lines.append('')
            continue
        if any('\u4e00' <= ch <= '\u9fff' for ch in paragraph):
            # CJK characters occupy approximately two Latin character widths.
            line='';units=0
            for ch in paragraph:
                size=2 if ord(ch)>255 else 1
                if units+size>width*2:
                    lines.append(line);line='';units=0
                line+=ch;units+=size
            if line:lines.append(line)
        else:
            wrapped=textwrap.wrap(paragraph,width=max(8,int(width*1.4)),
                                  break_long_words=True,break_on_hyphens=False)
            lines.extend(wrapped or [''])
    if len(lines)>5:lines=lines[:5];lines[-1]=lines[-1][:max(1,len(lines[-1])-1)]+'…'
    return '\n'.join(lines)


def toolbar_html(lang='zh'):
    return TOOLBAR_TEMPLATE.format(
        aria=t(lang, 'kg_toolbar_aria'),
        scope_label=t(lang, 'kg_scope_label'),
        scope_clear=t(lang, 'kg_scope_clear'),
        scope_extended=t(lang, 'kg_scope_extended'),
        scope_all=t(lang, 'kg_scope_all'),
        show_attrs=t(lang, 'kg_show_attrs'),
        center_label=t(lang, 'kg_center_label'),
        focus=t(lang, 'kg_focus'),
        zoom_in=t(lang, 'kg_zoom_in'),
        zoom_in_aria=t(lang, 'kg_zoom_in_aria'),
        zoom_out=t(lang, 'kg_zoom_out'),
        zoom_out_aria=t(lang, 'kg_zoom_out_aria'),
        fit=t(lang, 'kg_fit'),
        readable=t(lang, 'kg_readable'),
        radial=t(lang, 'kg_radial'),
        font=t(lang, 'kg_font', size=20),
        fullscreen=t(lang, 'kg_fullscreen'))


def script_for(lang='zh'):
    strings = {
        'showing': t(lang, 'kgjs_showing'),
        'attributes': t(lang, 'kgjs_attributes'),
        'attr_node': t(lang, 'kgjs_attr_node'),
        'arranged_suffix': t(lang, 'kgjs_arranged_suffix'),
        'arranged_status': t(lang, 'kgjs_arranged_status'),
        'font': t(lang, 'kgjs_font'),
        'fullscreen_denied': t(lang, 'kgjs_fullscreen_denied'),
    }
    return SCRIPT.replace('__TEXT__', json.dumps(strings, ensure_ascii=False))


def build_readable_document(view, height=820, lang='zh'):
    net=Network(height=f'{height}px',width='100%',directed=True,notebook=False,
                bgcolor='#ffffff',font_color='#152b3b',cdn_resources='in_line')
    for n in view.get('nodes',[]):
        kind=n.get('type','entity');raw=str(n.get('label',n['id']))
        color={'background':'#ADD8E6','border':'#79a9bb','highlight':{'background':'#8ac7df','border':'#1b6b92'}}
        if kind=='case':color={'background':'#e5ddf4','border':'#a793c5'}
        if kind=='transmission':color={'background':'#ffe2af','border':'#cd932e'}
        if kind=='rule':color={'background':'#e5ddf4','border':'#9276b8'}
        if kind=='rule_content':color={'background':'#f2ecf8','border':'#b19acb'}
        if n.get('resolution_status') in ('unresolved','ambiguous','conflict'):
            color={'background':'#e2e6e9','border':'#8a969e'}
        details='\n'.join(x for x in [raw,'ID: '+str(n['id']),str(n.get('subtitle','')),
            t(lang,'kg_identity',value=enum_text(lang,n.get('identity_status',''))) if n.get('identity_status') else '',
            t(lang,'kg_resolution',value=enum_text(lang,n.get('resolution_status',''))) if n.get('resolution_status') else '',
            t(lang,'kg_certainty',value=str(n.get('certainty',''))) if n.get('certainty') else '',
            t(lang,'kg_polarity',value=str(n.get('polarity',''))) if n.get('polarity') else ''] if x)
        net.add_node(n['id'],label=wrap_label(raw),title=html.escape(details).replace('\n','<br>'),
                     shape='circle',color=color,margin=18,borderWidth=1.7,
                     widthConstraint={'minimum':70,'maximum':180},
                     font={'size':20,'face':'Microsoft YaHei, Arial','color':'#142d3e'},
                     kgLabel=raw,kgDetails=details)
    for i,e in enumerate(view.get('edges',[])):
        kind=e.get('kind','relation');label=str(e.get('label',''))
        tr=kind.startswith('transmission');membership=kind=='case_membership'
        color='#9276b8' if kind=='rule_element' else '#cc8721' if tr else '#b4c1c8' if membership else '#4d829f'
        details='\n'.join([label,t(lang,'kg_record',value=str(e.get('id',''))),
                          str(e.get('details','')),
                          t(lang,'kg_edge_transmission') if tr else
                          t(lang,'kg_edge_membership') if membership else
                          t(lang,'kg_edge_rule') if kind=='rule_element' else t(lang,'kg_edge_literature')])
        net.add_edge(e['source'],e['target'],id='display-'+str(i),label=label,
                     arrows={'to':{'enabled':True,'scaleFactor':1.3}},
                     color=color,dashes=[7,5] if tr else [3,5] if membership else False,
                     width=2.4 if not membership else 1.1,
                     font={'size':17,'color':'#344e60','align':'middle','strokeWidth':5,'strokeColor':'#ffffff'},
                     title=html.escape(details).replace('\n','<br>'),kgKind=kind,kgDetails=details)
    net.set_options(json.dumps({
        'layout':{'randomSeed':41,'improvedLayout':True},
        'nodes':{'font':{'size':20,'face':'Microsoft YaHei, Arial','color':'#142d3e'},'shape':'circle','margin':18,'chosen':True},
        'edges':{'arrows':{'to':{'enabled':True,'scaleFactor':1.3}},
                 'font':{'size':17,'align':'middle','strokeWidth':5,'strokeColor':'#ffffff'},
                 'smooth':{'enabled':True,'type':'continuous','roundness':0.12},'selectionWidth':2},
        'physics':{'enabled':True,'solver':'forceAtlas2Based',
                   'forceAtlas2Based':{'gravitationalConstant':-110,'centralGravity':0.0015,
                                      'springLength':320,'springConstant':0.035,'damping':0.4,'avoidOverlap':1},
                   'stabilization':{'enabled':True,'iterations':420,'fit':False}},
        'interaction':{'hover':True,'tooltipDelay':150,'zoomView':True,'dragView':True,'dragNodes':True,
                       'hideEdgesOnDrag':False,'keyboard':False}
    },ensure_ascii=False))
    document=net.generate_html(notebook=False)
    # PyVis includes optional Bootstrap CDN resources even with inline vis assets.
    # The viewer uses no Bootstrap features; remove external dependencies for local use.
    document=re.sub(r'<script\b[^>]*\bsrc=["\']https?://[^>]*>\s*</script>','',document,flags=re.I)
    document=re.sub(r'<link\b[^>]*\bhref=["\']https?://[^>]*>','',document,flags=re.I)
    document=re.sub(r'<center>\s*<h1>\s*</h1>\s*</center>','',document,flags=re.I)
    document=document.replace('</head>','<style>'+CSS+'</style></head>')
    # Attribute type/value pairs travel with the page; they are drawn only on request.
    attributes=json.dumps(view.get('attributes',{}),ensure_ascii=False).replace('</','<\\/')
    document=re.sub(r'(<body[^>]*>)',lambda m:m.group(1)+'<script>window.KG_ATTRIBUTES='
                    +attributes+';</script>'+toolbar_html(lang),document,count=1)
    extras=('<div id="kg-detail" role="status"></div><div id="kg-hint">'
            + t(lang,'kg_hint') + '</div>')
    document=document.replace('</body>',extras+'<script>'+script_for(lang)+'</script></body>')
    return document


def render_readable(view,height=820,lang='zh'):
    return ('<iframe title="'+html.escape(t(lang,'kg_iframe_title'),quote=True)
            +'" sandbox="allow-scripts" allow="fullscreen" allowfullscreen '
            'referrerpolicy="no-referrer" style="width:100%;height:'+str(height)+'px;border:1px solid #cadbe6;border-radius:8px;background:#fff" srcdoc="'
            +html.escape(build_readable_document(view,height,lang),quote=True)+'"></iframe>')
