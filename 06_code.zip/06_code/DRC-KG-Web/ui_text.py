"""Interface text in Chinese and English.

Only interface wording lives here. Research data values (case titles, entity
names, rule text, ontology terms) are never translated: they are shown exactly
as recorded in the release files.
"""

# Each entry maps a message key to (Chinese, English).
TEXT = {
    # ---- page shell ------------------------------------------------------
    'app_title': ('# DRC-KG | 登革热研究案例知识图谱',
                  '# Dengue Research Case Knowledge Graph (DRC-KG)'),
    'mode_demo': ('虚构演示', 'Synthetic demonstration'),
    'mode_public': ('真实数据发布视图', 'Public data release view'),
    'mode_standardized': ('标准化表数据视图（内部候选）',
                          'Standardized-table view (internal candidate)'),
    'loaded_cases': ('已载入 {count} 篇案例。', '{count} cases loaded.'),
    'demo_notice': ('当前是两个虚构案例的演示模式；真实数据使用原 start_public.bat 启动。',
                    'This is the two-case synthetic demonstration; the real data is started '
                    'from start_public.bat.'),
    'language': ('语言', 'Language'),
    'lang_zh': ('中文', 'Chinese'),
    'lang_en': ('English', 'English'),
    # 页面顶部平台简介（两段）。
    'intro_lede': (
        '本交互式平台提供基于261篇中英文登革热研究案例论文构建的流行病学结构化知识及知识图谱可视化。'
        '数据集通过细粒度语义标注、本体驱动的知识组织与人工复核构建，涵盖疫情特征、流行病学调查、'
        '实验室检测、媒介监测、传播过程及防控措施等方面的知识。',
        'This interactive dashboard provides structured epidemiological knowledge and knowledge '
        'graph visualizations derived from 261 Chinese and English dengue research case papers. '
        'The dataset was constructed through fine-grained semantic annotation, ontology-based '
        'knowledge organization, and manual validation, capturing outbreak characteristics, '
        'epidemiological investigations, laboratory findings, vector surveillance, transmission '
        'dynamics, and prevention and control measures.'),
    'intro_method': (
        '知识图谱以实体、属性和语义关系为基础，重点表达传播关系的不确定性、支持证据及'
        '原始研究文献的可追溯性。平台支持用户探索具体研究案例、分析流行病学关联，'
        '并考察具有证据支持的传播路径。',
        'DRC-KG represents entities, attributes, and semantic relationships, with '
        'particular emphasis on transmission uncertainty, supporting evidence, and traceability '
        'to original research sources. The dashboard enables users to explore individual research '
        'cases, examine epidemiological relationships, and investigate evidence-supported '
        'transmission pathways.'),
    'case_picker': ('研究案例', 'Research case'),
    'entity_redacted_label': ('未命名（{kind}）{suffix}', 'unnamed ({kind}) {suffix}'),
    'graph_redacted_note': ('原始名称是长原文短语，按发布规则未公开。',
                            'The source name was withheld by the release rule for long verbatim '
                            'phrases.'),
    'tab_case': ('案例与图谱', 'Case and graph'),
    'tab_rules': ('规则', 'Rules'),
    'tab_evidence': ('证据', 'Evidence'),
    'tab_attributes': ('属性', 'Attributes'),
    'tab_checks': ('数据检查', 'Data checks'),
    'attr_filter': ('按归属实体筛选', 'Filter by owning entity'),
    'attr_all_owners': ('全部归属实体', 'All owning entities'),
    'attr_note': ('当前范围：{count} 条属性，归属 {owners} 个实体。属性以（归属实体，属性类型，属性值）'
                  '列出，不进入关系图谱；需要看图时可在图谱工具条勾选“显示属性”。',
                  'Current scope: {count} attribute(s) from {owners} owning entities. Attributes are '
                  'listed as (owning entity, attribute type, attribute value) and are not relation '
                  'edges; tick "Show attributes" in the graph toolbar to draw them.'),
    'attr_empty': ('本案例没有收录属性记录。', 'No attribute records are held for this case.'),
    'case_graph_note': (
        '普通关系、传播相关原始关系与规则要素共用此图。蓝色为实体，橙色为传播声明，紫色为规则。'
        '图中最多载入300条原始关系，另显示当前案例的全部非空规则要素；完整记录见下表。'
        '可用“中心节点”选择规则ID，再聚焦查看规则。',
        'Ordinary relations, transmission-related source relations and rule elements share this '
        'graph. Blue nodes are entities, orange nodes are transmission statements, purple nodes are '
        'rules. At most 300 source relations are drawn, plus every non-empty rule element of the '
        'current case; the tables below hold the complete records. Use "Center node" to pick a rule '
        'ID and focus on it.'),
    'triple_note': (
        '“传播声明摘要”保留原TR记录，不计作新增抽取三元组；规则结构采用（规则ID，规则要素，原始内容），'
        '保留条件归属，不自动推断新事实。未决记录也保留在表中。',
        '"Transmission statement summary" rows keep the original TR records and are not counted as '
        'newly extracted triples; rule structures are shown as (rule ID, rule element, original '
        'content), keep their condition assignment and do not infer new facts automatically. '
        'Undecided records stay in the table as well.'),
    'triple_scope': ('三元组展示范围', 'Triple display scope'),
    'triple_scope_local': ('精选（{shown} 条）', 'Selected ({shown} rows)'),
    'triple_scope_all': ('全部（{total} 条）', 'All rows ({total})'),
    'triple_local_note': (
        '默认只展开 {shown} / {total} 条最有代表性的三元组：传播声明全部保留，'
        '其余按两端实体的连接度排序；规则要素可切换到“全部”或在“规则”页查看。',
        'Only {shown} of {total} representative triples are shown by default: every transmission '
        'statement is kept and the remaining relations are ranked by the connectivity of their two '
        'endpoints. Switch to "All rows" — or open the Rules tab — for the complete records.'),
    'rules_note': (
        '每行按“规则ID—规则要素—规则内容”展示，与原始分类记录对应。'
        '仅对规则要素和原始内容均非空的行绘制结构边。'
        '原始缺失字段保持缺失，待拆规则保留原有规则ID，不重新划分。',
        'Each row is shown as "rule ID — rule element — rule content" and corresponds to the '
        'original classification records. Structural edges are drawn only when both the rule element '
        'and the original content are non-empty. Missing source fields stay missing, and rules '
        'awaiting splitting keep their original rule ID without being re-split.'),
    'evidence_note_public': ('证据区提供定位信息；规则正文取自公开数据集。',
                             'The evidence area provides locator information; rule text is taken '
                             'from the public dataset.'),
    'evidence_note_local': ('证据区提供定位信息；规则正文在本机读取第二步索引。',
                            'The evidence area provides locator information; rule text is read from '
                            'the local step-2 index.'),
    'rule_scope': ('规则显示范围', 'Rule scope'),
    'evidence_scope': ('证据查询范围', 'Evidence scope'),
    'scope_current': ('当前案例', 'Current case'),
    'scope_all': ('全部已加载案例', 'All loaded cases'),
    'trace_picker': ('选择关系、传播声明或规则记录',
                     'Select a relation, transmission statement or rule record'),
    'trace_button': ('追溯证据', 'Trace evidence'),
    'label_trace_result': ('原始记录与定位元数据', 'Raw record and locator metadata'),
    'label_diagnostics': ('已载入数据统计', 'Loaded data statistics'),
    'empty_trace_note': ('当前范围未选择可追溯的记录。',
                         'No traceable record is selected in the current scope.'),

    # ---- case summary ----------------------------------------------------
    'case_meta': ('**案例：** {case_id} · **语言：** {language}',
                  '**Case:** {case_id} · **Language:** {language}'),
    'counts': ('实体 {entities} · 原始关系 {relations} · 传播声明 {transmission} · 规则 {rules}',
               '**Entities** {entities} · **Source relations** {relations} · '
               '**Transmission statements** {transmission} · **Rules** {rules}'),
    'summary_note': ('表格提供完整记录。规则按原始要素结构展示；传播端点可解析不等于已确证。',
                     'The tables hold the complete records. Rules are shown in their original '
                     'element structure; a resolvable transmission endpoint is not a confirmed '
                     'transmission.'),

    # ---- table headers ---------------------------------------------------
    'hdr_rule_id': ('规则ID', 'Rule ID'),
    'hdr_rule_element': ('规则要素', 'Rule element'),
    'hdr_rule_content': ('规则内容', 'Rule content'),
    'hdr_attr_id': ('属性ID', 'Attribute ID'),
    'hdr_attr_owner': ('归属实体', 'Owning entity'),
    'hdr_attr_type': ('属性类型', 'Attribute type'),
    'hdr_attr_value': ('属性值', 'Attribute value'),
    'hdr_attr_status': ('归属状态', 'Owner status'),
    'hdr_head': ('头实体／规则ID', 'Head entity / rule ID'),
    'hdr_predicate': ('关系／规则要素', 'Relation / rule element'),
    'hdr_ontology': ('本体关系（当前语言）', 'Ontology relation (current language)'),
    'hdr_tail': ('尾实体／原始内容', 'Tail entity / original content'),
    'hdr_certainty': ('原始确定性', 'Original certainty'),
    'hdr_record': ('记录ID', 'Record ID'),
    'hdr_source_file': ('源文件', 'Source file'),
    'hdr_pdf_page': ('PDF页码', 'PDF page'),
    'hdr_section': ('章节', 'Section'),
    'hdr_excel_sheet': ('Excel表', 'Excel sheet'),
    'hdr_excel_row': ('Excel行', 'Excel row'),

    # ---- scope notes and fallbacks ---------------------------------------
    'scope_all_lower': ('全部已加载案例', 'all loaded cases'),
    'scope_current_lower': ('当前案例 {case}', 'current case {case}'),
    'scope_none': ('未选择', 'none selected'),
    'status_note': ('范围：{scope}；匹配 {matched} 条。全部已加载 {total} 条，当前案例 {local} 条。',
                    'Scope: {scope}; {matched} matching record(s). Total loaded {total}, '
                    'current case {local}.'),
    'no_table_records': (' 当前数据源没有此类记录；请在“数据检查”页确认是否仍为演示模式或数据未接入。',
                         ' The current data source has no records of this type; check the Data checks '
                         'tab to confirm whether demo mode is still active or the data is not loaded.'),
    'no_case_records': (' 当前案例没有此类记录。切换到“全部已加载案例”可以查看其他案例。',
                        ' The current case has no records of this type. Switch to "All loaded cases" '
                        'to view other cases.'),
    'no_keyword_match': (' 当前关键词没有匹配记录，请清空关键词。',
                         ' No record matches the current keyword; clear the keyword.'),
    'endpoint_missing': ('未标注端点（未决）', 'unlabelled endpoint (unresolved)'),
    'not_recorded': ('原表未记录', 'not recorded in the source table'),
    'not_stated': ('原表未注明', 'not stated in the source table'),
    'certainty_unstated': ('确定性未注明', 'certainty not stated'),
    'blank_raw': ('原始标注未填写', 'not filled in the original annotation'),
    'locator_no_text': ('定位版未提供原文', 'source text not provided in the locator-only view'),
    'source_no_text': ('原表未提供', 'not provided in the source table'),
    'rule_blank_note': (' 其中 {count} 条的条件和结论原文未在此视图提供；下表显示规则ID和元数据，'
                        '不推测补写。',
                        ' {count} of them have no condition or result text in this view; the table '
                        'below shows rule IDs and metadata without inferring missing text.'),

    # ---- evidence tracing ------------------------------------------------
    'msg_choose_type': ('请选择事实类型。', 'Select a fact type.'),
    'msg_not_found': ('指定类型和范围内未找到此ID；请核对ID或切换到全部已加载案例。',
                      'This ID was not found within the specified type and scope; check the ID or '
                      'switch to all loaded cases.'),
    'msg_ambiguous': ('此ID不唯一，需要核对源数据，未自动选取。',
                      'This ID is not unique, so the source data needs checking; no record was '
                      'selected automatically.'),
    'msg_cross_case': ('跨案例KU关联已隔离，需核对源数据。',
                       'A cross-case knowledge-unit link was quarantined; the source data needs '
                       'checking.'),
    'msg_no_evidence': ('事实记录存在，但当前视图没有可返回的证据关联；请检查evidence_references.csv。',
                        'The fact record exists, but this view has no evidence link to return; check '
                        'evidence_references.csv.'),
    'content_notice_blank': ('原始标注没有填写条件和结论。',
                             'The original annotation has no condition or result text.'),
    'content_notice_hidden': ('该规则的条件和结论原文未在当前视图提供；元数据和证据关联仍可查询。',
                              'The condition and result text of this rule is not provided in this '
                              'view; metadata and evidence links can still be queried.'),
    'trace_note': ('事实 {fact_id} 属于 {case_id}；找到 {count} 条证据关联。',
                   'Fact {fact_id} belongs to {case_id}; {count} evidence link(s) found.'),
    'untyped': ('未注明类型', 'untyped'),

    # ---- rule views ------------------------------------------------------
    'compact_empty': ('本案例没有收录规则记录。', 'No rule records are held for this case.'),
    'compact_note': ('本案例收录 {count} 条规则。', '{count} rule(s) recorded for this case.'),
    'compact_source': (' 正文对应本机第二步原始标注；未填字段保持未填。',
                       ' Text comes from the local step-2 raw annotation; empty fields stay empty.'),
    'compact_blank': (' 其中 {count} 条的条件和结论未提供，按原字段留示说明。',
                      ' {count} of them have no condition or result text and are shown as recorded.'),
    'tr_summary': ('传播声明摘要', 'Transmission statement summary'),
    'tr_relation': ('传播关系', 'Transmission relation'),
    'classified_note': ('当前范围：{rules} 条规则，{rows} 行规则要素。按分类表的原始行顺序展示，'
                        '内容不截断。',
                        'Current scope: {rules} rule(s), {rows} rule element row(s). Shown in the '
                        'original worksheet row order, content not truncated.'),
    'classified_empty': (' 本案例没有收录规则，可切换到全部案例。',
                         ' No rules are held for this case; switch to all cases.'),
    'classified_public': (' 规则正文取自公开数据集。', ' Rule text comes from the public dataset.'),
    'classified_locator': (' 当前只有定位版，规则正文未公开。',
                           ' Only the locator-only view is available; rule text is not published.'),

    # ---- graph view ------------------------------------------------------
    'graph_empty': ('本案例没有可绘制的关系。未决原始记录仍可在下方关系列表查看。',
                    'No drawable relations for this case. Unresolved raw records remain available in '
                    'the relation list below.'),
    'graph_transmission': ('传播声明', 'Transmission statement'),
    'graph_source': ('来源：{value}', 'Source: {value}'),
    'graph_target': ('目标：{value}', 'Target: {value}'),
    'graph_caveat': ('可解析不等于确证', 'resolvable does not mean confirmed'),
    'graph_unmapped': ('未映射', 'unmapped'),
    'graph_unlabelled': ('未标注', 'unlabelled'),
    'graph_edge_statement': ('原始关系陈述。原文谓词：{original}；本体关系：{ontology}',
                             'Source relation statement. Original predicate: {original}; '
                             'ontology relation: {ontology}'),
    'graph_edge_transmission': (' 关联传播声明：{tid}；原始确定性：{certainty}；'
                                '不据此补造缺失传播端点。',
                                ' Linked transmission statement: {tid}; original certainty: '
                                '{certainty}; missing transmission endpoints are not invented.'),
    'graph_rule_node': ('原始规则实例；规则要素结构不代表新增推断。',
                        'Original rule instance; the rule element structure does not represent a new '
                        'inference.'),
    'graph_rule_content': ('规则内容原文；类别：{category}',
                           'Original rule text; category: {category}'),
    'graph_rule_edge': ('原始分类表规则要素。规则ID：{rule_id}；源行：{row}',
                        'Rule element from the original classification table. Rule ID: {rule_id}; '
                        'source row: {row}'),

    # ---- knowledge graph toolbar and tooltips -----------------------------
    'kg_toolbar_aria': ('知识图谱显示控制', 'Knowledge graph display controls'),
    'kg_scope_label': ('显示范围', 'Display scope'),
    'kg_scope_clear': ('清晰局部 12节点', 'Clear local 12 nodes'),
    'kg_scope_extended': ('扩展局部 24节点', 'Extended local 24 nodes'),
    'kg_scope_all': ('全部已加载节点', 'All loaded nodes'),
    'kg_center_label': ('中心节点', 'Center node'),
    'kg_focus': ('聚焦选中节点', 'Focus selected node'),
    'kg_zoom_in': ('放大 +', 'Zoom in +'),
    'kg_zoom_in_aria': ('放大图谱', 'Zoom in on the graph'),
    'kg_zoom_out': ('缩小 −', 'Zoom out −'),
    'kg_zoom_out_aria': ('缩小图谱', 'Zoom out of the graph'),
    'kg_fit': ('适应画布', 'Fit canvas'),
    'kg_readable': ('清晰缩放', 'Readable zoom'),
    'kg_radial': ('散开排列', 'Spread layout'),
    'kg_font': ('字号 {size}', 'Font {size}'),
    'kg_fullscreen': ('全屏', 'Fullscreen'),
    'kg_show_attrs': ('显示属性', 'Show attributes'),
    'kgjs_attr_node': ('属性：%1 = %2；归属实体：%3',
                       'Attribute: %1 = %2; owning entity: %3'),
    'kg_hint': ('滚轮缩放 · 拖拽节点调整 · 单击查看完整文字与记录ID · 双击以该节点为中心 · '
                '虚线传播边保留原始不确定性',
                'Scroll to zoom · drag a node to adjust · click for the full text and record ID · '
                'double-click to centre on that node · dashed transmission edges keep the original '
                'uncertainty'),
    'kg_iframe_title': ('可交互知识图谱', 'Interactive knowledge graph'),
    'kg_identity': ('身份：{value}', 'Identity: {value}'),
    'kg_resolution': ('解析：{value}', 'Resolution: {value}'),
    'kg_certainty': ('确定性：{value}', 'Certainty: {value}'),
    'kg_polarity': ('肯否：{value}', 'Polarity: {value}'),
    'kg_record': ('记录ID: {value}', 'Record ID: {value}'),
    'kg_edge_transmission': ('传播陈述，端点可解析不等于传播确证。',
                             'Transmission statement; resolvable endpoints do not mean the '
                             'transmission is confirmed.'),
    'kg_edge_membership': ('案例归属关系', 'Case membership relation'),
    'kg_edge_rule': ('规则要素结构，保留原始规则归属。',
                     'Rule element structure that keeps the original rule assignment.'),
    'kg_edge_literature': ('文献陈述，保留原始事实与限定。',
                           'Literature statement that keeps the original fact and its qualifiers.'),
    'kgjs_showing': ('当前显示 %1 / %2 个已加载节点，%3 / %4 条边。原始记录保持不变。',
                     'Showing %1 of %2 loaded nodes and %3 of %4 edges. Source records are '
                     'unchanged.'),
    'kgjs_arranged_suffix': (' 已按径向散开排列。', ' Arranged radially.'),
    'kgjs_arranged_status': ('已按径向散开排列：中心节点居中，邻居铺在圆周上。',
                             'Arranged radially: the center node sits in the middle and neighbours '
                             'are placed around it.'),
    'kgjs_font': ('字号 %1', 'Font %1'),
    'kgjs_attributes': (' 另显示 %1 条属性节点。', ' Showing %1 attribute node(s).'),
    'kgjs_fullscreen_denied': (' 浏览器未允许全屏，可使用缩放和拖拽。',
                               ' The browser did not allow fullscreen; use zoom and drag instead.'),

    # ---- local rule source -----------------------------------------------
    'lr_demo': ('演示模式只显示虚构规则。', 'Demo mode shows fictional rules only.'),
    'lr_hosted': ('公开托管使用现有发布视图，不自动读取本机原始标注。',
                  'Hosted deployment uses the existing release view and does not read local raw '
                  'annotations.'),
    'lr_public_text': ('规则正文来自公开数据集（规则与规则要素字段）。',
                       'Rule text comes from the public dataset (rules and rule elements fields).'),
    'lr_version_fail': ('找到原始规则源，但未通过版本核对：{error}',
                        'An original rule source was found but failed the version check: {error}'),
    'lr_local_text': ('规则正文来自本机第二步原始标注，按稳定规则ID对应。',
                      'Rule text comes from the local step-2 raw annotation, matched by stable rule '
                      'ID.'),
    'lr_missing': ('尚未找到第二步原始规则索引，请将原第二步目录放回项目中，或设置'
                   'DRC_KG_LOCAL_RULE_INDEX。',
                   'The step-2 raw rule index was not found; put the original step-2 directory back '
                   'into the project or set DRC_KG_LOCAL_RULE_INDEX.'),
    'lr_err_duplicate_index': ('原始配套索引不唯一：{name}', 'Duplicate original companion index: {name}'),
    'lr_err_empty_id': ('配套索引ID为空或重复：{key}', 'Empty or duplicate companion index ID: {key}'),
    'lr_err_element_mismatch': ('原始规则要素与当前发布版本不一致。',
                                'Original rule elements do not match the current release.'),
    'lr_err_element_parent': ('规则要素的父规则关联不一致。',
                              'Rule element parent links are inconsistent.'),
    'lr_err_group': ('原始规则组与当前规则关联不一致。',
                     'Original rule groups do not match the current rules.'),
    'lr_err_case_missing': ('原始案例索引缺少规则案例。',
                            'The original case index lacks a rule case.'),
    'lr_err_zip_index': ('压缩包内没有唯一的第二步rule_index.csv。',
                         'The archive does not contain exactly one step-2 rule_index.csv.'),
    'lr_err_columns': ('源文件缺少原始规则正文列。',
                       'The source file lacks the raw rule text columns.'),
    'lr_err_rule_id': ('原始规则ID为空或重复。', 'Empty or duplicate original rule IDs.'),
    'lr_err_missing_rule': ('原始索引缺少对应规则ID。',
                            'The original index lacks a matching rule ID.'),
    'lr_err_version': ('规则版本关联不一致，需核对案例和来源。',
                       'Rule version links are inconsistent; check the cases and sources.'),
}

# Column order of each table, as message keys.
HEADER_KEYS = {
    'rule': ('hdr_rule_id', 'hdr_rule_element', 'hdr_rule_content'),
    'triple': ('hdr_head', 'hdr_predicate', 'hdr_ontology', 'hdr_tail',
               'hdr_certainty', 'hdr_record'),
    'attribute': ('hdr_attr_id', 'hdr_attr_owner', 'hdr_attr_type', 'hdr_attr_value',
                  'hdr_attr_status'),
    'evidence': ('hdr_evidence_id', 'hdr_case_id', 'hdr_ku_id', 'hdr_source_file',
                 'hdr_pdf_page', 'hdr_section', 'hdr_excel_sheet', 'hdr_excel_row'),
}

# 状态枚举值（数据里的英文原值）-> 界面显示。
# 发布表里的 candidate / unresolved / true … 是受控英文枚举，属于系统层文字：
# 中文界面必须翻译，英文界面保留原词，否则中文页面会夹着英文状态值。
ENUM = {
    'candidate': ('候选', 'candidate'),
    'resolved': ('已解析', 'resolved'),
    'resolved_unique': ('已唯一解析', 'resolved (unique)'),
    'unresolved': ('未解析', 'unresolved'),
    'ambiguous': ('歧义', 'ambiguous'),
    'conflict': ('冲突', 'conflict'),
    'true': ('是', 'true'),
    'false': ('否', 'false'),
}

# Identifiers keep their English spelling in both languages.
FIXED_HEADERS = {'hdr_evidence_id': 'Evidence ID', 'hdr_case_id': 'Case ID', 'hdr_ku_id': 'KU ID'}


def enum_text(lang, value):
    """Translate a controlled English status value for display; unknown values pass through."""
    if value is None:
        return ''
    zh, en = ENUM.get(str(value).strip().lower(), (str(value), str(value)))
    return en if str(lang).lower().startswith('en') else zh


def t(lang, key, **values):
    """Return one interface string in the requested language."""
    zh, en = TEXT[key]
    text = en if str(lang).lower().startswith('en') else zh
    return text.format(**values) if values else text


def headers(lang, table):
    """Column headers of a table in the requested language."""
    return [FIXED_HEADERS.get(key) or t(lang, key) for key in HEADER_KEYS[table]]
