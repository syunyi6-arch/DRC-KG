@echo off
setlocal
cd /d "%~dp0"
py -3.11 --version >nul 2>&1
if errorlevel 1 (
  echo Python 3.11 is required. Install it from https://www.python.org/downloads/
  pause
  exit /b 1
)
if not exist ".venv\Scripts\python.exe" (
  py -3.11 -m venv .venv
  if errorlevel 1 goto :fail
)
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto :fail
".venv\Scripts\python.exe" -m compileall -q app.py data_access.py demo_data.py graph_view.py release_check.py detail_views.py readable_graph.py local_rules.py ui_text.py scripts tests
if errorlevel 1 goto :fail
".venv\Scripts\python.exe" -m unittest discover -s tests -v
if errorlevel 1 goto :fail
echo Installation complete. Double-click start_demo.bat
pause
exit /b 0
:fail
echo Installation or checks failed. See the error above.
pause
exit /b 1
