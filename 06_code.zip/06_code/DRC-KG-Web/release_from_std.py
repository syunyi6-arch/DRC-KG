# -*- coding: utf-8 -*-
"""Release view for the Gradio app, built from DRC-KG/04_knowledge_graph/01_standardized_data.

The Gradio app was written against the "public_data" release view: 12 CSVs in a fixed
column layout plus an approval manifest (release_check.py). That release view no longer
matches the knowledge-graph tables, so this module rebuilds the very same *view* from
04_knowledge_graph/01_standardized_data, using the mapping documented in
06_code/DRC-KG-Web-HTML-JS/README.md. The app, its views and its graph code are unchanged.

Two properties are deliberate:

* nothing is invented. Identity resolution is only a **case-local literal match**, and it
  is published as endpoint_status / *_status = "candidate" (or "unresolved"), never as
  "resolved". Fields the standardized tables do not carry (source_section, certainty...)
  are emitted empty, and the interface renders them as "not stated".
* it is **not** an approved website release. `check_manifest()` therefore refuses the
  approval claims (release_ready / website_approved) that release_check.py demands; the
  app runs in "std" mode and says so on the page.
"""
from __future__ import annotations

import csv
import json
import unicodedata
from collections import defaultdict
from pathlib import Path

Z = Path(__file__).resolve().parents[2]
STD_DIR = Z / "04_knowledge_graph" / "01_standardized_data"
ONTO_CSV = Z / "03_ontology" / "ontology_term_map.csv"

# Column layout of each table, identical to the retired public_data release view.
COLUMNS = {
    "cases": ["case_id", "language", "title", "source_document_id", "source_file",
              "source_file_variants", "research_case_aliases", "n_01", "n_02", "n_03", "n_04",
              "n_05", "n_06", "n_07", "total_source_rows", "has_rules", "has_transmission",
              "workbook_sha256", "doi", "doi_status", "source_url", "anomaly_count"],
    "entities": ["entity_id", "case_id", "language", "entity_name", "entity_name_normalized",
                 "name_variants", "ontology_class", "ontology_class_id", "identity_status",
                 "identity_rule_version", "n_mentions", "source_tables", "external_case_reference",
                 "conflict_classes", "resolution_status"],
    "attributes": ["attribute_id", "case_id", "language", "owner_kind", "owner_id", "owner_raw",
                   "owner_status", "owner_identity_status", "attribute_type", "attribute_type_id",
                   "attribute_value", "value_language", "assertion_qualifiers", "ku_id", "kuc_id",
                   "evidence_id", "resolution_status", "source_document_id", "source_file",
                   "source_sheet", "source_row"],
    "relations": ["relation_id", "case_id", "language", "relation_layer", "head_kind", "head_id",
                  "head_raw", "head_identity_status", "relation_original", "ontology_relation",
                  "ontology_relation_id", "tail_kind", "tail_id", "tail_raw",
                  "tail_identity_status", "endpoint_status", "transmission_id",
                  "record_role_original", "ku_id", "kuc_id", "evidence_id", "resolution_status",
                  "source_document_id", "source_file", "source_sheet", "source_row"],
    "transmission": ["transmission_id", "case_id", "language", "source_id", "source_kind",
                     "source_raw", "source_status", "source_candidates", "target_id",
                     "target_kind", "target_raw", "target_status", "target_candidates",
                     "certainty_original", "association_nature", "assertion_polarity",
                     "qualifier_original", "evidence_status", "evidence_ids", "relation_ids",
                     "resolution_status", "graph_ready", "quality_flags"],
    "transmission_participants": ["transmission_id", "mention_id", "participant_record_key",
                                  "case_id", "language", "entity_id", "ontology_class",
                                  "entity_name", "role_original", "is_declaration_row",
                                  "source_sheet", "source_row", "ku_id",
                                  "mention_reference_status", "resolution_status"],
    "transmission_attributes": ["transmission_attribute_id", "transmission_id", "case_id",
                                "language", "attribute_label_zh", "attribute_label_en",
                                "attribute_value", "source_row"],
    "rules": ["rule_id", "rule_group_id", "case_id", "language", "title_block", "ku_id",
              "rule_split_status", "n_elements", "subject", "conditions", "result", "authority",
              "source_rows", "evidence_ids", "resolution_status"],
    "rule_elements": ["rule_element_id", "rule_id", "rule_group_id", "case_id", "language",
                      "element_order", "element_original", "element_category",
                      "content_original", "ku_id", "evidence_id", "source_row",
                      "resolution_status"],
    "rule_groups": ["rule_group_id", "case_id", "language", "title_block", "ku_id", "n_rows",
                    "n_rules", "split_status", "source_rows", "resolution_status"],
    "knowledge_units": ["ku_id", "kuc_id", "case_id", "language", "text_excerpt", "text_length",
                        "text_mode", "source_document_id", "source_page", "source_section",
                        "source_table", "location_method", "section_status", "source_sheets",
                        "source_rows", "n_occurrences", "identity_status", "resolution_status"],
    "knowledge_unit_clusters": ["kuc_id", "case_id", "language", "text_excerpt", "text_length",
                                "text_mode", "n_occurrences", "source_sheets", "ku_ids",
                                "section_status", "identity_status", "resolution_status"],
    "evidence_references": ["evidence_id", "case_id", "fact_type", "fact_id", "ku_id", "kuc_id",
                            "evidence_role", "source_document_id", "source_doi", "source_url",
                            "source_page", "source_section", "source_table", "source_file",
                            "source_sheet", "source_row", "text_excerpt", "text_length",
                            "text_mode", "resolution_status"],
}
ONTOLOGY_COLUMNS = ["term_kind", "source_row", "term_id", "uri", "label_zh", "label_en",
                    "label_aliases", "definition_en", "status"]


def norm(value):
    if value is None:
        return ""
    return unicodedata.normalize("NFKC", str(value)).strip()


def _read(path, columns):
    with open(path, encoding="utf-8-sig", newline="") as handle:
        return [{c: (row.get(c) or "") for c in columns} for row in csv.DictReader(handle)]


def _rows(path):
    with open(path, encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def _name_index(entities):
    """case-local raw-name -> entity_id, the class label breaking homonyms."""
    index = {}
    for row in entities:
        exact, loose = index.setdefault(row["case_id"], ({}, {}))
        key = (norm(row["entity_raw"]).lower(), norm(row["class_label_zh"]))
        exact.setdefault(key, row["entity_id"])
        loose.setdefault(norm(row["entity_raw"]).lower(), row["entity_id"])
    return index


def _resolve(index, case_id, raw, class_zh=""):
    exact, loose = index.get(case_id, ({}, {}))
    if class_zh and (norm(raw).lower(), norm(class_zh)) in exact:
        return exact[(norm(raw).lower(), norm(class_zh))]
    return loose.get(norm(raw).lower(), "")


def _first_source_file(case):
    try:
        files = json.loads(case.get("source_files") or "[]")
    except ValueError:
        files = []
    return files[0] if files else ""


def _release_version(std_dir):
    """Version of the standardized release, so the page never shows a stale number."""
    path = Path(std_dir) / "release_manifest.json"
    if not path.is_file():
        return ""
    try:
        return str(json.loads(path.read_text(encoding="utf-8")).get("version", ""))
    except ValueError:
        return ""


def build(std_dir=None):
    """Return (tables, manifest) shaped like the retired public_data release view."""
    std_dir = Path(std_dir or STD_DIR)
    raw = {name: _rows(std_dir / (name + ".csv")) for name in COLUMNS}
    onto = _rows(ONTO_CSV) if ONTO_CSV.is_file() else []

    index = _name_index(raw["entities"])
    ku_cluster = {row["ku_id"]: row["cluster_id"] for row in raw["knowledge_units"]}
    ku_table = {}
    for row in raw["knowledge_units"]:
        try:
            sheets = json.loads(row["source_sheets"] or "[]")
        except ValueError:
            sheets = []
        ku_table[row["ku_id"]] = sheets[0] if sheets else ""

    evidence_by_fact = defaultdict(list)
    for row in raw["evidence_references"]:
        evidence_by_fact[(row["fact_type"], row["fact_id"])].append(row)
    # 05/06/07 的证据行没有 clue 之外的定位信息，但 (案例, 表号, 行号) 能唯一定位回标注行。
    evidence_by_location = {}
    for row in raw["evidence_references"]:
        evidence_by_location[(row["case_id"], row["source_sheet"], row["source_row"])] = row

    def first_evidence(fact_type, fact_id):
        found = evidence_by_fact.get((fact_type, fact_id)) or []
        return found[0] if found else {}

    source_file_of = {row["case_id"]: _first_source_file(row) for row in raw["cases"]}

    tr_head, tr_tail = {}, {}
    for row in raw["transmission_participants"]:
        role = row["role_raw"] or ""
        tr_id = row["transmission_id"]
        if "头实体" in role:
            tr_head.setdefault(tr_id, row)
        elif "尾实体" in role:
            tr_tail.setdefault(tr_id, row)

    def blank(name, **values):
        return {column: values.get(column, "") for column in COLUMNS[name]}

    tables = {name: [] for name in COLUMNS}

    for case in raw["cases"]:
        try:
            variants = json.loads(case.get("source_files") or "[]")
        except ValueError:
            variants = []
        row = blank("cases", **{k: case.get(k, "") for k in (
            "case_id", "language", "title", "n_01", "n_02", "n_03", "n_04", "n_05", "n_06",
            "n_07", "total_source_rows", "has_rules", "has_transmission")})
        row["source_file"] = variants[0] if variants else ""
        row["source_file_variants"] = json.dumps(variants, ensure_ascii=False)
        row["anomaly_count"] = "0"
        tables["cases"].append(row)

    for entity in raw["entities"]:
        tables["entities"].append(blank("entities", **{
            "entity_id": entity["entity_id"], "case_id": entity["case_id"],
            "language": entity["language"], "entity_name": entity["entity_raw"],
            "entity_name_normalized": norm(entity["entity_raw"]),
            "name_variants": "[]",
            "ontology_class": entity["class_label_en"],
            "ontology_class_id": entity["class_id"],
            "identity_status": entity["identity_status"],
            "n_mentions": entity["n_mentions"],
            "source_tables": entity["source_sheet"],
        }))

    for attribute in raw["attributes"]:
        case_id = attribute["case_id"]
        owner_id = _resolve(index, case_id, attribute["owner_entity_raw"],
                            attribute["class_label_zh"])
        evidence = first_evidence("attribute", attribute["attribute_id"])
        tables["attributes"].append(blank("attributes", **{
            "attribute_id": attribute["attribute_id"], "case_id": case_id,
            "language": attribute["language"], "owner_kind": "entity",
            "owner_id": owner_id, "owner_raw": attribute["owner_entity_raw"],
            "owner_status": "candidate" if owner_id else "",
            "owner_identity_status": "candidate",
            "attribute_type": attribute["attribute_label_en"],
            "attribute_type_id": attribute["attribute_id_ont"],
            "attribute_value": attribute["attribute_value"],
            "value_language": attribute["value_language"],
            "ku_id": evidence.get("ku_id", ""),
            "kuc_id": ku_cluster.get(evidence.get("ku_id", ""), ""),
            "evidence_id": evidence.get("evidence_id", ""),
            "source_document_id": "", "source_file": attribute["source_file"],
            "source_sheet": attribute["source_sheet"], "source_row": attribute["source_row"],
        }))

    for relation in raw["relations"]:
        case_id = relation["case_id"]
        head_id = _resolve(index, case_id, relation["head_value"], relation["head_class_zh"])
        tail_id = _resolve(index, case_id, relation["tail_value"], relation["tail_class_zh"])
        evidence = first_evidence("relation", relation["relation_id"])
        tables["relations"].append(blank("relations", **{
            "relation_id": relation["relation_id"], "case_id": case_id,
            "language": relation["language"], "relation_layer": "plain",
            "head_kind": "entity", "head_id": head_id, "head_raw": relation["head_value"],
            "head_identity_status": "candidate",
            "relation_original": relation["relation_raw"],
            "ontology_relation": relation["ontology_relation_en"],
            "ontology_relation_id": relation["ontology_relation_id"],
            "tail_kind": "entity", "tail_id": tail_id, "tail_raw": relation["tail_value"],
            "tail_identity_status": "candidate",
            "endpoint_status": "candidate" if (head_id and tail_id) else "unresolved",
            "transmission_id": "",
            "ku_id": evidence.get("ku_id", ""),
            "kuc_id": ku_cluster.get(evidence.get("ku_id", ""), ""),
            "evidence_id": evidence.get("evidence_id", ""),
            "source_document_id": "", "source_file": relation["source_file"],
            "source_sheet": relation["source_sheet"], "source_row": relation["source_row"],
        }))

    for transmission in raw["transmission"]:
        case_id = transmission["case_id"]
        head = tr_head.get(transmission["transmission_id"], {})
        tail = tr_tail.get(transmission["transmission_id"], {})
        source_id = _resolve(index, case_id, head.get("entity_value", ""),
                             head.get("class_label_zh", "")) if head else ""
        target_id = _resolve(index, case_id, tail.get("entity_value", ""),
                             tail.get("class_label_zh", "")) if tail else ""
        evidence_ids = [row["evidence_id"] for row in
                        evidence_by_fact.get(("transmission", transmission["transmission_id"]), [])]
        tables["transmission"].append(blank("transmission", **{
            "transmission_id": transmission["transmission_id"], "case_id": case_id,
            "language": transmission["language"],
            "source_id": source_id, "source_kind": "entity",
            "source_raw": transmission["head_participant"],
            "source_status": "candidate" if source_id else "",
            "source_candidates": "[]",
            "target_id": target_id, "target_kind": "entity",
            "target_raw": transmission["tail_participant"],
            "target_status": "candidate" if target_id else "",
            "target_candidates": "[]",
            "evidence_ids": json.dumps(evidence_ids, ensure_ascii=False),
            "graph_ready": transmission["graph_ready"],
        }))

    for participant in raw["transmission_participants"]:
        case_id = participant["case_id"]
        tables["transmission_participants"].append(blank("transmission_participants", **{
            "transmission_id": participant["transmission_id"], "case_id": case_id,
            "language": participant["language"],
            "entity_id": _resolve(index, case_id, participant["entity_value"],
                                 participant["class_label_zh"]),
            "ontology_class": participant["class_label_en"],
            "entity_name": participant["entity_value"],
            "role_original": participant["role_raw"],
            "source_sheet": "05", "source_row": participant["source_row"],
            "ku_id": evidence_by_location.get((case_id, "05", participant["source_row"]), {})
            .get("ku_id", ""),
        }))

    for record in raw["transmission_attributes"]:
        tables["transmission_attributes"].append(blank("transmission_attributes", **{
            "transmission_attribute_id": record["transmission_attribute_id"],
            "transmission_id": record["transmission_id"], "case_id": record["case_id"],
            "language": record["language"],
            "attribute_label_zh": record["attribute_label_zh"],
            "attribute_label_en": record["attribute_label_en"],
            "attribute_value": record["attribute_value"], "source_row": record["source_row"],
        }))

    for group in raw["rule_groups"]:
        tables["rule_groups"].append(blank("rule_groups", **{
            "rule_group_id": group["rule_group_id"], "case_id": group["case_id"],
            "language": group["language"], "title_block": group["title_block"],
            "n_rules": group["n_rules"],
        }))

    element_evidence = defaultdict(list)
    for element in raw["rule_elements"]:
        evidence = first_evidence("rule_element", element["rule_element_id"])
        element_evidence[element["rule_id"]].append(evidence.get("evidence_id", ""))
        tables["rule_elements"].append(blank("rule_elements", **{
            "rule_element_id": element["rule_element_id"], "rule_id": element["rule_id"],
            "rule_group_id": element["rule_group_id"], "case_id": element["case_id"],
            "language": element["language"], "element_order": element["element_order"],
            "element_original": element["element_raw"],
            "element_category": element["element_category"],
            "content_original": element["content"], "ku_id": element["ku_id"],
            "evidence_id": evidence.get("evidence_id", ""),
            "source_row": element["source_row"],
        }))

    for rule in raw["rules"]:
        tables["rules"].append(blank("rules", **{
            "rule_id": rule["rule_id"], "rule_group_id": rule["rule_group_id"],
            "case_id": rule["case_id"], "language": rule["language"],
            "title_block": rule["title_block"], "ku_id": rule["ku_id"],
            "rule_split_status": rule["split_status"], "n_elements": rule["n_elements"],
            "subject": rule["subject"], "conditions": rule["conditions"],
            "result": rule["result"], "authority": rule["authority"],
            "source_rows": rule["source_rows"],
            "evidence_ids": json.dumps([e for e in element_evidence.get(rule["rule_id"], []) if e],
                                       ensure_ascii=False),
        }))

    for ku in raw["knowledge_units"]:
        tables["knowledge_units"].append(blank("knowledge_units", **{
            "ku_id": ku["ku_id"], "kuc_id": ku["cluster_id"], "case_id": ku["case_id"],
            "language": ku["language"], "text_length": ku["text_length"],
            "text_mode": ku["text_mode"], "source_table": ku_table.get(ku["ku_id"], ""),
            "location_method": "annotation_table",
            "source_sheets": ku["source_sheets"], "source_rows": ku["source_rows"],
            "n_occurrences": ku["n_occurrences"],
        }))

    for cluster in raw["knowledge_unit_clusters"]:
        tables["knowledge_unit_clusters"].append(blank("knowledge_unit_clusters", **{
            "kuc_id": cluster["cluster_id"], "text_length": cluster["text_length"],
            "text_mode": "locator_only", "n_occurrences": cluster["n_knowledge_units"],
        }))

    for evidence in raw["evidence_references"]:
        tables["evidence_references"].append(blank("evidence_references", **{
            "evidence_id": evidence["evidence_id"], "case_id": evidence["case_id"],
            "fact_type": evidence["fact_type"], "fact_id": evidence["fact_id"],
            "ku_id": evidence["ku_id"], "kuc_id": ku_cluster.get(evidence["ku_id"], ""),
            "evidence_role": evidence["evidence_role"],
            "source_table": evidence["source_sheet"],
            "source_file": evidence["source_file"],
            "source_sheet": evidence["source_sheet"], "source_row": evidence["source_row"],
            "text_mode": "locator_only",
        }))

    tables["ontology_term_map"] = [dict(row) for row in onto]

    manifest = {
        "version": _release_version(std_dir),
        "mode": "locator_only",
        "source": "04_knowledge_graph/01_standardized_data (release_manifest.json)",
        "cases": len(tables["cases"]),
        "counts": {name: len(rows) for name, rows in tables.items()},
        # The standardized tables publish rule element text under project decision D7.
        "rule_text_publication": "full",
        # Deliberately NOT an approved website release: see module docstring.
        "release_ready": False,
        "website_approved": False,
        "approval_note": "内部候选数据（04 标准化表），未走 05 授权发布流程；不可当作已批准的公开站点数据",
        "identity_note": "实体只做案例内字面匹配，endpoint_status/status 一律为 candidate，不做跨文献消歧",
        "empty_fields": ["source_section", "source_page", "certainty_original",
                         "association_nature", "assertion_polarity", "resolution_status"],
    }
    return tables, manifest
