"""One graph for ordinary and transmission-related source relations."""
from readable_graph import render_readable
from ui_text import t


def graph_edges(store, case_id, max_edges=300):
    local_entities = {key for key, row in store.entities.items() if row.get('case_id') == case_id}
    local_tr = {row.get('transmission_id') for row in store.rows('transmission', case_id)}
    ordinary, transmission = [], []
    def local(kind, record_id):
        return ((kind == 'entity' and record_id in local_entities)
                or (kind == 'transmission' and record_id in local_tr)
                or (kind == 'case' and record_id == case_id))
    for row in store.rows('relations', case_id):
        head, tail = row.get('head_id', ''), row.get('tail_id', '')
        # 'candidate'：两端按同案例内的字面名称匹配到实体，是本数据能给出的最强状态
        # （标准化表明确不做跨文献实体消歧，因此不存在 resolved）。
        if (row.get('endpoint_status', '').lower() not in ('resolved', 'resolved_unique', 'candidate')
            or not local(row.get('head_kind'), head) or not local(row.get('tail_kind'), tail)):
            continue
        is_tr = row.get('transmission_id') in local_tr or row.get('relation_layer') == 'transmission'
        item = (head, tail, row, is_tr)
        (transmission if is_tr else ordinary).append(item)
    # Reserve graph room for transmission-related source rows without inventing edges.
    return (transmission + ordinary)[:max(0, int(max_edges))]


def graph_for_case(store, case_id, lang='zh', max_edges=300, rule_triples=None):
    edges = graph_edges(store, case_id, max_edges)
    tr_by_id = {r.get('transmission_id'): r for r in store.rows('transmission', case_id)}
    ids = {node_id for head, tail, _, _ in edges for node_id in (head, tail)} | set(tr_by_id)
    if not ids and not rule_triples:
        return '<div style="padding:40px">' + t(lang, 'graph_empty') + '</div>'
    view = {'nodes': [], 'edges': []}
    unlabelled = t(lang, 'not_stated')
    for node_id in sorted(ids):
        if node_id in tr_by_id:
            r = tr_by_id[node_id]
            source = r.get('source_raw') or r.get('source_id') or t(lang, 'graph_unlabelled')
            target = r.get('target_raw') or r.get('target_id') or t(lang, 'graph_unlabelled')
            view['nodes'].append({'id': node_id,
                'label': t(lang, 'graph_transmission') + '\n'
                         + (r.get('certainty_original') or t(lang, 'certainty_unstated')),
                'type': 'transmission',
                'subtitle': (t(lang, 'graph_source', value=source)
                             + '\n' + t(lang, 'graph_target', value=target)
                             + '\n' + t(lang, 'graph_caveat')),
                'certainty': r.get('certainty_original', ''),
                'polarity': r.get('assertion_polarity', ''),
                'resolution_status': r.get('resolution_status', '')})
        elif node_id == case_id:
            view['nodes'].append({'id': node_id, 'label': case_id, 'type': 'case'})
        else:
            r = store.entities[node_id]
            # Node labels are the raw entity names; when the release withheld a name, a
            # derived label from the public ontology class is used instead.
            subtitle = store.label(r.get('ontology_class', ''), lang)
            if store.name_is_redacted(r):
                subtitle = (subtitle + '\n' if subtitle else '') + t(lang, 'graph_redacted_note')
            view['nodes'].append({'id': node_id, 'label': store.entity_label(r, lang),
                'type': 'entity', 'subtitle': subtitle,
                'identity_status': r.get('identity_status', ''), 'resolution_status': r.get('resolution_status', '')})
    for head, tail, row, is_tr in edges:
        tr = tr_by_id.get(row.get('transmission_id'), {})
        ontology = store.label(row.get('ontology_relation', ''), lang)
        original = row.get('relation_original', '')
        details = t(lang, 'graph_edge_statement', original=original or '-',
                    ontology=ontology or t(lang, 'graph_unmapped'))
        if is_tr:
            details += t(lang, 'graph_edge_transmission',
                         tid=str(row.get('transmission_id', '')),
                         certainty=(tr.get('certainty_original') or unlabelled))
        view['edges'].append({'source': head, 'target': tail,
            'label': ontology or row.get('relation_original', ''),
            'kind': 'transmission_statement' if is_tr else 'relation', 'id': row.get('relation_id', ''),
            'details': details})
    # Each displayed rule element is a structural edge, never a derived clinical fact.
    added_rules = set()
    for item in rule_triples or []:
        if item.get('case_id') != case_id or not item.get('content'):
            continue
        rid = item['rule_id']
        if rid not in added_rules:
            view['nodes'].append({'id': rid, 'label': rid, 'type': 'rule',
                'subtitle': t(lang, 'graph_rule_node')})
            added_rules.add(rid)
        value_id = 'RULE-VALUE::' + item['element_id']
        view['nodes'].append({'id': value_id, 'label': item['content'], 'type': 'rule_content',
            'subtitle': t(lang, 'graph_rule_content', category=item.get('category', ''))})
        view['edges'].append({'source': rid, 'target': value_id, 'label': item['predicate'],
            'kind': 'rule_element', 'id': item['element_id'],
            'details': t(lang, 'graph_rule_edge', rule_id=rid, row=item.get('source_row', ''))})
    # Attribute values are drawn only when the viewer ticks "Show attributes"; the map
    # keeps type/value pairs per owning entity so the page never scans the whole table.
    attributes = {}
    for row in store.rows('attributes', case_id):
        owner = row.get('owner_id') or ''
        value = (row.get('attribute_value') or '').strip()
        if not owner or not value:
            continue
        attributes.setdefault(owner, []).append({
            'id': row.get('attribute_id', ''),
            't': row.get('attribute_type', ''),
            'v': value,
        })
    view['attributes'] = attributes
    return render_readable(view, lang=lang)
