# -*- coding: utf-8 -*-
"""Verify the Gradio app data layer against the standardized tables (std mode).

Run with the app's virtualenv python:  .venv\\Scripts\\python.exe _check_std.py
"""
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from release_from_std import build                      # noqa: E402
from data_access import DataStore                       # noqa: E402
from detail_views import Explorer                       # noqa: E402
from graph_view import graph_for_case                   # noqa: E402
from local_rules import LocalRuleSource                 # noqa: E402

tables, manifest = build()
print('tables        :', {k: len(v) for k, v in tables.items() if k != 'ontology_term_map'})
print('manifest      :', manifest['version'], '| rule_text:', manifest['rule_text_publication'],
      '| approved:', manifest['website_approved'])

store = DataStore(tables)
print('cases         :', len(store.cases), '| entities:', len(store.entities), '| terms:', len(store.terms))

rule_source = LocalRuleSource(HERE, tables.get('rules', []), 'std', tables.get('rule_elements', []))
explorer = Explorer(store, 'locator_only', rule_source.records, rule_source,
                    allow_public_rule_text=True)

case = 'CN-011'
print('case title    :', store.cases[case]['title'])
print('local rows    :', {t: len(store.rows(t, case)) for t in
                         ('entities', 'relations', 'attributes', 'transmission', 'rules')})

note, rows = explorer.transmission_view('case', case)
print('transmission  :', len(rows), 'rows |', note[:60])
print('   sample     :', rows[0] if rows else None)

note, rows = explorer.rule_view('case', case)
print('rules         :', len(rows), 'rows')

attr_rows = explorer.attribute_rows(case, 'zh')
attr_note = explorer.attribute_summary(case)
print('attributes    :', len(attr_rows), 'rows |', str(attr_note)[:60])
print('   owners     :', len(explorer.attribute_owners(case)))
print('   sample     :', attr_rows[:2])

relation_id = next((r['relation_id'] for r in store.rows('relations', case)), '')
result = explorer.trace('relation', relation_id, 'case', case)
print('trace relation:', relation_id, '->', result.get('status'), 'evidence:', len(result.get('evidence', [])))

tr_id = next((r['transmission_id'] for r in store.rows('transmission', case)), '')
result = explorer.trace('transmission', tr_id, 'case', case)
print('trace trans.  :', tr_id, '->', result.get('status'), 'evidence:', len(result.get('evidence', [])))

rule = next((r for r in store.rows('rules', case)), None)
if rule:
    result = explorer.trace('rule', rule['rule_id'], 'case', case)
    print('trace rule    :', rule['rule_id'], '->', result.get('status'),
          'evidence:', len(result.get('evidence', [])), '| elements:', len(result.get('rule_elements', [])))

html = graph_for_case(store, case, 'zh', 300, [])
print('graph html    :', len(html), 'bytes | has edge data:', 'edges' in html)
empty = [cid for cid in list(store.cases)[:40]
         if store.rows('relations', cid) and len(graph_for_case(store, cid, 'en', 300, [])) < 2000]
print('empty graphs  :', len(empty), empty[:5])

ep = {}
for row in tables['relations']:
    ep[row['endpoint_status']] = ep.get(row['endpoint_status'], 0) + 1
print('endpoint stat :', ep)
print('OK')
