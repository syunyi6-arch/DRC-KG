"""Read original rule text locally without rewriting the release CSV files."""
import csv
import io
import os
from pathlib import Path
from zipfile import ZipFile

from ui_text import t

RAW_FIELDS = {'subject_raw', 'conditions_raw', 'result_raw', 'authority_raw'}


class RuleSourceError(ValueError):
    """A version check failed; the wording is resolved per interface language."""

    def __init__(self, key, **values):
        super().__init__(key)
        self.key = key
        self.values = values


class LocalRuleSource:
    def __init__(self, root, published_rules, mode, published_elements=None):
        self.records = {}
        self.elements = {}
        self.groups = {}
        self.cases = {}
        self.path = None
        self.message_key = None
        self.message_values = {}
        if mode != 'public':
            self.message_key = 'lr_demo'
            return
        if os.getenv('SPACE_ID') or os.getenv('HF_SPACE_ID'):
            self.message_key = 'lr_hosted'
            return
        if any((row.get('subject') or row.get('conditions') or row.get('result') or row.get('authority'))
               for row in published_rules):
            self.message_key = 'lr_public_text'
            return
        root = Path(root).resolve()
        configured = os.getenv('DENGEKG_LOCAL_RULE_INDEX', '').strip()
        candidates = [Path(configured).expanduser()] if configured else []
        if not configured:
            candidates.append(root / 'local_rules' / 'rule_index.csv')
            for base in [root, *list(root.parents)[:3]]:
                candidates.append(base / '2.数据集构建' / '01_映射与索引' / 'rule_index.csv')
                candidates.append(base / '2.数据集构建.zip')
        for path in candidates:
            if not path.is_file():
                continue
            try:
                rows = self.read(path)
                records = self.validate(rows, published_rules)
                elements, groups, cases = self.companions(path, records, published_elements)
            except Exception as error:
                self.message_key = 'lr_version_fail'
                self.message_values = {'error': error}
                if configured:
                    return
                continue
            self.records = records
            self.elements, self.groups, self.cases = elements, groups, cases
            self.path = path.resolve()
            self.message_key = 'lr_local_text'
            return
        if self.message_key is None:
            self.message_key = 'lr_missing'

    def message(self, lang='zh'):
        """Explain where rule text comes from, in the requested language."""
        values = dict(self.message_values)
        if 'error' in values:
            values['error'] = self.reason(lang)
        return t(lang, self.message_key or 'lr_missing', **values)

    def reason(self, lang='zh'):
        error = self.message_values.get('error')
        if isinstance(error, RuleSourceError):
            return t(lang, error.key, **error.values)
        return str(error)

    @staticmethod
    def companions(path, records, published_elements):
        """Read the original classified rows; never reconstruct them by splitting text."""
        def read_csv(name):
            if path.suffix.lower() == '.zip':
                with ZipFile(path) as archive:
                    members = [n for n in archive.namelist() if n.replace('\\', '/').endswith('/01_映射与索引/' + name)]
                    if not members:
                        return []
                    if len(members) != 1:
                        raise RuleSourceError('lr_err_duplicate_index', name=name)
                    value = archive.read(members[0]).decode('utf-8-sig')
            else:
                companion = path.parent / name
                if not companion.is_file():
                    return []
                value = companion.read_text(encoding='utf-8-sig')
            return list(csv.DictReader(io.StringIO(value)))
        def index(rows, key):
            out = {}
            for row in rows:
                ident = row.get(key)
                if not ident or ident in out:
                    raise RuleSourceError('lr_err_empty_id', key=key)
                out[ident] = row
            return out
        elements = index(read_csv('rule_elements.csv'), 'rule_element_id')
        groups = index(read_csv('rule_group_index.csv'), 'rule_group_id')
        cases = index(read_csv('case_registry.csv'), 'case_id')
        if elements:
            for published in published_elements or []:
                source = elements.get(published.get('rule_element_id'))
                if not source or any(str(published.get(k, '')) != str(source.get(k, ''))
                                     for k in ('case_id','rule_id','rule_group_id','ku_id','element_order','source_row')):
                    raise RuleSourceError('lr_err_element_mismatch')
            for row in elements.values():
                parent = records.get(row.get('rule_id'))
                if parent and any(row.get(k, '') != parent.get(k, '') for k in ('case_id','rule_group_id','ku_id')):
                    raise RuleSourceError('lr_err_element_parent')
        for row in records.values():
            if groups:
                group = groups.get(row.get('rule_group_id'))
                if not group or any(group.get(k, '') != row.get(k, '') for k in ('case_id','ku_id')):
                    raise RuleSourceError('lr_err_group')
            if cases and row.get('case_id') not in cases:
                raise RuleSourceError('lr_err_case_missing')
        return elements, groups, cases

    @staticmethod
    def read(path):
        if path.suffix.lower() == '.zip':
            with ZipFile(path) as archive:
                members = [n for n in archive.namelist()
                           if n.replace('\\', '/').endswith('/01_映射与索引/rule_index.csv')]
                if len(members) != 1:
                    raise RuleSourceError('lr_err_zip_index')
                text = archive.read(members[0]).decode('utf-8-sig')
        else:
            text = path.read_text(encoding='utf-8-sig')
        reader = csv.DictReader(io.StringIO(text))
        if not RAW_FIELDS.issubset(set(reader.fieldnames or [])):
            raise RuleSourceError('lr_err_columns')
        return list(reader)

    @staticmethod
    def validate(rows, published_rules):
        grouped = {}
        for row in rows:
            key = row.get('rule_id')
            if not key or key in grouped:
                raise RuleSourceError('lr_err_rule_id')
            grouped[key] = row
        records = {}
        for published in published_rules:
            key = published.get('rule_id')
            source = grouped.get(key)
            if source is None:
                raise RuleSourceError('lr_err_missing_rule')
            for field in ('case_id', 'rule_group_id', 'ku_id', 'n_elements'):
                if str(published.get(field, '')) != str(source.get(field, '')):
                    raise RuleSourceError('lr_err_version')
            records[key] = source
        return records
