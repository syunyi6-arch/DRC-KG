"""Case explorer with rule triples and a combined relation graph."""
import html
import os
from pathlib import Path

import gradio as gr

from data_access import DataStore
from demo_data import make_demo
from detail_views import Explorer, FACTS
from graph_view import graph_for_case
from local_rules import LocalRuleSource
from release_check import check_public_release
from ui_text import headers, t

ROOT = Path(__file__).resolve().parent
MODE = os.getenv('DENGEKG_MODE', 'demo').strip().lower()
if MODE == 'demo':
    tables = make_demo()
    manifest = {}
elif MODE == 'public':
    tables, manifest = check_public_release(ROOT / 'public_data')
elif MODE == 'std':
    # 直接读 04_knowledge_graph/01_standardized_data：内部候选数据，不冒充已批准的发布视图
    from release_from_std import build as build_from_std
    tables, manifest = build_from_std(os.getenv('DRC_KG_STD') or None)
else:
    raise RuntimeError('DENGEKG_MODE must be demo, public or std.')
store = DataStore(tables)
rule_source = LocalRuleSource(ROOT, tables.get('rules', []), MODE, tables.get('rule_elements', []))
# 公开视图是否已获授权发布规则要素原文（DECISION_LOG.md#D7）
public_rule_text = bool(MODE in ('public', 'std') and
                        str(manifest.get('rule_text_publication', 'none')).lower() == 'full')
explorer = Explorer(store, 'locator_only' if MODE in ('public', 'std') else 'synthetic',
                    rule_source.records, rule_source, allow_public_rule_text=public_rule_text)
# 页面首次打开时的语言，可用 DENGEKG_LANGUAGE=en 变成英文优先
DEFAULT_LANGUAGE = 'en' if os.getenv('DENGEKG_LANGUAGE', 'zh').strip().lower().startswith('en') else 'zh'


def mode_line(lang):
    if MODE == 'demo':
        label = t(lang, 'mode_demo')
    elif MODE == 'std':
        label = t(lang, 'mode_standardized')
    else:
        label = t(lang, 'mode_public')
    if MODE in ('public', 'std') and manifest.get('version'):
        label += ' / ' + str(manifest['version'])
    return f'**{label}** · ' + t(lang, 'loaded_cases', count=len(store.cases))


def language_choices(lang):
    return [(t(lang, 'lang_zh'), 'zh'), (t(lang, 'lang_en'), 'en')]


def scope_choices(lang):
    return [(t(lang, 'scope_current'), 'current'), (t(lang, 'scope_all'), 'all')]


def table_update(rows, kind, lang):
    """Dataframe update carrying both the rows and the localised header row."""
    return gr.update(value={'data': rows, 'headers': headers(lang, kind)})


def render_rules(case_id, scope, lang):
    selected = None if scope == 'all' else case_id
    note, _ = explorer.classified_table(selected, lang=lang)
    if MODE == 'public' and not public_rule_text:
        note += ' ' + rule_source.message(lang)
    triples = explorer.rule_triples(selected)
    return note, [[r['rule_id'], r['predicate'], r['content']] for r in triples]


def trace_fact(fact_id, case_id, lang, scope='current'):
    for kind, (table, key) in FACTS.items():
        if kind == 'attribute':
            continue
        rows = store.tables.get(table, []) if scope == 'all' else store.rows(table, case_id)
        if any(r.get(key) == fact_id for r in rows):
            return explorer.trace_panel(kind, fact_id, scope, case_id, lang)
    return t(lang, 'empty_trace_note'), {'status': 'not_found', 'evidence': []}, []


def evidence_choices(case_id, scope, lang):
    if scope == 'all':
        choices = [r.get(key) for _, (table, key) in FACTS.items()
                   for r in store.tables.get(table, []) if table != 'attributes' and r.get(key)]
    else:
        choices = explorer.case_fact_choices(case_id)
    first = choices[0] if choices else None
    note, result, rows = trace_fact(first, case_id, lang, scope)
    return gr.update(choices=choices, value=first), note, result, rows


def attribute_choices(case_id, lang):
    choices = [(t(lang, 'attr_all_owners'), '')]
    choices += [(owner['label'], owner['value']) for owner in explorer.attribute_owners(case_id, lang)]
    return choices


def attribute_panel(case_id, lang, owner=''):
    """Note and rows of the attributes tab, for one owning entity or all of them."""
    summary = explorer.attribute_summary(case_id, owner)
    if not summary['total']:
        return t(lang, 'attr_empty'), []
    note = t(lang, 'attr_note', count=summary['count'], owners=summary['owners'])
    return note, explorer.attribute_rows(case_id, lang, owner)


def attribute_filter_update(case_id, lang, owner=''):
    choices = attribute_choices(case_id, lang)
    keep = owner if owner in {value for _, value in choices} else ''
    return gr.update(label=t(lang, 'attr_filter'), choices=choices, value=keep)


def case_content(case_id, lang, rule_scope='current', evidence_scope='current'):
    case = store.cases[case_id]
    counts = {n: len(store.rows(n, case_id)) for n in ('entities', 'relations', 'transmission', 'rules')}
    summary = (f'### {html.escape(case.get("title", case_id))}\n\n'
               + t(lang, 'case_meta', case_id=case_id, language=case.get('language', '')) + '\n\n'
               + t(lang, 'counts', **counts) + '\n\n'
               + t(lang, 'summary_note'))
    rule_note, rule_rows = render_rules(case_id, rule_scope, lang)
    picker, trace_note, trace_result, evidence_rows = evidence_choices(case_id, evidence_scope, lang)
    attr_note, attr_rows = attribute_panel(case_id, lang)
    return {'summary': summary,
            'graph': graph_for_case(store, case_id, lang, rule_triples=explorer.rule_triples(case_id)),
            'relation_rows': explorer.combined_statements(case_id, include_rules=True, language=lang),
            'rule_note': rule_note, 'rule_rows': rule_rows,
            'picker': picker, 'trace_note': trace_note, 'trace_result': trace_result,
            'evidence_rows': evidence_rows,
            'attr_note': attr_note, 'attr_rows': attr_rows}


def intro_html(lang):
    """Platform introduction shown above the case picker; follows the language switch."""
    parts = [t(lang, key) for key in ('intro_lede', 'intro_method')]
    return '<div class="intro-card">' + ''.join(f'<p>{part}</p>' for part in parts) + '</div>'


def static_updates(lang):
    """One update per fixed label, so the whole page follows the selected language."""
    return {
        'header': gr.update(value=t(lang, 'app_title')),
        'mode': gr.update(value=mode_line(lang)),
        'intro': gr.update(value=intro_html(lang)),
        'demo': gr.update(value=t(lang, 'demo_notice') if MODE == 'demo' else '',
                          visible=MODE == 'demo'),
        'case_picker': gr.update(label=t(lang, 'case_picker')),
        'language': gr.update(label=t(lang, 'language'), choices=language_choices(lang)),
        'tab_case': gr.update(label=t(lang, 'tab_case')),
        'tab_rules': gr.update(label=t(lang, 'tab_rules')),
        'tab_evidence': gr.update(label=t(lang, 'tab_evidence')),
        'tab_attributes': gr.update(label=t(lang, 'tab_attributes')),
        'tab_checks': gr.update(label=t(lang, 'tab_checks')),
        'case_note': gr.update(value=t(lang, 'case_graph_note')),
        'triple_note': gr.update(value=t(lang, 'triple_note')),
        'rules_note': gr.update(value=t(lang, 'rules_note')),
        'evidence_note': gr.update(value=t(lang, 'evidence_note_public' if public_rule_text
                                          else 'evidence_note_local')),
        'rule_scope': gr.update(label=t(lang, 'rule_scope'), choices=scope_choices(lang)),
        'evidence_scope': gr.update(label=t(lang, 'evidence_scope'), choices=scope_choices(lang)),
        'trace_button': gr.update(value=t(lang, 'trace_button')),
        'diagnostics': gr.update(value=explorer.diagnostics(lang),
                                 label=t(lang, 'label_diagnostics')),
        'rule_source': gr.update(value=rule_source.message(lang)),
    }


def trace_result_update(result, lang):
    return gr.update(value=result, label=t(lang, 'label_trace_result'))


def refresh(case_id, lang, rule_scope_value, evidence_scope_value, attr_owner=''):
    """Full page refresh: content plus every label that depends on the language."""
    content = case_content(case_id, lang, rule_scope_value, evidence_scope_value)
    fixed = static_updates(lang)
    picker = dict(content['picker'], label=t(lang, 'trace_picker'))
    filter_update = attribute_filter_update(case_id, lang, attr_owner)
    attr_note, attr_rows = attribute_panel(case_id, lang, filter_update['value'])
    return [fixed['header'], fixed['mode'], fixed['intro'], fixed['demo'], fixed['case_picker'],
            fixed['language'],
            fixed['tab_case'], fixed['tab_rules'], fixed['tab_evidence'], fixed['tab_attributes'],
            fixed['tab_checks'],
            content['summary'], content['graph'], fixed['case_note'],
            table_update(content['relation_rows'], 'triple', lang), fixed['triple_note'],
            fixed['rule_scope'], content['rule_note'], fixed['rules_note'],
            table_update(content['rule_rows'], 'rule', lang),
            fixed['evidence_scope'], picker, fixed['trace_button'], content['trace_note'],
            trace_result_update(content['trace_result'], lang),
            table_update(content['evidence_rows'], 'evidence', lang), fixed['evidence_note'],
            filter_update, attr_note, table_update(attr_rows, 'attribute', lang),
            fixed['diagnostics'], fixed['rule_source']]


def refresh_rules(case_id, lang, rule_scope_value):
    note, rows = render_rules(case_id, rule_scope_value, lang)
    return note, table_update(rows, 'rule', lang)


def refresh_evidence(case_id, lang, evidence_scope_value):
    picker, note, result, rows = evidence_choices(case_id, evidence_scope_value, lang)
    return (dict(picker, label=t(lang, 'trace_picker')), note,
            trace_result_update(result, lang), table_update(rows, 'evidence', lang))


def trace_event(fact_id, case_id, lang, evidence_scope_value):
    note, result, rows = trace_fact(fact_id, case_id, lang, evidence_scope_value)
    return (note, trace_result_update(result, lang),
            table_update(rows, 'evidence', lang))


def refresh_attributes(case_id, lang, attr_owner=''):
    note, rows = attribute_panel(case_id, lang, attr_owner or '')
    return note, table_update(rows, 'attribute', lang)


choices = store.choices()
if not choices:
    raise RuntimeError('Dataset contains no cases.')
first_case = choices[0][1]
# 中文为默认语言，可通过页面顶部的“语言 / Language”切换到 English
initial = case_content(first_case, DEFAULT_LANGUAGE)
with gr.Blocks(title='Dengue Research Case Knowledge Graph (DRC-KG)',css='.gradio-container{max-width:1700px!important} '
              '.prose{max-width:none!important} '
              '.intro-card{background:#f7fafc;border:1px solid #dbe6ee;border-left:4px solid #2d7fa8;'
              'border-radius:8px;padding:14px 18px;margin:4px 0 10px}'
              '.intro-card p{margin:0 0 8px;font-size:14.5px;line-height:1.75;color:#22415a}'
              '.intro-card p:last-child{margin-bottom:0}'
              '.intro-card strong{color:#123c55}') as demo:
    header_md = gr.Markdown(t(DEFAULT_LANGUAGE, 'app_title'))
    mode_md = gr.Markdown(mode_line(DEFAULT_LANGUAGE))
    intro_md = gr.HTML(intro_html(DEFAULT_LANGUAGE))
    demo_md = gr.Markdown(t(DEFAULT_LANGUAGE, 'demo_notice'), visible=(MODE == 'demo'))
    with gr.Row():
        case_picker = gr.Dropdown(choices=choices,value=first_case,label=t(DEFAULT_LANGUAGE, 'case_picker'),filterable=False,scale=3)
        language = gr.Radio(language_choices(DEFAULT_LANGUAGE),value=DEFAULT_LANGUAGE,label=t(DEFAULT_LANGUAGE, 'language'),scale=1)
    with gr.Tab(t(DEFAULT_LANGUAGE, 'tab_case')) as tab_case:
        summary = gr.Markdown(initial['summary'])
        graph = gr.HTML(initial['graph'])
        case_note = gr.Markdown(t(DEFAULT_LANGUAGE, 'case_graph_note'))
        relation_table = gr.Dataframe(headers=headers(DEFAULT_LANGUAGE, 'triple'),value=initial['relation_rows'],interactive=False,wrap=True,max_height=600)
        triple_note = gr.Markdown(t(DEFAULT_LANGUAGE, 'triple_note'))
    with gr.Tab(t(DEFAULT_LANGUAGE, 'tab_rules')) as tab_rules:
        rule_scope = gr.Radio(scope_choices(DEFAULT_LANGUAGE),value='current',label=t(DEFAULT_LANGUAGE, 'rule_scope'))
        rule_note = gr.Markdown(initial['rule_note'])
        rules_note = gr.Markdown(t(DEFAULT_LANGUAGE, 'rules_note'))
        rule_table = gr.Dataframe(headers=headers(DEFAULT_LANGUAGE, 'rule'),value=initial['rule_rows'],interactive=False,wrap=True,max_height=650)
    with gr.Tab(t(DEFAULT_LANGUAGE, 'tab_evidence')) as tab_evidence:
        evidence_scope = gr.Radio(scope_choices(DEFAULT_LANGUAGE),value='current',label=t(DEFAULT_LANGUAGE, 'evidence_scope'))
        trace_picker = gr.Dropdown(choices=initial['picker']['choices'],value=initial['picker']['value'],label=t(DEFAULT_LANGUAGE, 'trace_picker'),filterable=False)
        trace_button = gr.Button(t(DEFAULT_LANGUAGE, 'trace_button'))
        trace_note = gr.Markdown(initial['trace_note'])
        trace_result = gr.JSON(value=initial['trace_result'],label=t(DEFAULT_LANGUAGE, 'label_trace_result'))
        evidence_table = gr.Dataframe(headers=headers(DEFAULT_LANGUAGE, 'evidence'),value=initial['evidence_rows'],interactive=False,wrap=True,max_height=500)
        evidence_note = gr.Markdown(t(DEFAULT_LANGUAGE, 'evidence_note_public' if public_rule_text
                                      else 'evidence_note_local'))
    with gr.Tab(t(DEFAULT_LANGUAGE, 'tab_attributes')) as tab_attributes:
        attr_filter = gr.Dropdown(choices=attribute_choices(first_case, DEFAULT_LANGUAGE),value='',
                                  label=t(DEFAULT_LANGUAGE, 'attr_filter'),filterable=False)
        attr_note = gr.Markdown(initial['attr_note'])
        attr_table = gr.Dataframe(headers=headers(DEFAULT_LANGUAGE, 'attribute'),value=initial['attr_rows'],interactive=False,wrap=True,max_height=600)
    with gr.Tab(t(DEFAULT_LANGUAGE, 'tab_checks')) as tab_checks:
        diag_json = gr.JSON(value=explorer.diagnostics(DEFAULT_LANGUAGE),label=t(DEFAULT_LANGUAGE, 'label_diagnostics'))
        rule_source_md = gr.Markdown(rule_source.message(DEFAULT_LANGUAGE))
    outputs = [header_md, mode_md, intro_md, demo_md, case_picker, language,
               tab_case, tab_rules, tab_evidence, tab_attributes, tab_checks,
               summary, graph, case_note, relation_table, triple_note,
               rule_scope, rule_note, rules_note, rule_table,
               evidence_scope, trace_picker, trace_button, trace_note, trace_result,
               evidence_table, evidence_note,
               attr_filter, attr_note, attr_table, diag_json, rule_source_md]
    case_picker.change(refresh,[case_picker,language,rule_scope,evidence_scope,attr_filter],outputs,api_name=False)
    language.change(refresh,[case_picker,language,rule_scope,evidence_scope,attr_filter],outputs,api_name=False)
    rule_scope.change(refresh_rules,[case_picker,language,rule_scope],[rule_note,rule_table],api_name=False)
    evidence_scope.change(refresh_evidence,[case_picker,language,evidence_scope],[trace_picker,trace_note,trace_result,evidence_table],api_name=False)
    trace_picker.change(trace_event,[trace_picker,case_picker,language,evidence_scope],[trace_note,trace_result,evidence_table],api_name=False)
    trace_button.click(trace_event,[trace_picker,case_picker,language,evidence_scope],[trace_note,trace_result,evidence_table],api_name=False)
    attr_filter.change(refresh_attributes,[case_picker,language,attr_filter],[attr_note,attr_table],api_name=False)

if __name__ == '__main__':
    # Gradio's startup self-check goes through httpx, which honours the Windows proxy
    # settings; a local proxy then answers 502 for 127.0.0.1 and the launch aborts.
    os.environ.setdefault('NO_PROXY', '127.0.0.1,localhost')
    os.environ.setdefault('no_proxy', os.environ['NO_PROXY'])
    demo.launch(server_name='127.0.0.1' if rule_source.records else ('0.0.0.0' if os.getenv('SPACE_ID') else '127.0.0.1'),
        server_port=int(os.getenv('PORT','7860')),share=False,show_api=False,allowed_paths=[],
        blocked_paths=[str(ROOT/p) for p in ('_internal','internal_data','private_data','public_data','local_rules','.env')]
            + ([str(rule_source.path.parent)] if rule_source.path else []),show_error=False)
