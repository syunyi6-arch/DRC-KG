@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Run install_windows.bat first.
  pause
  exit /b 1
)
set "DENGEKG_MODE=public"
echo Public mode requires the reviewed data and a valid website release manifest.
".venv\Scripts\python.exe" app.py
pause
