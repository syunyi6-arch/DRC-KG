"""Read-only tab views and typed evidence tracing for the CSV website."""
from collections import Counter, defaultdict

from ui_text import t

FACTS = {
    'relation': ('relations', 'relation_id'),
    'attribute': ('attributes', 'attribute_id'),
    'transmission': ('transmission', 'transmission_id'),
    'rule': ('rules', 'rule_id'),
}
LOCATORS = ('evidence_id', 'case_id', 'fact_type', 'fact_id', 'ku_id', 'kuc_id',
            'source_file', 'source_doi', 'source_url', 'source_page',
            'source_section', 'source_table', 'source_sheet', 'source_row')


class Explorer:
    def __init__(self, store, evidence_mode='locator_only', local_rules=None, rule_source=None,
                 allow_public_rule_text=False):
        self.store = store
        self.evidence_mode = evidence_mode
        self.allow_public_rule_text = allow_public_rule_text
        self.local_rules = local_rules or {}
        self.rule_source = rule_source
        self.facts = {}
        for kind, (table, key) in FACTS.items():
            groups = defaultdict(list)
            for row in store.tables.get(table, []):
                groups[row.get(key, '')].append(row)
            self.facts[kind] = groups
        self.elements = defaultdict(list)
        for row in store.tables.get('rule_elements', []):
            self.elements[(row.get('case_id'), row.get('rule_id'))].append(row)

    def select(self, table, scope, case_id, keyword=''):
        rows = (self.store.tables.get(table, []) if scope == 'all'
                else self.store.rows(table, case_id))
        query = (keyword or '').strip().casefold()
        if not query:
            return list(rows)
        return [r for r in rows if query in ' '.join(str(v) for v in r.values()).casefold()]

    def status(self, table, scope, case_id, rows, lang='zh'):
        total = len(self.store.tables.get(table, []))
        local = len(self.store.rows(table, case_id))
        scope_label = (t(lang, 'scope_all_lower') if scope == 'all'
                       else t(lang, 'scope_current_lower', case=case_id or t(lang, 'scope_none')))
        note = t(lang, 'status_note', scope=scope_label, matched=len(rows),
                 total=total, local=local)
        if not rows:
            if total == 0:
                note += t(lang, 'no_table_records')
            elif scope != 'all' and local == 0:
                note += t(lang, 'no_case_records')
            else:
                note += t(lang, 'no_keyword_match')
        return note

    @staticmethod
    def endpoint(raw, entity_id, lang='zh'):
        return raw or entity_id or t(lang, 'endpoint_missing')

    def transmission_view(self, scope, case_id, keyword='', lang='zh'):
        rows = self.select('transmission', scope, case_id, keyword)
        not_recorded, not_stated = t(lang, 'not_recorded'), t(lang, 'not_stated')
        values = [[r.get('transmission_id', ''), r.get('case_id', ''),
                   self.endpoint(r.get('source_raw'), r.get('source_id'), lang),
                   r.get('source_status', '') or not_recorded,
                   self.endpoint(r.get('target_raw'), r.get('target_id'), lang),
                   r.get('target_status', '') or not_recorded,
                   r.get('certainty_original', '') or not_stated,
                   r.get('resolution_status', ''), str(r.get('graph_ready', ''))]
                  for r in rows]
        return self.status('transmission', scope, case_id, rows, lang), values

    def rule_text(self, value, local=False, lang='zh'):
        if value:
            return value
        if local:
            return t(lang, 'blank_raw')
        return (t(lang, 'locator_no_text') if self.evidence_mode == 'locator_only'
                else t(lang, 'source_no_text'))

    def rule_record(self, row):
        source = self.local_rules.get(row.get('rule_id'))
        if not source:
            return row
        out = dict(row)
        for key in ('subject', 'conditions', 'result', 'authority'):
            out[key] = source.get(key + '_raw', '')
        out['rule_text_source'] = 'local_original_annotation'
        return out

    def rule_view(self, scope, case_id, keyword='', lang='zh'):
        rows = self.select('rules', scope, case_id, keyword)
        values = [[r.get('rule_id', ''), r.get('case_id', ''), r.get('n_elements', ''),
                   r.get('rule_split_status', ''), self.rule_text(r.get('subject'), lang=lang),
                   self.rule_text(r.get('conditions'), lang=lang),
                   self.rule_text(r.get('result'), lang=lang)] for r in rows]
        note = self.status('rules', scope, case_id, rows, lang)
        blank = sum(not r.get('conditions') and not r.get('result') for r in rows)
        if blank:
            note += t(lang, 'rule_blank_note', count=blank)
        return note, values

    def first_fact(self, kind, scope, case_id):
        if kind not in FACTS:
            return ''
        table, key = FACTS[kind]
        return next((r.get(key, '') for r in self.select(table, scope, case_id) if r.get(key)), '')

    def trace(self, kind, fact_id, scope='all', case_id='', lang='zh'):
        fact_id = (fact_id or '').strip()
        if kind not in FACTS:
            return {'status': 'invalid_type', 'message': t(lang, 'msg_choose_type'), 'evidence': []}
        rows = list(self.facts[kind].get(fact_id, []))
        if scope != 'all':
            rows = [r for r in rows if r.get('case_id') == case_id]
        if not rows:
            return {'status': 'not_found', 'message': t(lang, 'msg_not_found'), 'evidence': []}
        if len(rows) != 1:
            return {'status': 'ambiguous_id', 'message': t(lang, 'msg_ambiguous'), 'evidence': []}
        row = self.rule_record(rows[0]) if kind == 'rule' else rows[0]
        owner_case = row.get('case_id', '')
        refs, issues = [], []
        for ref in self.store.evidence_by_fact.get(fact_id, []):
            if ref.get('case_id') != owner_case:
                continue
            if ref.get('fact_type') and ref.get('fact_type') != kind:
                continue
            ku = self.store.kus.get(ref.get('ku_id'), {})
            if ku and ku.get('case_id') != owner_case:
                issues.append(t(lang, 'msg_cross_case'))
                continue
            out = {key: ref.get(key, '') for key in LOCATORS}
            out['case_id'] = owner_case
            out['fact_type'] = kind
            for key in ('source_page', 'source_section', 'source_table'):
                if not out.get(key):
                    out[key] = ku.get(key, '')
            if not out.get('source_section'):
                out['source_section'] = ku.get('section', '')
            refs.append(out)
        detail_keys = {
            'relation': ('relation_id', 'head_raw', 'head_id', 'relation_original', 'ontology_relation', 'tail_raw', 'tail_id', 'endpoint_status'),
            'attribute': ('attribute_id', 'owner_id', 'owner_raw', 'owner_status', 'attribute_type', 'attribute_value'),
            'transmission': ('transmission_id', 'source_id', 'source_raw', 'source_status', 'target_id', 'target_raw', 'target_status', 'certainty_original', 'association_nature', 'assertion_polarity', 'resolution_status', 'graph_ready'),
            'rule': ('rule_id', 'rule_group_id', 'n_elements', 'subject', 'conditions', 'result', 'authority', 'rule_split_status'),
        }[kind]
        result = {'status': 'ok' if refs else 'no_evidence', 'fact_type': kind,
                  'fact_id': fact_id, 'case_id': owner_case,
                  'fact': {key: row.get(key, '') for key in detail_keys},
                  'evidence_count': len(refs), 'evidence': refs, 'issues': issues}
        if not refs:
            result['message'] = t(lang, 'msg_no_evidence')
        if kind == 'rule':
            result['rule_text_source'] = row.get('rule_text_source', 'release_view')
            result['rule_elements'] = [{key: el.get(key, '') for key in
                ('rule_element_id', 'element_order', 'element_original', 'element_category', 'ku_id', 'evidence_id')}
                for el in self.elements.get((owner_case, fact_id), [])]
            result['classified_rows'] = [r for r in self.classified_records(owner_case) if r['rule_id'] == fact_id]
            if not row.get('conditions') and not row.get('result'):
                result['content_notice'] = (t(lang, 'content_notice_blank') if row.get('rule_text_source')
                    else t(lang, 'content_notice_hidden'))
        return result

    def trace_panel(self, kind, fact_id, scope='all', case_id='', lang='zh'):
        result = self.trace(kind, fact_id, scope, case_id, lang)
        if result['status'] in ('ok', 'no_evidence'):
            note = t(lang, 'trace_note', fact_id=result['fact_id'], case_id=result['case_id'],
                     count=len(result['evidence']))
            if result.get('message'):
                note += ' ' + result['message']
        else:
            note = result['message']
        cols = ('evidence_id', 'case_id', 'ku_id', 'source_file', 'source_page',
                'source_section', 'source_sheet', 'source_row')
        values = [[r.get(k, '') for k in cols] for r in result['evidence']]
        return note, result, values

    def diagnostics(self, lang='zh'):
        return {'counts': {k: len(v) for k, v in self.store.tables.items()},
                'cases_by_language': dict(Counter(r.get('language', '') for r in self.store.cases.values())),
                'cases_with_transmission': len({r.get('case_id') for r in self.store.tables.get('transmission', [])}),
                'cases_with_rules': len({r.get('case_id') for r in self.store.tables.get('rules', [])}),
                'release_view_rules_without_condition_and_result_text': sum(not r.get('conditions') and not r.get('result') for r in self.store.tables.get('rules', [])),
                'local_original_rule_records': len(self.local_rules),
                'local_original_rule_elements': len(self.rule_source.elements) if self.rule_source else 0,
                'evidence_by_fact_type': dict(Counter(r.get('fact_type', '') or t(lang, 'untyped') for r in self.store.tables.get('evidence_references', [])))}

    def compact_rules(self, case_id, lang='zh'):
        """Use actual rules.csv field headings, without metadata columns."""
        rows = [self.rule_record(r) for r in self.store.rows('rules', case_id)]
        values = [[r.get('rule_id', ''), self.rule_text(r.get('subject'), bool(r.get('rule_text_source')), lang),
                   self.rule_text(r.get('conditions'), bool(r.get('rule_text_source')), lang),
                   self.rule_text(r.get('result'), bool(r.get('rule_text_source')), lang),
                   self.rule_text(r.get('authority'), bool(r.get('rule_text_source')), lang)] for r in rows]
        if not rows:
            return t(lang, 'compact_empty'), values
        blank = sum(not r.get('conditions') and not r.get('result') for r in rows)
        note = t(lang, 'compact_note', count=len(rows))
        if any(r.get('rule_text_source') for r in rows):
            note += t(lang, 'compact_source')
        if blank:
            note += t(lang, 'compact_blank', count=blank)
        return note, values

    def combined_statements(self, case_id, include_rules=False, language='zh'):
        """One list of source relation rows plus clearly marked TR summaries.

        Six columns: head entity, original relation, ontology relation, tail entity,
        original certainty, record ID. The endpoint/resolution status column was dropped
        from the table on request; the raw status stays in the evidence record.
        """
        transmissions = self.store.rows('transmission', case_id)
        tr_by_id = {r.get('transmission_id'): r for r in transmissions}
        labeller = getattr(self.store, 'label', None)

        def ontology_label(value):
            if labeller:
                return labeller(value, language)
            return value or ''
        rows = []
        for r in self.store.rows('relations', case_id):
            linked = tr_by_id.get(r.get('transmission_id'), {})
            certainty = linked.get('certainty_original', '')
            rows.append([r.get('head_raw') or r.get('head_id', ''),
                         r.get('relation_original') or r.get('ontology_relation', ''),
                         ontology_label(r.get('ontology_relation', '')),
                         r.get('tail_raw') or r.get('tail_id', ''),
                         certainty or (t(language, 'not_stated') if linked else ''),
                         r.get('relation_id', '')])
        for tr in transmissions:
            rows.append([self.endpoint(tr.get('source_raw'), tr.get('source_id'), language),
                         t(language, 'tr_summary'), t(language, 'tr_relation'),
                         self.endpoint(tr.get('target_raw'), tr.get('target_id'), language),
                         tr.get('certainty_original', '') or t(language, 'not_stated'),
                         tr.get('transmission_id', '')])
        if include_rules:
            for r in self.rule_triples(case_id):
                rows.append([r['rule_id'], r['predicate'], '', r['content'], '',
                             r['element_id']])
        return rows

    def case_fact_choices(self, case_id, include_attributes=False):
        choices = []
        for kind in (('relation', 'transmission', 'rule', 'attribute') if include_attributes else ('relation', 'transmission', 'rule')):
            table, key = FACTS[kind]
            for row in self.store.rows(table, case_id):
                if row.get(key):
                    choices.append(row[key])
        return choices

    def classified_records(self, case_id=None):
        """Six columns from classified source rows, in original worksheet order."""
        rules = self.store.tables.get('rules', []) if case_id is None else self.store.rows('rules', case_id)
        source = self.rule_source
        out = []
        for published in rules:
            rule = self.rule_record(published)
            cid, rid = rule.get('case_id', ''), rule.get('rule_id', '')
            case = self.store.cases.get(cid, {})
            original_case = source.cases.get(cid, {}) if source else {}
            original_rule = self.local_rules.get(rid, {})
            group = source.groups.get(rule.get('rule_group_id'), {}) if source else {}
            els = self.elements.get((cid, rid), [])
            # Synthetic demonstration has no classified element table.
            if not els and self.evidence_mode == 'synthetic':
                els = [dict(rule_element_id=rid+'-DEMO-'+key, element_original=key.title(),
                            content_original=rule.get(key), ku_id=rule.get('ku_id', ''))
                       for key in ('subject','conditions','result','authority') if rule.get(key)]
            for el in els:
                raw = source.elements.get(el.get('rule_element_id'), {}) if source else {}
                local = bool(raw)
                ku = self.store.kus.get(el.get('ku_id'), {})
                content = (raw.get('content_raw', '') if local
                           else (el.get('content_original', '')
                                 if (self.evidence_mode != 'locator_only' or self.allow_public_rule_text) else ''))
                out.append(dict(case_id=cid, rule_id=rid, element_id=el.get('rule_element_id', ''),
                    source_row=el.get('source_row', ''),
                    source_file=original_case.get('source_file') or case.get('source_file', ''),
                    research_case=original_case.get('research_case_aliases') or case.get('title') or cid,
                    title_block=group.get('title_block_raw') or original_rule.get('title_block_raw') or rule.get('title_block', ''),
                    knowledge_unit=group.get('ku_text_raw') or (ku.get('text_excerpt', '') if self.evidence_mode != 'locator_only' else ''),
                    predicate=raw.get('element_raw') if local else el.get('element_original', '') or el.get('element_category', ''),
                    category=raw.get('element_category', '') if local else el.get('element_category', ''),
                    content=content, local=local))
        def order(r):
            value = str(r['source_row'])
            return r['case_id'], int(value) if value.isdigit() else 10**12, r['element_id']
        return sorted(out, key=order)

    def classified_table(self, case_id=None, lang='zh'):
        records = self.classified_records(case_id)
        fields = ('source_file','research_case','title_block','knowledge_unit','predicate','content')
        values = [[r[k] if r[k] else (self.rule_text('', r['local'], lang) if k in ('knowledge_unit','content') else '')
                   for k in fields] for r in records]
        count = len(self.store.tables.get('rules', [])) if case_id is None else len(self.store.rows('rules', case_id))
        note = t(lang, 'classified_note', rules=count, rows=len(records))
        if not count:
            note += t(lang, 'classified_empty')
        elif not any(r['local'] for r in records):
            if self.allow_public_rule_text:
                note += t(lang, 'classified_public')
            elif self.evidence_mode == 'locator_only':
                note += t(lang, 'classified_locator')
        return note, values

    def rule_triples(self, case_id=None):
        # Reification avoids turning a conditional rule into an unconditional claim.
        return [r for r in self.classified_records(case_id) if r['predicate'] and r['content']]

    def owner_label(self, row, lang='zh'):
        """How an attribute owner is shown: name (or derived label) plus its entity ID."""
        ident = row.get('owner_id') or ''
        name = (row.get('owner_raw') or '').strip()
        if not name and ident:
            entity = getattr(self.store, 'entities', {}).get(ident)
            labeler = getattr(self.store, 'entity_label', None)
            if entity and labeler:
                name = labeler(entity, lang)
        if name and ident:
            return f'{name} ({ident})'
        return name or ident

    def attribute_owners(self, case_id, lang='zh'):
        """Owner choices of the attributes table, one per owning entity."""
        owners = {}
        for row in self.store.rows('attributes', case_id):
            ident = row.get('owner_id') or ''
            if ident:
                owners.setdefault(ident, self.owner_label(row, lang))
        return [{'value': key, 'label': owners[key]} for key in sorted(owners, key=owners.get)]

    def attribute_summary(self, case_id, owner=''):
        """How many attributes (and owning entities) the attributes tab will show."""
        rows = self.store.rows('attributes', case_id)
        total = len(rows)
        if owner:
            rows = [r for r in rows if (r.get('owner_id') or '') == owner]
        return {'total': total, 'count': len(rows),
                'owners': len({r.get('owner_id') or '' for r in rows})}

    def attribute_rows(self, case_id, lang='zh', owner=''):
        """Attribute table rows: (attribute ID, owning entity, type, value, owner status)."""
        labeller = getattr(self.store, 'label', None)
        rows = self.store.rows('attributes', case_id)
        if owner:
            rows = [r for r in rows if (r.get('owner_id') or '') == owner]
        values = []
        for r in rows:
            attribute_type = r.get('attribute_type', '')
            if labeller:
                attribute_type = labeller(attribute_type, lang)
            values.append([r.get('attribute_id', ''), self.owner_label(r, lang), attribute_type,
                           r.get('attribute_value', ''), r.get('owner_status', '')])
        return values
