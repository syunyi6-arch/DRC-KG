"""All examples are synthetic and are unrelated to real patients or articles."""
def make_demo():
    tables = {n: [] for n in ("cases", "entities", "attributes", "relations",
        "transmission", "rules", "knowledge_units", "knowledge_unit_clusters",
        "evidence_references", "rule_elements", "transmission_participants",
        "rule_groups", "ontology_term_map")}
    tables["cases"] = [
        dict(case_id="DEMO-CN-001", title="虚构登革热流行病学调查", language="zh"),
        dict(case_id="DEMO-EN-001", title="Synthetic Dengue Investigation", language="en")]
    tables["entities"] = [
        dict(entity_id="DEMO-ENT-1", case_id="DEMO-CN-001", entity_name="演示调查事件",
             ontology_class="Investigation Event", identity_status="candidate"),
        dict(entity_id="DEMO-ENT-2", case_id="DEMO-CN-001", entity_name="虚构病例A",
             ontology_class="Human", identity_status="candidate"),
        dict(entity_id="DEMO-ENT-3", case_id="DEMO-EN-001", entity_name="Synthetic investigation",
             ontology_class="Investigation Event", identity_status="candidate")]
    tables["attributes"] = [dict(attribute_id="DEMO-ATT-1", case_id="DEMO-CN-001",
        owner_id="DEMO-ENT-2", attribute_type="Example Attribute", attribute_value="虚构属性")]
    tables["relations"] = [dict(relation_id="DEMO-REL-1", case_id="DEMO-CN-001",
        head_id="DEMO-ENT-1", head_kind="entity", head_raw="演示调查事件",
        tail_id="DEMO-ENT-2", tail_kind="entity", tail_raw="虚构病例A",
        relation_original="虚构调查关系", ontology_relation="Example Relation", endpoint_status="resolved")]
    tables["transmission"] = [dict(transmission_id="DEMO-TR-1", case_id="DEMO-CN-001",
        source_id="", target_id="", source_raw="", target_raw="", source_status="empty",
        target_status="empty", certainty_original="未确认", assertion_polarity="",
        resolution_status="unresolved", graph_ready="false")]
    tables["rules"] = [dict(rule_id="DEMO-RULE-1", case_id="DEMO-CN-001",
        conditions="虚构判断条件", result="虚构处置要求", rule_split_status="synthetic")]
    tables["knowledge_units"] = [dict(ku_id="DEMO-KU-1", case_id="DEMO-CN-001",
        section="SYNTHETIC", text_excerpt="")]
    tables["evidence_references"] = [dict(evidence_id="DEMO-EV-1", case_id="DEMO-CN-001",
        fact_id="DEMO-REL-1", ku_id="DEMO-KU-1", source_file="SYNTHETIC", source_page="",
        text_excerpt="")]
    tables["ontology_term_map"] = [
        dict(label_en="Investigation Event", label_zh="调查监测事件"),
        dict(label_en="Human", label_zh="人"),
        dict(label_en="Example Relation", label_zh="演示关系"),
        dict(label_en="Example Attribute", label_zh="演示属性")]
    return tables
