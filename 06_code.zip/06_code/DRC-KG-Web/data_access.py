"""Read-only in-memory indexes; no alteration of source IDs."""
from collections import defaultdict

from ui_text import t


class DataStore:
    def __init__(self, tables):
        self.tables = tables
        self.cases = {r["case_id"]: r for r in tables.get("cases", [])}
        self.entities = {r["entity_id"]: r for r in tables.get("entities", [])}
        self.kus = {r["ku_id"]: r for r in tables.get("knowledge_units", [])}
        self.by_case = {}
        for name, rows in tables.items():
            groups = defaultdict(list)
            for row in rows:
                if row.get("case_id"):
                    groups[row["case_id"]].append(row)
            self.by_case[name] = groups
        self.evidence_by_fact = defaultdict(list)
        for row in tables.get("evidence_references", []):
            self.evidence_by_fact[row.get("fact_id", "")].append(row)
        self.terms = {}
        for row in tables.get("ontology_term_map", []):
            en = self.first(row, "label_en", "term_en", "english_label", "preferred_en")
            zh = self.first(row, "label_zh", "term_zh", "chinese_label", "preferred_zh")
            if en and zh:
                self.terms[en] = zh

    @staticmethod
    def first(row, *keys):
        return next((row[k] for k in keys if row.get(k)), "")

    def rows(self, table, case_id):
        return self.by_case.get(table, {}).get(case_id, [])

    def label(self, value, lang):
        # lang is 'zh' or 'en'; the ontology term map only stores en -> zh.
        return self.terms.get(value, value) if str(lang).lower().startswith("zh") else value

    def entity_label(self, row, lang='zh'):
        """Name to show for an entity.

        The release withholds some source names (long verbatim phrases, or PII) on
        purpose; those rows keep an empty entity_name. Rather than publishing them
        again we show a derived label built only from the public ontology class and
        the last digits of the stable entity ID.
        """
        name = (row.get('entity_name') or '').strip()
        if name and '«redacted»' not in name:
            return name
        ident = row.get('entity_id') or ''
        kind = self.label(row.get('ontology_class', ''), lang) or row.get('ontology_class', '')
        return t(lang, 'entity_redacted_label', kind=kind, suffix=ident.split('-')[-1])

    def name_is_redacted(self, row):
        name = (row.get('entity_name') or '').strip()
        return not name or '«redacted»' in name

    def choices(self, search=""):
        search = (search or "").casefold()
        return [(f'{r["case_id"]} | {r.get("title", "")[:85]}', r["case_id"])
                for r in sorted(self.cases.values(), key=lambda r: r["case_id"])
                if search in (r["case_id"] + " " + r.get("title", "")).casefold()]

    def trace_relation(self, case_id, relation_id):
        match = next((r for r in self.rows("relations", case_id)
                      if r.get("relation_id") == relation_id), None)
        if match is None:
            return {"status": "not_found"}
        evidence = []
        for ref in self.evidence_by_fact.get(relation_id, []):
            if ref.get("case_id") != case_id:
                continue
            ku = self.kus.get(ref.get("ku_id", ""), {})
            if ku and ku.get("case_id") != case_id:
                continue
            out = {k: ref.get(k, "") for k in ("evidence_id", "ku_id", "source_file",
                    "source_page", "source_section")}
            out["ku_section"] = ku.get("section", "")
            evidence.append(out)
        return {"case_id": case_id, "relation_id": relation_id,
                "ontology_relation": match.get("ontology_relation", ""),
                "relation_original": match.get("relation_original", ""),
                "evidence": evidence}
