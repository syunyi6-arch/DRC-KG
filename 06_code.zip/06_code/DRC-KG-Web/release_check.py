"""Read and validate an explicitly approved locator-only website release."""
import csv
import hashlib
import json
from pathlib import Path

REQUIRED_FILES = tuple(n + ".csv" for n in (
    "cases", "entities", "attributes", "relations", "transmission", "rules",
    "knowledge_units", "knowledge_unit_clusters", "evidence_references",
    "rule_elements", "transmission_participants", "rule_groups"))
OPTIONAL_FILES = ("ontology_term_map.csv",)
REQUIRED_COLUMNS = {
    "cases": {"case_id", "title", "language"},
    "entities": {"entity_id", "case_id", "entity_name", "ontology_class", "identity_status"},
    "attributes": {"attribute_id", "case_id", "attribute_type", "attribute_value", "owner_id"},
    "relations": {"relation_id", "case_id", "ontology_relation", "head_id", "tail_id", "endpoint_status"},
    "transmission": {"transmission_id", "case_id", "graph_ready", "source_status", "target_status"},
    "rules": {"rule_id", "case_id"},
    "knowledge_units": {"ku_id", "case_id"},
    "evidence_references": {"evidence_id", "case_id", "fact_id", "ku_id"},
}

def checksum(path):
    h = hashlib.sha256()
    with open(path, "rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def check_public_release(folder):
    folder = Path(folder)
    manifest_path = folder / "release_manifest.json"
    if not manifest_path.is_file() or manifest_path.is_symlink():
        raise RuntimeError("Missing website release manifest.")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8-sig"))
    if manifest.get("release_ready") is not True or manifest.get("website_approved") is not True:
        raise RuntimeError("Website release approval is missing.")
    if any(manifest.get("gates", {}).get(g) != "PASS" for g in ("P15", "P17")):
        raise RuntimeError("P15/P17 must pass.")
    if manifest.get("evidence_mode") != "locator_only":
        raise RuntimeError("Expected locator_only evidence mode.")
    if not manifest.get("approved_by") or not manifest.get("approval_date"):
        raise RuntimeError("Missing actual approver/date.")
    entries = list(folder.iterdir())
    if any(p.is_symlink() or not p.is_file() for p in entries):
        raise RuntimeError("Nested directories and symlinks are not supported.")
    present = {p.name for p in entries}
    missing = set(REQUIRED_FILES) - present
    unexpected = present - set(REQUIRED_FILES) - set(OPTIONAL_FILES) - {"release_manifest.json"}
    if missing or unexpected:
        raise RuntimeError(f"Missing: {sorted(missing)}; unexpected: {sorted(unexpected)}")
    tables = {}
    for filename in sorted(present - {"release_manifest.json"}):
        expected = manifest.get("sha256", {}).get(filename, "")
        if not expected or checksum(folder / filename).lower() != expected.lower():
            raise RuntimeError(f"SHA256 mismatch or missing hash: {filename}")
        with open(folder / filename, encoding="utf-8-sig", newline="") as stream:
            reader = csv.DictReader(stream)
            name = filename[:-4]
            absent = REQUIRED_COLUMNS.get(name, {"case_id"}) - set(reader.fieldnames or [])
            if name == "ontology_term_map":
                absent = set()
            if absent:
                raise RuntimeError(f"{filename} missing columns: {sorted(absent)}")
            tables[name] = list(reader)
    tables.setdefault("ontology_term_map", [])
    counts = manifest.get("counts", {})
    expected_cases = int(counts.get("cases", 261))
    expected_tr = int(counts.get("transmission", 161))
    case_ids = {r["case_id"] for r in tables["cases"]}
    if len(case_ids) != expected_cases or len(tables["cases"]) != expected_cases or "" in case_ids:
        raise RuntimeError(f"Expected exactly {expected_cases} distinct nonempty cases.")
    if len(tables["transmission"]) != expected_tr:
        raise RuntimeError(f"Expected {expected_tr} transmission instances.")
    for table, id_col in (("entities", "entity_id"), ("relations", "relation_id"),
                          ("attributes", "attribute_id"), ("knowledge_units", "ku_id"),
                          ("rules", "rule_id"), ("transmission", "transmission_id")):
        ids = [r[id_col] for r in tables[table]]
        if any(not i for i in ids) or len(ids) != len(set(ids)):
            raise RuntimeError(f"Empty or duplicate identifiers in {table}")
    for table, rows in tables.items():
        for row in rows:
            if table != "ontology_term_map" and row.get("case_id") not in case_ids:
                raise RuntimeError(f"Invalid case reference in {table}")
            if table in ("knowledge_units", "evidence_references") and row.get("text_excerpt", "").strip():
                raise RuntimeError("Locator-only data contains narrative excerpts.")
    return tables, manifest
