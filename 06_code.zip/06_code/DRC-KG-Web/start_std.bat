@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Run install_windows.bat first.
  pause
  exit /b 1
)
set "DENGEKG_MODE=std"
echo Standardized-table view: data is read from ..\..\04_knowledge_graph\01_standardized_data
echo This is the internal candidate release, not the approved public release view.
".venv\Scripts\python.exe" app.py
pause
