---
title: Dengue Research Case Knowledge Graph (DRC-KG)
emoji: 🦟
colorFrom: blue
colorTo: green
sdk: static
pinned: false
---

# Dengue Research Case Knowledge Graph (DRC-KG) — static HTML + JavaScript build

A Hugging Face **Static Space** version of `DRC-KG-Web` (the Gradio app). Same data,
same wording, same tables, same graph rules and the same Chinese/English switch — but
served as plain static files: no Python runtime on the server.

Open `index.html` through a web server (see below); the page then loads only the case
you pick, about 200 KB of JSON per case.

## Layout

```
index.html                 page shell
assets/css/app.css         styling that mirrors the Gradio layout
assets/js/i18n-data.js     generated from DRC-KG-Web/ui_text.py
assets/js/i18n.js          t(key), headers(lang, table), %1..%4 fill
assets/js/data.js          fetch + cache of the JSON shards
assets/js/explorer.js      port of detail_views.Explorer and its tables/traces
assets/js/graph.js         port of graph_view.py + readable_graph.py (vis-network 9.1.2)
assets/js/app.js           tabs, controls, language switch
assets/vendor/             vis-network 9.1.2 (vendored, no CDN calls)
data/                      generated: 261 case shards + global indexes
tools/build_data.py        CSV -> data/*.json
tools/build_i18n.py        ui_text.py -> assets/js/i18n-data.js
preview.bat                local preview server on http://127.0.0.1:7870
```

## Run locally

```
preview.bat
```

or any static server, for example:

```
python -m http.server 7870 --bind 127.0.0.1
```

Then open <http://127.0.0.1:7870/>. Add `?lang=en` to open in English.
Opening `index.html` directly from disk does not work: browsers refuse `fetch()` of local
JSON from `file://`.

## Rebuild the data

The build scripts read the validated release from the Gradio project, so both sites keep
exactly the same records:

```
set DRC_KG_SOURCE=D:\path\to\DRC-KG-Web
python tools\build_data.py
python tools\build_i18n.py
```

`build_data.py` validates `public_data/release_manifest.json` (SHA256, 261 cases,
161 transmission statements) before writing anything, and writes:

| file | size | purpose |
| --- | --- | --- |
| `data/cases.json` | 51 KB | case list, titles, per-case counts |
| `data/case/<ID>.json` | 150 KB–2 MB | entities, relations, transmission, rules, elements, attributes, knowledge units, evidence for one case |
| `data/rules.json` | ~300 KB | every rule and element, for “all loaded cases” |
| `data/facts.json` | ~900 KB | every relation / transmission / rule id, for “all loaded cases” traces |
| `data/terms.json` | ~100 KB | ontology label map (English → Chinese) |
| `data/diagnostics.json` | 1 KB | the “Data checks” tab payload |

## Fidelity with the Gradio app

Replicated exactly:

- All interface wording, both languages, generated from `ui_text.py` (156 strings).
- Layout order: title, release line, introduction card, case picker, language switch,
  five tabs, notes, tables, JSON panels.
- Tables and their columns; “case scope” and “all loaded cases” options; the evidence
  trace result object (same keys and order, including `classified_rows` and
  `content_notice`); the diagnostics payload.
- The “Attributes” tab (owning entity filter, five columns) and the graph’s
  “Show attributes” checkbox, which adds the attribute values of the displayed entities
  as small box nodes (capped at 240, empty values skipped).
- Entity names withheld by the release (long verbatim phrases, PII) are shown as
  “name redacted (class) N”, derived from the public ontology class and the entity ID;
  the tooltip says so, and the Attributes tab lists them as “label (entity ID)”.
- Graph rules: at most 300 source relations, only resolved endpoints that belong to the
  case, transmission statements first, rule elements as structural edges, the same
  colours, the 12 / 24 / all display scopes, centre-node focus, zoom, fit, readable
  zoom, the component-ring spread layout, font size and fullscreen.

Differences worth knowing:

- There is no local step-2 rule index in a browser, so the rule-source note is the
  “rule text comes from the public dataset” wording (identical to the Gradio app running
  in public mode).
- `local_original_rule_records` / `local_original_rule_elements` in Data checks are 0,
  as in public mode.
- Language switching happens instantly in the browser instead of a server round-trip.
- The graph is rendered in the page (no sandboxed iframe), so “fullscreen” enlarges the
  graph card itself.

## Deploy as a Static Space

1. Create a Space with **SDK: static**.
2. Upload this folder (or `git push` it); `data/` must be included (~62 MB, largest file
   1.5 MB, so no LFS needed).
3. Nothing to configure: `index.html` is the entry point, and the YAML front matter above
   is the Space card.

## Summary

This folder is a backend-free replica of `DRC-KG-Web` (the Gradio app): every record is
pre-split into per-case JSON at build time and the browser loads only the case you pick.
The bilingual interface, the tabs, the tables, the evidence traces and the graph
(12 / 24 / all nodes, focus, zoom, spread layout, font size, fullscreen) match the
original. For a local preview run `preview.bat` and open <http://127.0.0.1:7870/>; after
updating the data run `tools\build_data.py` and `tools\build_i18n.py` to regenerate.
