---
title: Dengue Research Case Knowledge Graph (DRC-KG)
emoji: 🦟
colorFrom: blue
colorTo: green
sdk: static
pinned: false
---

# Dengue Research Case Knowledge Graph (DRC-KG) — static HTML + JavaScript build

A Hugging Face **Static Space** version of `DRC-KG-Web` (the Gradio app, now shipped next to this
folder in `../DRC-KG-Web/`). Same data, same wording, same tables, same graph rules and the same
Chinese/English switch — but served as plain static files: no Python runtime on the server.

Open `index.html` through a web server (see below); the page then loads only the case
you pick, about 200 KB of JSON per case.

## Layout

```
index.html                 page shell
assets/css/app.css         styling that mirrors the Gradio layout
assets/js/i18n-data.js     generated from DRC-KG-Web/ui_text.py
assets/js/i18n.js          t(key), headers(lang, table), %1..%4 fill
assets/js/data.js          fetch + cache of the JSON shards
assets/js/explorer.js      port of detail_views.Explorer and its tables/traces
assets/js/graph.js         port of graph_view.py + readable_graph.py (vis-network 9.1.2)
assets/js/app.js           tabs, controls, language switch
assets/vendor/             vis-network 9.1.2 (vendored, no CDN calls)
data/                      generated: 261 case shards + global indexes
tools/build_web_data.py    standardized KG tables -> data/*.json
tools/smoke_test.js        headless node check of the shipped JS + data
tools/build_i18n.py        ui_text.py -> assets/js/i18n-data.js
preview.bat                local preview server on http://127.0.0.1:7870
```

## Run locally

```
preview.bat
```

or any static server, for example:

```
python -m http.server 7870 --bind 127.0.0.1
```

Then open <http://127.0.0.1:7870/>. The interface opens in English; add `?lang=zh` to
open the Chinese one (the language switch in the page does the same without a reload).
Opening `index.html` directly from disk does not work: browsers refuse `fetch()` of local
JSON from `file://`.

## Rebuild the data

The data now comes straight from the knowledge-graph release, so the site and
`04_knowledge_graph/01_standardized_data/` can never disagree:

```
python tools\build_web_data.py
python tools\build_i18n.py
```

`build_web_data.py` reads the 13 standardized CSV tables, `03_ontology/ontology_term_map.csv` and
`04_knowledge_graph/01_standardized_data/release_manifest.json`, and writes:

| file | size | purpose |
| --- | --- | --- |
| `data/cases.json` | 50 KB | case list, titles, per-case counts |
| `data/case/<ID>.json` | 55 KB-2.3 MB | entities, relations, transmission, rules, elements, attributes, knowledge units, evidence for one case |
| `data/rules.json` | 265 KB | every rule and element, for "all loaded cases" |
| `data/facts.json` | 3.9 MB | every relation / transmission / rule id, for "all loaded cases" traces |
| `data/terms.json` | 19 KB | ontology label map (English -> Chinese) |
| `data/diagnostics.json` | 1 KB | the "Data checks" tab payload |

`tools/smoke_test.js` (node, no browser needed) loads the shipped scripts and data and exercises the
exact code paths the page uses - case shards, `combinedRows`, `localRows`, the evidence trace and
`Graph.buildView` - then fails if a shard is unreadable, a trace comes back empty or a graph loses its
relation edges:

```
node tools\smoke_test.js
```

### Field mapping

Everything below is derived, never invented:

| site field | source |
| --- | --- |
| `entity_name` / `ontology_class` | `entities.entity_raw` / `entities.class_label_en` |
| `ontology_class`, `attribute_type`, `ontology_relation` | the **human-reviewed** canonical English term from the reviewed term-map sheet of `03_ontology/ontology_bilingual.xlsx`, never a machine translation; the build fails if the term map drifts from that sheet (467/467 equal, 0 drift on 382,351 labels) |
| `attribute_type` / `attribute_value` | `attributes.attribute_label_en` / `attributes.attribute_value` |
| `owner_id`, `head_id`, `tail_id`, `source_id`, `target_id` | **case-local literal match** between a raw name and an entity of the same case (the class label breaks homonyms). Published as `endpoint_status` / `*_status` = `candidate`, or `unresolved` when no entity of that case carries the name. |
| `relation_original` / `ontology_relation` | `relations.relation_raw` / `relations.ontology_relation_en` |
| `relation_layer` | constant `plain`: the standardized tables keep the sheet-03 relations, while sheet-07 transmission relations are aggregated into `transmission` instead of `relations` |
| `element_original` / `content_original` | `rule_elements.element_raw` / `rule_elements.content` |
| `ku.source_table` | the sheet tag the knowledge unit was annotated in (`knowledge_units.source_sheets`) |
| `evidence.source_file` / `source_sheet` / `source_row` | `evidence_references.source_file` / `source_sheet` / `source_row` |

Intentionally empty, because the standardized tables do not carry them: `source_section`, `source_page`,
`certainty_original`, `association_nature`, `assertion_polarity`, `resolution_status`. The interface already
treats all of them as optional (blank cell, "not stated", no badge).

Two graph predicates were widened for the same reason: `graph.js` and `explorer.js` now also accept
`endpoint_status === 'candidate'` when deciding whether an edge may be drawn / ranked, because entities are
not disambiguated across papers in this release.

## Fidelity with the Gradio app

Replicated exactly:

- All interface wording, both languages, generated from `ui_text.py` (161 strings), plus the
  eight controlled status values (`candidate`, `resolved`, `resolved_unique`, `unresolved`,
  `ambiguous`, `conflict`, `true`, `false`), which `enumT()` translates for display:
  the Chinese page shows the translated status labels while the English page keeps the canonical terms.
- Layout order: title, release line, introduction card, case picker, language switch,
  five tabs, notes, tables, JSON panels.
- Tables and their columns, with the one omission listed under the differences below; “case scope” and “all loaded cases” options; the evidence
  trace result object (same keys and order, including `classified_rows` and
  `content_notice`); the diagnostics payload.
- The “Attributes” tab (owning entity filter, five columns) and the graph’s
  “Show attributes” checkbox, which adds the attribute values of the displayed entities
  as small box nodes (empty values skipped).
- Entity names withheld by the release (long verbatim phrases, PII) are shown as
  “name redacted (class) N”, derived from the public ontology class and the entity ID;
  the tooltip says so, and the Attributes tab lists them as “label (entity ID)”.
- Graph rules: at most 300 source relations, only resolved endpoints that belong to the
  case, transmission statements first, rule elements as structural edges, the same
  colours, the 12 / 24 / all display scopes, centre-node focus, zoom, fit, readable
  zoom, the component-ring spread layout, font size and fullscreen.

Differences worth knowing:

- The triples table has five columns: the predicate / rule-element column is not shown.
- The page opens in English (`?lang=zh` for Chinese), so a first-time visitor never sees a
  half-translated shell.
- Nothing is opened in full. The graph starts in the 12-node clear local scope, centred on
  the entity whose neighbourhood holds the most meaningful edges and the most attribute
  values, with “Show attributes” already ticked: attribute boxes are capped at three per
  displayed entity (240 overall) so a local view stays readable at its own zoom level.
  The toolbar still offers 24 nodes and the full case.
- The triples table starts on “Selected (N rows)”: every transmission statement plus the
  relations that touch the best-connected endpoints, 24 rows by default. “All rows” and the
  Rules tab still show every record, and the note above the table says how many are hidden.
- There is no local step-2 rule index in a browser, so the rule-source note is the
  “rule text comes from the public dataset” wording (identical to the Gradio app running
  in public mode).
- `local_original_rule_records` / `local_original_rule_elements` in Data checks are 0,
  as in public mode.
- Language switching happens instantly in the browser instead of a server round-trip.
- The graph is rendered in the page (no sandboxed iframe), so “fullscreen” enlarges the
  graph card itself.

## Deploy as a Static Space

1. Create a Space with **SDK: static**.
2. Upload this folder (or `git push` it); `data/` must be included (~134 MB, largest file
   2.3 MB, so no LFS needed).
3. Nothing to configure: `index.html` is the entry point, and the YAML front matter above
   is the Space card.

## Summary

This folder is a backend-free replica of `DRC-KG-Web` (the Gradio app): every record is
pre-split into per-case JSON at build time and the browser loads only the case you pick.
The bilingual interface, the tabs, the tables, the evidence traces and the graph
(12 / 24 / all nodes, focus, zoom, spread layout, font size, fullscreen) match the
original. The page opens in English on a 12-node local view with attributes drawn, and the
triples table opens on a ranked 24-row selection instead of the whole case; the toolbar and
the table switch still reach every record. For a local preview run `preview.bat` and open
<http://127.0.0.1:7870/>; after updating the data run `tools\build_web_data.py` and
`tools\build_i18n.py` to regenerate.
