@echo off
rem Serve the static site locally. Opening index.html from disk will not work,
rem because the browser blocks fetch() of local JSON from file://.
setlocal
cd /d "%~dp0"
echo Serving http://127.0.0.1:7870/  (Ctrl+C stops it)
where py >nul 2>&1
if not errorlevel 1 (
  py -3 -m http.server 7870 --bind 127.0.0.1
  goto :eof
)
python -m http.server 7870 --bind 127.0.0.1
