/* Port of detail_views.Explorer and graph_view, so the static page shows exactly
   the records, wording and tables of the Gradio application. */
(function () {
  const LOCATORS = ['evidence_id', 'case_id', 'fact_type', 'fact_id', 'ku_id', 'kuc_id',
    'source_file', 'source_doi', 'source_url', 'source_page', 'source_section',
    'source_table', 'source_sheet', 'source_row'];

  const DETAIL_KEYS = {
    relation: ['relation_id', 'head_raw', 'head_id', 'relation_original', 'ontology_relation',
      'tail_raw', 'tail_id', 'endpoint_status'],
    attribute: ['attribute_id', 'owner_id', 'owner_raw', 'owner_status', 'attribute_type',
      'attribute_value'],
    transmission: ['transmission_id', 'source_id', 'source_raw', 'source_status', 'target_id',
      'target_raw', 'target_status', 'certainty_original', 'association_nature',
      'assertion_polarity', 'resolution_status', 'graph_ready'],
    rule: ['rule_id', 'rule_group_id', 'n_elements', 'subject', 'conditions', 'result',
      'authority'],
  };

  const TABLE_FIELDS = { relation: 'relations', transmission: 'transmission', rule: 'rules' };

  function ontology(value, lang, terms) {
    if (!value) return '';
    if (String(lang).toLowerCase().startsWith('zh')) return terms[value] || value;
    return value;
  }

  function endpoint(raw, id, lang) {
    return raw || id || T(lang, 'endpoint_missing');
  }

  function rowNumber(value) {
    const text = String(value === undefined || value === null ? '' : value);
    return /^\d+$/.test(text) ? Number(text) : 1e12;
  }

  function sortRecords(records) {
    records.sort((a, b) => {
      if (a.case_id !== b.case_id) return a.case_id < b.case_id ? -1 : 1;
      const ra = rowNumber(a.source_row), rb = rowNumber(b.source_row);
      if (ra !== rb) return ra - rb;
      return a.element_id < b.element_id ? -1 : a.element_id > b.element_id ? 1 : 0;
    });
    return records;
  }

  function record(caseRow, rule, element) {
    return {
      case_id: caseRow.case_id,
      rule_id: rule.rule_id,
      element_id: element.rule_element_id || '',
      source_row: element.source_row || '',
      source_file: caseRow.source_file || '',
      research_case: caseRow.title || caseRow.case_id,
      title_block: rule.title_block || '',
      knowledge_unit: '',
      predicate: element.element_original || element.element_category || '',
      category: element.element_category || '',
      content: element.content_original || '',
      local: false,
    };
  }

  function groupElements(elements) {
    const grouped = new Map();
    for (const element of elements) {
      if (!grouped.has(element.rule_id)) grouped.set(element.rule_id, []);
      grouped.get(element.rule_id).push(element);
    }
    return grouped;
  }

  /* Six-column classified rows of one case, in source worksheet order. */
  function classifiedRecords(caseData) {
    const grouped = groupElements(caseData.elements);
    const caseRow = { case_id: caseData.id, title: caseData.title, source_file: caseData.source_file };
    const out = [];
    for (const rule of caseData.rules) {
      for (const element of grouped.get(rule.rule_id) || []) {
        out.push(record(caseRow, rule, element));
      }
    }
    return sortRecords(out);
  }

  /* The same rows across every loaded case, for the "all loaded cases" option. */
  function classifiedRecordsAll(rulesData) {
    const grouped = groupElements(rulesData.elements);
    const out = [];
    for (const rule of rulesData.rules) {
      const info = rulesData.cases[rule.case_id] || {};
      const caseRow = { case_id: rule.case_id, title: info.title || '', source_file: info.source_file || '' };
      for (const element of grouped.get(rule.rule_id) || []) {
        out.push(record(caseRow, rule, element));
      }
    }
    return sortRecords(out);
  }

  function triples(records) {
    return records.filter((row) => row.predicate && row.content);
  }

  /* combined_statements(): source relations, transmission statements, rule elements.
     Six columns; the endpoint/resolution status column is not shown. */
  function combinedRows(caseData, lang, terms) {
    const byId = new Map(caseData.transmission.map((row) => [row.transmission_id, row]));
    const rows = [];
    for (const relation of caseData.relations) {
      const linked = byId.get(relation.transmission_id);
      const certainty = linked ? (linked.certainty_original || '') : '';
      rows.push([
        relation.head_raw || relation.head_id || '',
        relation.relation_original || relation.ontology_relation || '',
        ontology(relation.ontology_relation || '', lang, terms),
        relation.tail_raw || relation.tail_id || '',
        certainty || (linked ? T(lang, 'not_stated') : ''),
        relation.relation_id || '',
      ]);
    }
    for (const item of caseData.transmission) {
      rows.push([
        endpoint(item.source_raw, item.source_id, lang),
        T(lang, 'tr_summary'),
        T(lang, 'tr_relation'),
        endpoint(item.target_raw, item.target_id, lang),
        item.certainty_original || T(lang, 'not_stated'),
        item.transmission_id || '',
      ]);
    }
    for (const row of triples(classifiedRecords(caseData))) {
      rows.push([row.rule_id, row.predicate, '', row.content, '', row.element_id]);
    }
    return rows;
  }

  /* Rules tab: note from the classified table, rows from the rule triples. */
  function rulesTable(scope, caseData, rulesData, lang) {
    const records = scope === 'all' ? classifiedRecordsAll(rulesData) : classifiedRecords(caseData);
    const ruleCount = scope === 'all' ? rulesData.rules.length : caseData.rules.length;
    let note = T(lang, 'classified_note', { rules: ruleCount, rows: records.length });
    if (!ruleCount) {
      note += T(lang, 'classified_empty');
    } else if (!records.some((row) => row.local)) {
      // The public release publishes rule text, so this is the wording the Gradio app shows.
      note += T(lang, 'classified_public');
    }
    return {
      note,
      rows: triples(records).map((row) => [row.rule_id, row.predicate, row.content]),
    };
  }

  function factChoices(caseData, scope, factsData) {
    if (scope === 'all') return factsData.order.slice();
    const choices = [];
    for (const name of ['relations', 'transmission', 'rules']) {
      const key = name === 'relations' ? 'relation_id' : name === 'transmission' ? 'transmission_id' : 'rule_id';
      for (const row of caseData[name]) {
        if (row[key]) choices.push(row[key]);
      }
    }
    return choices;
  }

  /* trace(): typed evidence lookup with the same guards as the Python explorer. */
  function trace(caseData, lang, kind, factId, scope) {
    const id = String(factId === undefined || factId === null ? '' : factId).trim();
    const table = TABLE_FIELDS[kind];
    if (!table) {
      return { status: 'invalid_type', message: T(lang, 'msg_choose_type'), evidence: [] };
    }
    const key = table === 'relations' ? 'relation_id' : table === 'transmission' ? 'transmission_id' : 'rule_id';
    const rows = caseData[table].filter((row) => row[key] === id);
    if (!rows.length) {
      return { status: 'not_found', message: T(lang, 'msg_not_found'), evidence: [] };
    }
    if (rows.length !== 1) {
      return { status: 'ambiguous_id', message: T(lang, 'msg_ambiguous'), evidence: [] };
    }
    const row = rows[0];
    const ownerCase = row.case_id || caseData.id;
    const kus = new Map(caseData.kus.map((ku) => [ku.ku_id, ku]));
    const refs = [];
    const issues = [];
    for (const ref of caseData.evidence) {
      if (ref.fact_id !== id) continue;
      if (ref.case_id !== ownerCase) continue;
      if (ref.fact_type && ref.fact_type !== kind) continue;
      const ku = kus.get(ref.ku_id);
      if (ku && ku.case_id && ku.case_id !== ownerCase) {
        issues.push(T(lang, 'msg_cross_case'));
        continue;
      }
      const out = {};
      for (const locator of LOCATORS) out[locator] = ref[locator] || '';
      out.case_id = ownerCase;
      out.fact_type = kind;
      for (const fallback of ['source_page', 'source_section', 'source_table']) {
        if (!out[fallback] && ku) out[fallback] = ku[fallback] || '';
      }
      if (!out.source_section && ku) out.source_section = ku.section || '';
      refs.push(out);
    }
    const fact = {};
    for (const field of DETAIL_KEYS[kind]) fact[field] = row[field] || '';
    const result = {
      status: refs.length ? 'ok' : 'no_evidence',
      fact_type: kind,
      fact_id: id,
      case_id: ownerCase,
      fact,
      evidence_count: refs.length,
      evidence: refs,
      issues,
    };
    if (!refs.length) result.message = T(lang, 'msg_no_evidence');
    if (kind === 'rule') {
      result.rule_text_source = 'release_view';
      result.rule_elements = caseData.elements
        .filter((element) => element.rule_id === id)
        .map((element) => {
          const picked = {};
          for (const field of ['rule_element_id', 'element_order', 'element_original',
            'element_category', 'ku_id', 'evidence_id']) {
            picked[field] = element[field] || '';
          }
          return picked;
        });
      result.classified_rows = classifiedRecords(caseData).filter((item) => item.rule_id === id);
      if (!row.conditions && !row.result) {
        result.content_notice = T(lang, 'content_notice_hidden');
      }
    }
    return result;
  }

  function tracePanel(caseData, lang, kind, factId, scope) {
    const result = trace(caseData, lang, kind, factId, scope);
    let note;
    if (result.status === 'ok' || result.status === 'no_evidence') {
      note = T(lang, 'trace_note', {
        fact_id: result.fact_id, case_id: result.case_id, count: result.evidence.length,
      });
      if (result.message) note += ' ' + result.message;
    } else {
      note = result.message;
    }
    const rows = result.evidence.map((item) => [
      item.evidence_id, item.case_id, item.ku_id, item.source_file, item.source_page,
      item.source_section, item.source_sheet, item.source_row,
    ]);
    return { note, result, rows };
  }

  window.Explorer = {
    ontology, endpoint, classifiedRecords, triples, combinedRows, rulesTable, factChoices,
    trace, tracePanel,
  };
})();
