/* Graph view and toolbar: a direct port of graph_view.py and readable_graph.py. */
(function () {
  function escapeHtml(value) {
    return String(value)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#x27;');
  }

  function shortText(value, max) {
    const text = String(value);
    return text.length > max ? text.slice(0, max - 1) + '…' : text;
  }

  /* Pixel wrapping for canvas labels: Latin at word boundaries, CJK per character. */
  function wrapLabel(value, width = 12) {
    const text = String(value === undefined || value === null ? '' : value);
    const lines = [];
    const paragraphs = text.split(/\r?\n/);
    for (const paragraph of paragraphs) {
      if (!paragraph) { lines.push(''); continue; }
      if (/[\u4e00-\u9fff]/.test(paragraph)) {
        let line = '';
        let units = 0;
        for (const character of paragraph) {
          const size = character.codePointAt(0) > 255 ? 2 : 1;
          if (units + size > width * 2) {
            lines.push(line);
            line = '';
            units = 0;
          }
          line += character;
          units += size;
        }
        if (line) lines.push(line);
      } else {
        const limit = Math.max(8, Math.trunc(width * 1.4));
        const words = paragraph.split(/\s+/).filter(Boolean);
        let line = '';
        for (const word of words) {
          let piece = word;
          while (piece.length > limit) {
            if (line) { lines.push(line); line = ''; }
            lines.push(piece.slice(0, limit));
            piece = piece.slice(limit);
          }
          if (!line) line = piece;
          else if (line.length + 1 + piece.length <= limit) line += ' ' + piece;
          else { lines.push(line); line = piece; }
        }
        if (line) lines.push(line);
      }
    }
    if (lines.length > 5) {
      const kept = lines.slice(0, 5);
      kept[4] = kept[4].slice(0, Math.max(1, kept[4].length - 1)) + '…';
      return kept.join('\n');
    }
    return lines.join('\n');
  }

  /* The node and edge set of one case, as graph_view.graph_for_case built it. */
  function buildView(caseData, lang, terms, ruleTriples) {
    const localEntities = new Set(caseData.entities.map((row) => row.entity_id));
    const transmissions = new Map(caseData.transmission.map((row) => [row.transmission_id, row]));
    const ordinary = [];
    const transmissionEdges = [];
    const local = (kind, id) => (kind === 'entity' && localEntities.has(id))
      || (kind === 'transmission' && transmissions.has(id))
      || (kind === 'case' && id === caseData.id);
    for (const relation of caseData.relations) {
      const head = relation.head_id || '';
      const tail = relation.tail_id || '';
      const status = (relation.endpoint_status || '').toLowerCase();
      // 'candidate' = both endpoints matched an entity of the same case by literal name.
      // DRC-KG 标准化表不做跨文献实体消歧，因此这是该数据能给出的最强状态。
      if (status !== 'resolved' && status !== 'resolved_unique' && status !== 'candidate') continue;
      if (!local(relation.head_kind, head) || !local(relation.tail_kind, tail)) continue;
      const isTransmission = transmissions.has(relation.transmission_id)
        || relation.relation_layer === 'transmission';
      (isTransmission ? transmissionEdges : ordinary).push([head, tail, relation, isTransmission]);
    }
    const edges = transmissionEdges.concat(ordinary).slice(0, 300);

    const ids = new Set();
    for (const [head, tail] of edges) { ids.add(head); ids.add(tail); }
    for (const id of transmissions.keys()) ids.add(id);
    const view = { nodes: [], edges: [] };
    const unlabelled = T(lang, 'graph_unlabelled');

    for (const id of [...ids].sort()) {
      if (transmissions.has(id)) {
        const row = transmissions.get(id);
        view.nodes.push({
          id,
          label: T(lang, 'graph_transmission') + '\n'
            + (row.certainty_original || T(lang, 'certainty_unstated')),
          type: 'transmission',
          subtitle: T(lang, 'graph_source', { value: row.source_raw || row.source_id || unlabelled })
            + '\n' + T(lang, 'graph_target', { value: row.target_raw || row.target_id || unlabelled })
            + '\n' + T(lang, 'graph_caveat'),
          certainty: row.certainty_original || '',
          polarity: row.assertion_polarity || '',
          resolution_status: row.resolution_status || '',
        });
      } else if (id === caseData.id) {
        view.nodes.push({ id, label: caseData.id, type: 'case' });
      } else {
        const entity = caseData.entities.find((row) => row.entity_id === id);
        if (!entity) continue;
        const name = (entity.entity_name || '').trim();
        const withheld = !name || name.indexOf('«redacted»') >= 0;
        const kind = Explorer.ontology(entity.ontology_class || '', lang, terms);
        // Names withheld by the release get a derived label from the public class + ID.
        const label = withheld ? T(lang, 'entity_redacted_label',
          { kind: kind || '', suffix: String(id).split('-').pop() }) : name;
        const subtitle = withheld
          ? (kind ? kind + '\n' : '') + T(lang, 'graph_redacted_note') : kind;
        view.nodes.push({
          id,
          label,
          type: 'entity',
          subtitle,
          identity_status: entity.identity_status || '',
          resolution_status: entity.resolution_status || '',
        });
      }
    }

    for (const [head, tail, relation, isTransmission] of edges) {
      const transmission = transmissions.get(relation.transmission_id) || {};
      const ontology = Explorer.ontology(relation.ontology_relation || '', lang, terms);
      const original = relation.relation_original || '';
      let details = T(lang, 'graph_edge_statement', {
        original: original || '-',
        ontology: ontology || T(lang, 'graph_unmapped'),
      });
      if (isTransmission) {
        details += T(lang, 'graph_edge_transmission', {
          tid: String(relation.transmission_id || ''),
          certainty: transmission.certainty_original || T(lang, 'not_stated'),
        });
      }
      view.edges.push({
        source: head,
        target: tail,
        label: ontology || original,
        kind: isTransmission ? 'transmission_statement' : 'relation',
        id: relation.relation_id || '',
        details,
      });
    }

    const addedRules = new Set();
    for (const item of ruleTriples || []) {
      if (!item.content) continue;
      if (!addedRules.has(item.rule_id)) {
        view.nodes.push({
          id: item.rule_id, label: item.rule_id, type: 'rule',
          subtitle: T(lang, 'graph_rule_node'),
        });
        addedRules.add(item.rule_id);
      }
      const valueId = 'RULE-VALUE::' + item.element_id;
      view.nodes.push({
        id: valueId, label: item.content, type: 'rule_content',
        subtitle: T(lang, 'graph_rule_content', { category: item.category || '' }),
      });
      view.edges.push({
        source: item.rule_id, target: valueId, label: item.predicate,
        kind: 'rule_element', id: item.element_id,
        details: T(lang, 'graph_rule_edge', { rule_id: item.rule_id, row: item.source_row || '' }),
      });
    }
    // Attribute values hang off their owning entity; drawn only when the toolbar box is ticked.
    view.attributes = {};
    for (const row of caseData.attributes || []) {
      const owner = row.owner_id || '';
      const value = (row.attribute_value || '').trim();
      if (!owner || !value) continue;
      if (!view.attributes[owner]) view.attributes[owner] = [];
      view.attributes[owner].push({ id: row.attribute_id || '', t: row.attribute_type || '', v: value });
    }
    return view;
  }

  /* Node count of the local view the page opens with; also the neighbourhood size used when
     scoring candidate centres, so the ranking describes exactly the picture on screen. */
  const OPENING_SCOPE = 12;

  const NODE_COLORS = {
    entity: { background: '#ADD8E6', border: '#79a9bb', highlight: { background: '#8ac7df', border: '#1b6b92' } },
    case: { background: '#e5ddf4', border: '#a793c5' },
    transmission: { background: '#ffe2af', border: '#cd932e' },
    rule: { background: '#e5ddf4', border: '#9276b8' },
    rule_content: { background: '#f2ecf8', border: '#b19acb' },
    unresolved: { background: '#e2e6e9', border: '#8a969e' },
  };

  function nodeData(node, lang) {
    const kind = node.type || 'entity';
    const raw = String(node.label === undefined ? node.id : node.label);
    let color = NODE_COLORS[kind] || NODE_COLORS.entity;
    if (['unresolved', 'ambiguous', 'conflict'].includes(node.resolution_status)) {
      color = NODE_COLORS.unresolved;
    }
    const details = [raw, 'ID: ' + node.id, node.subtitle || '',
      node.identity_status ? T(lang, 'kg_identity', { value: enumT(lang, node.identity_status) }) : '',
      node.resolution_status ? T(lang, 'kg_resolution', { value: enumT(lang, node.resolution_status) }) : '',
      node.certainty ? T(lang, 'kg_certainty', { value: node.certainty }) : '',
      node.polarity ? T(lang, 'kg_polarity', { value: node.polarity }) : '',
    ].filter(Boolean).join('\n');
    return {
      id: node.id,
      label: wrapLabel(raw),
      title: escapeHtml(details).replace(/\n/g, '<br>'),
      shape: 'circle',
      color,
      margin: 18,
      borderWidth: 1.7,
      widthConstraint: { minimum: 70, maximum: 180 },
      font: { size: 20, face: 'Microsoft YaHei, Arial', color: '#142d3e' },
      kgLabel: raw,
      kgType: kind,
      kgDetails: details,
    };
  }

  function edgeData(edge, index, lang) {
    const kind = edge.kind || 'relation';
    const label = String(edge.label || '');
    const isTransmission = kind.startsWith('transmission');
    const membership = kind === 'case_membership';
    const color = kind === 'rule_element' ? '#9276b8' : isTransmission ? '#cc8721'
      : membership ? '#b4c1c8' : '#4d829f';
    const details = [
      label,
      T(lang, 'kg_record', { value: String(edge.id === undefined ? '' : edge.id) }),
      String(edge.details || ''),
      isTransmission ? T(lang, 'kg_edge_transmission')
        : membership ? T(lang, 'kg_edge_membership')
        : kind === 'rule_element' ? T(lang, 'kg_edge_rule') : T(lang, 'kg_edge_literature'),
    ].join('\n');
    return {
      id: 'display-' + index,
      from: edge.source,
      to: edge.target,
      label,
      arrows: { to: { enabled: true, scaleFactor: 1.3 } },
      color,
      dashes: isTransmission ? [7, 5] : membership ? [3, 5] : false,
      width: membership ? 1.1 : 2.4,
      font: { size: 17, color: '#344e60', align: 'middle', strokeWidth: 5, strokeColor: '#ffffff' },
      title: escapeHtml(details).replace(/\n/g, '<br>'),
      kgKind: kind,
      kgDetails: details,
    };
  }

  const OPTIONS = {
    layout: { randomSeed: 41, improvedLayout: true },
    nodes: { font: { size: 20, face: 'Microsoft YaHei, Arial', color: '#142d3e' }, shape: 'circle', margin: 18, chosen: true },
    edges: {
      arrows: { to: { enabled: true, scaleFactor: 1.3 } },
      font: { size: 17, align: 'middle', strokeWidth: 5, strokeColor: '#ffffff' },
      smooth: { enabled: true, type: 'continuous', roundness: 0.12 }, selectionWidth: 2,
    },
    physics: {
      enabled: true, solver: 'forceAtlas2Based',
      forceAtlas2Based: {
        gravitationalConstant: -110, centralGravity: 0.0015, springLength: 320,
        springConstant: 0.035, damping: 0.4, avoidOverlap: 1,
      },
      stabilization: { enabled: true, iterations: 420, fit: false },
    },
    interaction: {
      hover: true, tooltipDelay: 150, zoomView: true, dragView: true, dragNodes: true,
      hideEdgesOnDrag: false, keyboard: false,
    },
  };

  function toolbarHtml(lang) {
    return `
<div class="graph-toolbar" role="toolbar" aria-label="${escapeHtml(T(lang, 'kg_toolbar_aria'))}">
 <label>${escapeHtml(T(lang, 'kg_scope_label'))} <select id="kg-limit" aria-label="${escapeHtml(T(lang, 'kg_scope_label'))}">
   <option value="${OPENING_SCOPE}" selected>${escapeHtml(T(lang, 'kg_scope_clear'))}</option>
   <option value="24">${escapeHtml(T(lang, 'kg_scope_extended'))}</option>
   <option value="all">${escapeHtml(T(lang, 'kg_scope_all'))}</option>
 </select></label>
 <label class="kg-check"><input type="checkbox" id="kg-attrs" checked> ${escapeHtml(T(lang, 'kg_show_attrs'))}</label>
 <label>${escapeHtml(T(lang, 'kg_center_label'))} <select id="kg-focus" aria-label="${escapeHtml(T(lang, 'kg_center_label'))}"></select></label>
 <button id="kg-refocus" type="button">${escapeHtml(T(lang, 'kg_focus'))}</button>
 <button id="kg-in" type="button" aria-label="${escapeHtml(T(lang, 'kg_zoom_in_aria'))}">${escapeHtml(T(lang, 'kg_zoom_in'))}</button>
 <button id="kg-out" type="button" aria-label="${escapeHtml(T(lang, 'kg_zoom_out_aria'))}">${escapeHtml(T(lang, 'kg_zoom_out'))}</button>
 <button id="kg-fit" type="button">${escapeHtml(T(lang, 'kg_fit'))}</button>
 <button id="kg-readable" type="button">${escapeHtml(T(lang, 'kg_readable'))}</button>
 <button id="kg-radial" type="button">${escapeHtml(T(lang, 'kg_radial'))}</button>
 <button id="kg-font" type="button">${escapeHtml(T(lang, 'kg_font', { size: 20 }))}</button>
 <button id="kg-full" type="button">${escapeHtml(T(lang, 'kg_fullscreen'))}</button>
</div>`;
  }

  function render(host, view, lang) {
    host.innerHTML = '';
    if (!view.nodes.length) {
      host.classList.add('is-empty');
      const empty = document.createElement('div');
      empty.className = 'graph-empty';
      empty.textContent = T(lang, 'graph_empty');
      host.appendChild(empty);
      return;
    }
    host.classList.remove('is-empty');
    host.insertAdjacentHTML('afterbegin', toolbarHtml(lang));
    host.insertAdjacentHTML('beforeend',
      `<div class="graph-status" role="status"></div>`
      + `<div class="graph-canvas" id="kg-canvas"></div>`
      + `<div class="graph-detail" role="status"></div>`
      + `<div class="graph-hint">${escapeHtml(T(lang, 'kg_hint'))}</div>`);

    const allNodes = view.nodes.map((node) => nodeData(node, lang));
    const allEdges = view.edges.map((edge, index) => edgeData(edge, index, lang));
    const network = new vis.Network(document.getElementById('kg-canvas'),
      { nodes: new vis.DataSet(allNodes), edges: new vis.DataSet(allEdges) }, OPTIONS);

    const nodeMap = new Map(allNodes.map((node) => [node.id, node]));
    const degree = new Map(allNodes.map((node) => [node.id, 0]));
    const adjacency = new Map(allNodes.map((node) => [node.id, new Set()]));
    for (const edge of allEdges.filter((item) => item.kgKind !== 'case_membership')) {
      if (!nodeMap.has(edge.from) || !nodeMap.has(edge.to)) continue;
      degree.set(edge.from, degree.get(edge.from) + 1);
      degree.set(edge.to, degree.get(edge.to) + 1);
      adjacency.get(edge.from).add(edge.to);
      adjacency.get(edge.to).add(edge.from);
    }
    const rank = (a, b) => (degree.get(b) || 0) - (degree.get(a) || 0)
      || String(a).localeCompare(String(b));
    const ranked = allNodes.map((node) => node.id).sort(rank);
    // The page opens on a local view centred on the most informative entity, not on every
    // node of the case; the toolbar still offers the 24-node and full scopes.
    let root = bestCenter();
    let fontSize = 20;
    let currentFont = 20;
    let stabilizationToken = 0;
    let attrInfo = new Map();
    const ATTRS = view.attributes || {};
    const ATTR_LIMIT = 240;

    const focus = document.getElementById('kg-focus');
    const limit = document.getElementById('kg-limit');
    const status = host.querySelector('.graph-status');
    const detail = host.querySelector('.graph-detail');
    const fontButton = document.getElementById('kg-font');

    for (const node of [...allNodes].sort((a, b) => String(a.kgLabel).localeCompare(String(b.kgLabel)))) {
      const option = document.createElement('option');
      option.value = String(node.id);
      option.textContent = node.kgLabel + '  [' + node.id + ']';
      focus.appendChild(option);
    }
    focus.value = String(root);

    function subset(center, cap) {
      if (cap === 'all') return new Set(ranked);
      const selected = new Set([center]);
      const queue = [center];
      const max = Number(cap);
      while (queue.length && selected.size < max) {
        const id = queue.shift();
        for (const other of [...(adjacency.get(id) || [])].sort(rank)) {
          if (selected.size >= max) break;
          if (!selected.has(other)) { selected.add(other); queue.push(other); }
        }
      }
      for (const id of ranked) { if (selected.size >= max) break; selected.add(id); }
      return selected;
    }

    /* Which node makes the best local view? Of the best-connected entities, the one whose
       OPENING_SCOPE neighbourhood holds the most meaningful edges and attribute values wins,
       so the page opens on an entity-centred subgraph rather than on the whole case. */
    function bestCenter() {
      const attributes = view.attributes || {};
      const entityIds = allNodes.filter((node) => node.kgType === 'entity')
        .sort((a, b) => rank(a.id, b.id)).map((node) => node.id);
      // Only entities may open the view: they carry the epidemiology. A case whose graph holds
      // no entity endpoint at all falls back to the best-connected nodes of any kind.
      const candidates = entityIds.length ? entityIds.slice(0, 20) : ranked.slice(0, 16);
      let best = candidates[0];
      let bestScore = -Infinity;
      for (const id of candidates) {
        const selected = subset(id, OPENING_SCOPE);
        let score = 0;
        for (const edge of allEdges) {
          if (!selected.has(edge.from) || !selected.has(edge.to)) continue;
          score += edge.kgKind === 'case_membership' ? 0 : edge.kgKind === 'rule_element' ? 1 : 3;
        }
        // The attributes are drawn by default, so a view that carries attribute values of its
        // own entities is more informative than one that leaves them empty.
        let owned = 0;
        for (const nodeId of selected) owned += Math.min((attributes[nodeId] || []).length, 3);
        score += owned * 1.2;
        if (score > bestScore) { bestScore = score; best = id; }
      }
      return best;
    }

    function positionOf(id) {
      return network.getPositions([id])[id] || { x: 0, y: 0 };
    }

    function readableZoom() {
      network.moveTo({
        position: positionOf(root), scale: 0.95,
        animation: { duration: 220, easingFunction: 'easeInOutQuad' },
      });
    }

    /* Connected components of the displayed subgraph, largest first. */
    function components(ids, adj) {
      const idSet = new Set(ids);
      const seen = new Set();
      const out = [];
      for (const id of ids) {
        if (seen.has(id)) continue;
        const comp = [];
        const queue = [id];
        seen.add(id);
        while (queue.length) {
          const current = queue.shift();
          comp.push(current);
          for (const neighbour of adj.get(current) || []) {
            if (idSet.has(neighbour) && !seen.has(neighbour)) {
              seen.add(neighbour);
              queue.push(neighbour);
            }
          }
        }
        out.push(comp);
      }
      return out.sort((a, b) => b.length - a.length);
    }

    /* Rings inside one component: BFS depth decides the ring, circumference decides the radius. */
    function ringPositions(comp, spacing, adj) {
      const idSet = new Set(comp);
      const rootId = [...comp].sort(rank)[0];
      const level = new Map([[rootId, 0]]);
      const levels = new Map([[0, [rootId]]]);
      const queue = [rootId];
      while (queue.length) {
        const current = queue.shift();
        const next = [...(adj.get(current) || [])]
          .filter((id) => idSet.has(id) && !level.has(id)).sort(rank);
        for (const id of next) {
          const depth = level.get(current) + 1;
          level.set(id, depth);
          queue.push(id);
          if (!levels.has(depth)) levels.set(depth, []);
          levels.get(depth).push(id);
        }
      }
      const maxLevel = Math.max(...levels.keys());
      const radius = new Map([[0, 0]]);
      let r = 0;
      for (let l = 1; l <= maxLevel; l += 1) {
        const needed = ((levels.get(l) || []).length * spacing) / (2 * Math.PI);
        r = Math.max(r + spacing * 0.85, needed);
        radius.set(l, r);
      }
      const pos = new Map();
      for (const [l, list] of levels) {
        const R = radius.get(l) || 0;
        const step = (2 * Math.PI) / Math.max(1, list.length);
        const offset = l % 2 ? 0 : step / 2;
        list.forEach((id, index) => {
          const angle = -Math.PI / 2 + step * index + offset;
          pos.set(id, { x: R * Math.cos(angle), y: R * Math.sin(angle) });
        });
      }
      return pos;
    }

    /* Pack component boxes into shelves so separate clusters never overlap. */
    function spreadAll(ids, spacing, adj) {
      const boxes = components(ids, adj).map((comp) => {
        const pos = ringPositions(comp, spacing, adj);
        let minX = Infinity; let minY = Infinity; let maxX = -Infinity; let maxY = -Infinity;
        for (const point of pos.values()) {
          minX = Math.min(minX, point.x); maxX = Math.max(maxX, point.x);
          minY = Math.min(minY, point.y); maxY = Math.max(maxY, point.y);
        }
        if (!Number.isFinite(minX)) { minX = 0; maxX = 0; minY = 0; maxY = 0; }
        return { pos, minX, minY, w: maxX - minX + spacing, h: maxY - minY + spacing };
      });
      const area = boxes.reduce((sum, box) => sum + box.w * box.h, 0);
      const targetWidth = Math.max(3 * spacing, Math.sqrt(area) * 1.15);
      const gap = spacing * 0.55;
      const placement = new Map();
      let x = 0; let y = 0; let rowHeight = 0;
      for (const box of boxes) {
        if (x > 0 && x + box.w > targetWidth) { x = 0; y += rowHeight + gap; rowHeight = 0; }
        const dx = x - box.minX + spacing / 2;
        const dy = y - box.minY + spacing / 2;
        for (const [id, point] of box.pos) placement.set(id, { x: point.x + dx, y: point.y + dy });
        x += box.w + gap;
        rowHeight = Math.max(rowHeight, box.h);
      }
      return placement;
    }

    /* Edges currently on screen; attribute edges are added at apply() time, so the layout
       has to read the live dataset instead of the edge list built at load time. */
    function layoutAdjacency() {
      const adj = new Map(network.body.data.nodes.getIds().map((id) => [id, new Set()]));
      for (const edge of network.body.data.edges.get()) {
        if (!adj.has(edge.from) || !adj.has(edge.to)) continue;
        adj.get(edge.from).add(edge.to);
        adj.get(edge.to).add(edge.from);
      }
      return adj;
    }

    function radial() {
      const ids = network.body.data.nodes.getIds();
      if (!ids.length) return;
      const spacing = Math.max(110, Math.round(currentFont * 9));
      const placement = spreadAll(ids, spacing, layoutAdjacency());
      network.setOptions({ physics: { enabled: false } });
      network.body.data.nodes.update([...placement.entries()].map(([id, point]) => ({
        id, x: point.x, y: point.y, physics: false,
      })));
      network.fit({ animation: false });
    }

    /* Attribute values of the displayed entities; drawn by default, scaled to the view so a
       small local graph stays readable (at most three per displayed node, 240 overall). */
    function attributeExtras(selected, size) {
      const out = { nodes: [], edges: [], info: new Map(), count: 0 };
      const toggle = document.getElementById('kg-attrs');
      if (!toggle || !toggle.checked) return out;
      const cap = Math.min(ATTR_LIMIT, Math.max(24, selected.size * 3));
      const seen = new Set();
      for (const id of selected) {
        for (const attr of (ATTRS[id] || [])) {
          if (out.count >= cap) return out;
          const nodeId = 'ATTR::' + attr.id;
          if (seen.has(nodeId)) continue;
          seen.add(nodeId);
          const details = fillPattern(T(lang, 'kgjs_attr_node'), [attr.t, attr.v, id]);
          out.nodes.push({
            id: nodeId,
            label: shortText(attr.v, 24),
            title: escapeHtml(details).replace(/\n/g, '<br>'),
            shape: 'box',
            color: { background: '#f4f6f8', border: '#b9c6cf', highlight: { background: '#e6eef5', border: '#7f9cb0' } },
            margin: 6,
            borderWidth: 1,
            widthConstraint: { minimum: 24, maximum: 150 },
            font: { size: Math.max(9, size - 5), face: 'Microsoft YaHei, Arial', color: '#33475b' },
            kgDetails: details,
          });
          out.edges.push({
            id: 'display-attr-' + attr.id, from: id, to: nodeId, label: '',
            arrows: { to: { enabled: false } }, color: '#b9c6cf', dashes: [2, 4], width: 1,
            font: { size: 9, color: '#6b7f90' }, kgKind: 'attribute', kgDetails: details,
          });
          out.info.set(nodeId, { kgDetails: details });
          out.count += 1;
        }
      }
      return out;
    }

    function apply() {
      root = nodeMap.has(focus.value) ? focus.value : root;
      detail.style.display = 'none';
      const selected = subset(root, limit.value);
      const shown = selected.size;
      currentFont = shown > 150 ? Math.min(fontSize, 14) : shown > 60 ? Math.min(fontSize, 16) : fontSize;
      const nodes = allNodes.filter((node) => selected.has(node.id))
        .map((node) => ({ ...node, font: { ...node.font, size: currentFont } }));
      const edges = allEdges.filter((edge) => selected.has(edge.from) && selected.has(edge.to))
        .map((edge) => ({ ...edge, font: { ...edge.font, size: Math.max(12, currentFont - 3) } }));
      const extras = attributeExtras(selected, currentFont);
      const baseNodes = nodes.length;
      const baseEdges = edges.length;
      nodes.push(...extras.nodes);
      edges.push(...extras.edges);
      attrInfo = extras.info;
      const token = ++stabilizationToken;
      network.setData({ nodes: new vis.DataSet(nodes), edges: new vis.DataSet(edges) });
      network.setOptions({
        physics: { enabled: true },
        nodes: { font: { size: currentFont } },
        edges: { font: { size: Math.max(12, currentFont - 3) } },
      });
      status.textContent = fillPattern(T(lang, 'kgjs_showing'),
        [baseNodes, allNodes.length, baseEdges, allEdges.length]);
      if (extras.count) {
        status.textContent += fillPattern(T(lang, 'kgjs_attributes'), [extras.count]);
      }

      function finish() {
        if (token !== stabilizationToken) return;
        radial();
        if (network.body.data.nodes.length <= 60) {
          network.moveTo({ scale: network.getScale() * 0.9, animation: false });
        }
        network.selectNodes([root], false);
        status.textContent += T(lang, 'kgjs_arranged_suffix');
      }

      if (nodes.length > 60) {
        finish();
        return;
      }
      let done = false;
      function settle() {
        if (done || token !== stabilizationToken) return;
        done = true;
        network.setOptions({ physics: { enabled: false } });
        finish();
      }
      network.once('stabilizationIterationsDone', settle);
      window.setTimeout(settle, 1800);
    }

    limit.addEventListener('change', apply);
    document.getElementById('kg-refocus').addEventListener('click', apply);
    document.getElementById('kg-in').addEventListener('click', () => network.moveTo({
      scale: Math.min(4, network.getScale() * 1.25), animation: { duration: 160 },
    }));
    document.getElementById('kg-out').addEventListener('click', () => network.moveTo({
      scale: Math.max(0.18, network.getScale() / 1.25), animation: { duration: 160 },
    }));
    document.getElementById('kg-fit').addEventListener('click', () => network.fit({ animation: { duration: 200 } }));
    document.getElementById('kg-readable').addEventListener('click', readableZoom);
    document.getElementById('kg-radial').addEventListener('click', () => {
      radial();
      status.textContent = T(lang, 'kgjs_arranged_status');
    });
    fontButton.addEventListener('click', () => {
      fontSize = fontSize >= 28 ? 20 : fontSize + 4;
      fontButton.textContent = fillPattern(T(lang, 'kgjs_font'), [fontSize]);
      currentFont = fontSize;
      network.body.data.nodes.update(network.body.data.nodes.get()
        .map((node) => ({ id: node.id, font: { ...node.font, size: currentFont } })));
      network.body.data.edges.update(network.body.data.edges.get()
        .map((edge) => ({ id: edge.id, font: { ...edge.font, size: Math.max(12, currentFont - 3) } })));
    });
    document.getElementById('kg-full').addEventListener('click', async () => {
      try {
        if (document.fullscreenElement) await document.exitFullscreen();
        else await host.requestFullscreen();
      } catch (error) {
        status.textContent += T(lang, 'kgjs_fullscreen_denied');
      }
    });
    document.getElementById('kg-attrs').addEventListener('change', apply);
    network.on('click', (params) => {
      if (params.nodes.length) {
        const id = params.nodes[0];
        const node = nodeMap.get(id);
        const info = node || attrInfo.get(id);
        if (!info) return;
        if (node) focus.value = String(id);
        detail.textContent = info.kgDetails;
        detail.style.display = 'block';
        if (node) {
          const related = network.getConnectedNodes(id);
          network.selectNodes([id, ...related], false);
        }
      } else if (params.edges.length) {
        const edge = allEdges.find((item) => item.id === params.edges[0]);
        detail.textContent = edge ? edge.kgDetails : '';
        detail.style.display = edge ? 'block' : 'none';
      } else {
        detail.style.display = 'none';
      }
    });
    network.on('doubleClick', (params) => {
      if (params.nodes.length && nodeMap.has(params.nodes[0])) {
        focus.value = String(params.nodes[0]);
        apply();
      }
    });
    window.addEventListener('resize', () => network.redraw());
    // The case tab can be hidden when the language changes; fitting a zero-width canvas
    // leaves the view zoomed in, so fit again the first time the canvas has a size.
    let pendingFit = host.clientWidth === 0;
    const observer = new ResizeObserver(() => {
      if (host.clientWidth > 0 && pendingFit) {
        pendingFit = false;
        network.redraw();
        network.fit({ animation: false });
      }
    });
    observer.observe(host);
    window.kgDisplayState = () => ({
      nodes: network.body.data.nodes.getIds(),
      edges: network.body.data.edges.getIds(),
      scale: network.getScale(), root,
    });
    apply();
  }

  window.Graph = { buildView, render, wrapLabel };
})();
