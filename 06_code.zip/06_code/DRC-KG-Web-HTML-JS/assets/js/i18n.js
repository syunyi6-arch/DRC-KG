/* Interface wording helper: the strings come from DRC-KG-Web/ui_text.py. */
(function () {
  const data = window.I18N;

  function t(lang, key, values) {
    const pair = data.text[key];
    if (!pair) return key;
    let text = String(lang).toLowerCase().startsWith('en') ? pair.en : pair.zh;
    if (values) {
      text = text.replace(/\{(\w+)\}/g, (match, name) =>
        values[name] === undefined || values[name] === null ? match : String(values[name]));
    }
    return text;
  }

  function headers(lang, kind) {
    return data.headers[kind].map((key) => data.fixed[key] || t(lang, key));
  }

  /* The graph script uses %1..%4 placeholders, as in the PyVis viewer. */
  function fill(text, values) {
    return text.replace(/%(\d)/g, (match, index) => {
      const value = values[Number(index) - 1];
      return value === undefined ? match : String(value);
    });
  }

  window.T = t;
  window.headersFor = headers;
  window.fillPattern = fill;
})();
