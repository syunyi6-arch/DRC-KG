/* Data access for the static site: one request per resource, cached in memory. */
(function () {
  const cache = new Map();

  function get(path) {
    if (!cache.has(path)) {
      const request = fetch(path, { cache: 'force-cache' }).then((response) => {
        if (!response.ok) throw new Error(`${path} (${response.status})`);
        return response.json();
      });
      cache.set(path, request);
      request.catch(() => cache.delete(path));
    }
    return cache.get(path);
  }

  window.Store = {
    cases: () => get('data/cases.json'),
    caseData: (id) => get(`data/case/${encodeURIComponent(id)}.json`),
    rules: () => get('data/rules.json'),
    facts: () => get('data/facts.json'),
    terms: () => get('data/terms.json'),
    diagnostics: () => get('data/diagnostics.json'),
  };
})();
