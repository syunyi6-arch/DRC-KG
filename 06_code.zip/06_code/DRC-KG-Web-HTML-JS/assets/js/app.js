/* Page wiring: case picker, tabs, tables, evidence tracing and the language switch. */
(function () {
  const state = {
    lang: new URLSearchParams(window.location.search).get('lang') === 'en' ? 'en' : 'zh',
    caseId: null,
    ruleScope: 'current',
    evidenceScope: 'current',
    traceFact: null,
    attrOwner: '',
    tab: 'case',
  };

  let casesData = null;
  let terms = {};
  let rulesData = null;
  let diagnosticsData = null;
  let factsData = null;
  let currentCase = null;

  const $ = (id) => document.getElementById(id);
  const t = (key, values) => T(state.lang, key, values);

  function escapeHtml(value) {
    return String(value === undefined || value === null ? '' : value)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#x27;');
  }

  function bold(text) {
    return text.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  }

  function paragraphs(text) {
    return text.split(/\n{2,}/).filter((part) => part.trim())
      .map((part) => `<p>${bold(escapeHtml(part).replace(/\n/g, '<br>'))}</p>`).join('');
  }

  function modeLine() {
    let label = t('mode_public');
    if (casesData && casesData.version) label += ' / ' + casesData.version;
    return `**${label}** · ` + t('loaded_cases', { count: casesData.cases.length });
  }

  function introHtml() {
    return '<div class="intro-card">' + ['intro_lede', 'intro_method']
      .map((key) => `<p>${t(key)}</p>`).join('') + '</div>';
  }

  function scopeOptions() {
    return [
      { value: 'current', label: t('scope_current') },
      { value: 'all', label: t('scope_all') },
    ];
  }

  function tableHtml(headers, rows) {
    const head = '<thead><tr>' + headers.map((header) => `<th>${escapeHtml(header)}</th>`).join('') + '</tr></thead>';
    const body = '<tbody>' + rows.map((row) => '<tr>'
      + row.map((cell) => `<td>${escapeHtml(cell)}</td>`).join('') + '</tr>').join('') + '</tbody>';
    return head + body;
  }

  function fillSelect(select, values, selected) {
    const fragment = document.createDocumentFragment();
    for (const value of values) {
      const option = document.createElement('option');
      option.value = value;
      option.textContent = value;
      fragment.appendChild(option);
    }
    select.textContent = '';
    select.appendChild(fragment);
    if (selected !== undefined && selected !== null) select.value = selected;
  }

  function renderRadioGroup(container, options, value, onChange) {
    container.textContent = '';
    for (const option of options) {
      const label = document.createElement('label');
      const input = document.createElement('input');
      input.type = 'radio';
      input.name = container.id;
      input.value = option.value;
      input.checked = option.value === value;
      input.addEventListener('change', () => { if (input.checked) onChange(option.value); });
      const text = document.createElement('span');
      text.textContent = option.label;
      label.appendChild(input);
      label.appendChild(text);
      container.appendChild(label);
    }
  }

  function renderTabs() {
    $('tab-case').textContent = t('tab_case');
    $('tab-rules').textContent = t('tab_rules');
    $('tab-evidence').textContent = t('tab_evidence');
    $('tab-attributes').textContent = t('tab_attributes');
    $('tab-checks').textContent = t('tab_checks');
    for (const button of document.querySelectorAll('.tabs button')) {
      const selected = button.dataset.tab === state.tab;
      button.setAttribute('aria-selected', String(selected));
      button.tabIndex = selected ? 0 : -1;
      $(`panel-${button.dataset.tab}`).hidden = !selected;
    }
  }

  /* Owning entity of an attribute: raw name, or the derived label of a withheld name. */
  function ownerLabel(row) {
    const ident = row.owner_id || '';
    const name = (row.owner_raw || '').trim();
    if (name) return ident ? `${name} (${ident})` : name;
    const entity = (currentCase ? currentCase.entities : []).find((item) => item.entity_id === ident);
    const entityName = entity ? (entity.entity_name || '').trim() : '';
    let label = entityName.indexOf('«redacted»') >= 0 ? '' : entityName;
    if (!label && entity) {
      label = T(state.lang, 'entity_redacted_label', {
        kind: Explorer.ontology(entity.ontology_class || '', state.lang, terms),
        suffix: ident.split('-').pop(),
      });
    }
    return label && ident ? `${label} (${ident})` : (label || ident);
  }

  /* Owned attributes of the current case, as the "Attributes" tab shows them. */
  function attributeRows(caseData, owner) {
    const rows = caseData.attributes || [];
    return rows.filter((row) => !owner || (row.owner_id || '') === owner).map((row) => {
      return [row.attribute_id || '', ownerLabel(row),
        Explorer.ontology(row.attribute_type || '', state.lang, terms),
        row.attribute_value || '', row.owner_status || ''];
    });
  }

  function renderAttributes() {
    if (!currentCase) return;
    const rows = currentCase.attributes || [];
    const owners = new Map();
    for (const row of rows) {
      const ident = row.owner_id || '';
      if (!ident || owners.has(ident)) continue;
      owners.set(ident, ownerLabel(row));
    }
    const options = [{ value: '', label: t('attr_all_owners') }];
    for (const [value, label] of [...owners.entries()].sort((a, b) => a[1].localeCompare(b[1]))) {
      options.push({ value, label });
    }
    if (!options.some((option) => option.value === state.attrOwner)) state.attrOwner = '';
    const select = $('attr-filter');
    select.textContent = '';
    for (const option of options) {
      const element = document.createElement('option');
      element.value = option.value;
      element.textContent = option.label;
      select.appendChild(element);
    }
    select.value = state.attrOwner;

    const scoped = rows.filter((row) => !state.attrOwner || (row.owner_id || '') === state.attrOwner);
    const ownerCount = new Set(scoped.map((row) => row.owner_id || '')).size;
    $('attr-label').textContent = t('attr_filter');
    $('attr-note').textContent = rows.length
      ? t('attr_note', { count: scoped.length, owners: ownerCount })
      : t('attr_empty');
    $('attr-table').innerHTML = tableHtml(headersFor(state.lang, 'attribute'),
      attributeRows(currentCase, state.attrOwner));
  }

  function renderCaseSelect() {
    const select = $('case-select');
    const fragment = document.createDocumentFragment();
    for (const entry of casesData.cases) {
      const option = document.createElement('option');
      option.value = entry.id;
      option.textContent = `${entry.id} | ${(entry.title || '').slice(0, 85)}`;
      fragment.appendChild(option);
    }
    select.textContent = '';
    select.appendChild(fragment);
    select.value = state.caseId;
  }

  function summaryHtml(caseData) {
    const counts = t('counts', {
      entities: caseData.counts.entities,
      relations: caseData.counts.relations,
      transmission: caseData.counts.transmission,
      rules: caseData.counts.rules,
    });
    return `<h3>${escapeHtml(caseData.title || caseData.id)}</h3>`
      + paragraphs(t('case_meta', { case_id: caseData.id, language: caseData.language }))
      + paragraphs(counts)
      + paragraphs(t('summary_note'));
  }

  function renderCase() {
    if (!currentCase) return;
    $('summary').innerHTML = summaryHtml(currentCase);
    $('case-note').textContent = t('case_graph_note');
    $('triple-note').textContent = t('triple_note');
    $('relation-table').innerHTML = tableHtml(headersFor(state.lang, 'triple'),
      Explorer.combinedRows(currentCase, state.lang, terms));
    const triples = Explorer.triples(Explorer.classifiedRecords(currentCase));
    Graph.render($('graph'), Graph.buildView(currentCase, state.lang, terms, triples), state.lang);
  }

  function renderRules() {
    renderRadioGroup($('rule-scope'), scopeOptions(), state.ruleScope, (value) => {
      state.ruleScope = value;
      renderRules();
    });
    if (!rulesData) return;
    const table = Explorer.rulesTable(state.ruleScope, currentCase, rulesData, state.lang);
    $('rule-note').textContent = table.note;
    $('rules-note').textContent = t('rules_note');
    $('rule-table').innerHTML = tableHtml(headersFor(state.lang, 'rule'), table.rows);
  }

  function factMeta(id, scope) {
    if (scope === 'all') {
      if (!factsData || !factsData.case[id]) return null;
      const table = factsData.type[id];
      const kind = table === 'relations' ? 'relation' : table === 'transmission' ? 'transmission' : 'rule';
      return { caseId: factsData.case[id], kind };
    }
    if (currentCase.relations.some((row) => row.relation_id === id)) {
      return { caseId: currentCase.id, kind: 'relation' };
    }
    if (currentCase.transmission.some((row) => row.transmission_id === id)) {
      return { caseId: currentCase.id, kind: 'transmission' };
    }
    if (currentCase.rules.some((row) => row.rule_id === id)) {
      return { caseId: currentCase.id, kind: 'rule' };
    }
    return null;
  }

  async function renderTrace() {
    const id = state.traceFact;
    if (!id) {
      $('trace-note').textContent = t('empty_trace_note');
      $('trace-json').textContent = '';
      $('evidence-table').innerHTML = tableHtml(headersFor(state.lang, 'evidence'), []);
      return;
    }
    const meta = factMeta(id, state.evidenceScope);
    if (!meta) {
      $('trace-note').textContent = t('empty_trace_note');
      $('trace-json').textContent = JSON.stringify({ status: 'not_found', evidence: [] }, null, 2);
      $('evidence-table').innerHTML = tableHtml(headersFor(state.lang, 'evidence'), []);
      return;
    }
    const caseData = meta.caseId === currentCase.id ? currentCase : await Store.caseData(meta.caseId);
    const panel = Explorer.tracePanel(caseData, state.lang, meta.kind, id, state.evidenceScope);
    $('trace-note').textContent = panel.note;
    $('trace-json').textContent = JSON.stringify(panel.result, null, 2);
    $('evidence-table').innerHTML = tableHtml(headersFor(state.lang, 'evidence'), panel.rows);
  }

  async function renderEvidence() {
    renderRadioGroup($('evidence-scope'), scopeOptions(), state.evidenceScope, (value) => {
      state.evidenceScope = value;
      renderEvidence();
    });
    if (state.evidenceScope === 'all' && !factsData) factsData = await Store.facts();
    const choices = Explorer.factChoices(currentCase, state.evidenceScope, factsData);
    const first = choices.length ? choices[0] : null;
    fillSelect($('trace-select'), choices, first);
    state.traceFact = first;
    $('trace-label').textContent = t('trace_picker');
    $('trace-button').textContent = t('trace_button');
    $('evidence-note').textContent = t('evidence_note_public');
    await renderTrace();
  }

  function renderChecks() {
    const payload = JSON.parse(JSON.stringify(diagnosticsData));
    const types = {};
    for (const [key, value] of Object.entries(payload.evidence_by_fact_type || {})) {
      types[key === 'untyped' ? t('untyped') : key] = value;
    }
    payload.evidence_by_fact_type = types;
    $('diagnostics').textContent = JSON.stringify(payload, null, 2);
    $('rule-source-note').textContent = t('lr_public_text');
  }

  function renderAll() {
    document.documentElement.lang = state.lang === 'en' ? 'en' : 'zh-CN';
    document.title = t('app_title').replace(/^#\s*/, '');
    $('app-title').textContent = t('app_title').replace(/^#\s*/, '');
    $('mode-line').innerHTML = bold(escapeHtml(modeLine()));
    $('intro').innerHTML = introHtml();
    $('case-label').textContent = t('case_picker');
    $('lang-label').textContent = t('language');
    renderRadioGroup($('lang-group'), [
      { value: 'zh', label: t('lang_zh') },
      { value: 'en', label: t('lang_en') },
    ], state.lang, (value) => {
      state.lang = value;
      renderAll();
    });
    renderTabs();
    renderCase();
    renderRules();
    renderEvidence();
    renderAttributes();
    renderChecks();
  }

  function showError(error) {
    const box = $('load-error');
    box.hidden = false;
    box.textContent = 'Data could not be loaded: ' + error.message
      + ' — serve this folder over HTTP (see README.md), opening index.html from disk is blocked by the browser.';
    console.error(error);
  }

  async function selectCase(id) {
    const select = $('case-select');
    select.disabled = true;
    try {
      state.caseId = id;
      currentCase = await Store.caseData(id);
      state.attrOwner = '';
      renderCase();
      renderRules();
      await renderEvidence();
      renderAttributes();
    } catch (error) {
      showError(error);
    } finally {
      select.disabled = false;
    }
  }

  async function init() {
    try {
      [casesData, terms, rulesData, diagnosticsData] = await Promise.all([
        Store.cases(), Store.terms(), Store.rules(), Store.diagnostics(),
      ]);
      state.caseId = casesData.cases[0].id;
      currentCase = await Store.caseData(state.caseId);
      renderCaseSelect();
      renderAll();
    } catch (error) {
      showError(error);
      return;
    }

    $('case-select').addEventListener('change', (event) => selectCase(event.target.value));
    $('attr-filter').addEventListener('change', (event) => {
      state.attrOwner = event.target.value;
      renderAttributes();
    });
    $('trace-select').addEventListener('change', (event) => {
      state.traceFact = event.target.value;
      renderTrace();
    });
    $('trace-button').addEventListener('click', () => renderTrace());
    for (const button of document.querySelectorAll('.tabs button')) {
      button.addEventListener('click', () => {
        state.tab = button.dataset.tab;
        renderTabs();
      });
    }
  }

  window.addEventListener('DOMContentLoaded', init);
})();
