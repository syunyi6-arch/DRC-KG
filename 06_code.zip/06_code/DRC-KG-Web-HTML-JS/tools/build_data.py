"""Build the JSON data files for the static HTML + JavaScript explorer.

Reads the validated release in the Gradio project (public_data) and writes one
compact JSON per case plus a few global indexes. The browser then loads only the
case it displays, so the page never downloads the full 90 MB of CSV.
"""
import json
import os
import sys
from pathlib import Path

SITE = Path(__file__).resolve().parents[1]
SOURCE = Path(os.getenv('DRC_KG_SOURCE', SITE.parent / 'DRC-KG-Web'))
sys.path.insert(0, str(SOURCE))

from release_check import check_public_release  # noqa: E402

DATA = SITE / 'data'

# Columns kept per table; the interface never shows anything else.
FIELDS = {
    'entities': ('entity_id', 'entity_name', 'ontology_class', 'identity_status', 'resolution_status'),
    'attributes': ('attribute_id', 'owner_id', 'owner_raw', 'attribute_type', 'attribute_value',
                   'owner_status'),
    'relations': ('relation_id', 'head_kind', 'head_id', 'head_raw', 'relation_original',
                  'ontology_relation', 'tail_kind', 'tail_id', 'tail_raw', 'endpoint_status',
                  'transmission_id', 'relation_layer', 'ku_id'),
    'transmission': ('transmission_id', 'source_id', 'source_raw', 'source_status', 'target_id',
                     'target_raw', 'target_status', 'certainty_original', 'association_nature',
                     'assertion_polarity', 'resolution_status', 'graph_ready'),
    'rules': ('rule_id', 'rule_group_id', 'title_block', 'ku_id', 'n_elements', 'subject',
              'conditions', 'result', 'authority'),
    'rule_elements': ('rule_element_id', 'rule_id', 'source_row', 'element_order',
                      'element_original', 'content_original', 'element_category', 'ku_id',
                      'evidence_id'),
    'knowledge_units': ('ku_id', 'case_id', 'source_page', 'source_section', 'source_table', 'section'),
    'evidence_references': ('evidence_id', 'case_id', 'fact_type', 'fact_id', 'ku_id', 'kuc_id',
                            'source_file', 'source_doi', 'source_url', 'source_page',
                            'source_section', 'source_table', 'source_sheet', 'source_row'),
}


def pick(row, name):
    return {field: row.get(field, '') for field in FIELDS[name] if row.get(field) != ''}


def group(rows, key='case_id'):
    out = {}
    for row in rows:
        out.setdefault(row.get(key, ''), []).append(row)
    return out


def write(path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, separators=(',', ':')),
                    encoding='utf-8')
    return path.stat().st_size


def main():
    tables, manifest = check_public_release(SOURCE / 'public_data')
    cases = tables['cases']
    entities = group(tables['entities'])
    relations = group(tables['relations'])
    transmission = group(tables['transmission'])
    rules = group(tables['rules'])
    elements = group(tables['rule_elements'])
    attributes = group(tables['attributes'])
    kus = group(tables['knowledge_units'])
    evidence = group(tables['evidence_references'])

    total = 0
    index = []
    for case in cases:
        cid = case['case_id']
        payload = {
            'id': cid,
            'title': case.get('title', ''),
            'language': case.get('language', ''),
            'source_file': case.get('source_file', ''),
            'relations': [pick(r, 'relations') for r in relations.get(cid, [])],
            'entities': [pick(r, 'entities') for r in entities.get(cid, [])],
            'transmission': [pick(r, 'transmission') for r in transmission.get(cid, [])],
            'rules': [pick(r, 'rules') for r in rules.get(cid, [])],
            'elements': [pick(r, 'rule_elements') for r in elements.get(cid, [])],
            'attributes': [pick(r, 'attributes') for r in attributes.get(cid, [])],
            'kus': [pick(r, 'knowledge_units') for r in kus.get(cid, [])],
            'evidence': [pick(r, 'evidence_references') for r in evidence.get(cid, [])],
        }
        payload['counts'] = {
            'entities': len(payload['entities']),
            'relations': len(payload['relations']),
            'transmission': len(payload['transmission']),
            'rules': len(payload['rules']),
        }
        total += write(DATA / 'case' / f'{cid}.json', payload)
        index.append({'id': cid, 'title': payload['title'], 'language': payload['language'],
                      'counts': payload['counts']})

    # Global rule index: the "all loaded cases" option needs every rule and element.
    write(DATA / 'rules.json', {
        'rules': [dict(pick(r, 'rules'), case_id=r['case_id']) for r in tables['rules']],
        'elements': [dict(pick(e, 'rule_elements'), case_id=e['case_id']) for e in tables['rule_elements']],
        'cases': {c['case_id']: {'title': c.get('title', ''), 'source_file': c.get('source_file', '')}
                  for c in cases},
    })

    # Global fact index for the "all loaded cases" evidence option, in the same order
    # as the Gradio app produced it: relations, then transmission, then rules.
    order, owner, kind = [], {}, {}
    for name, key in (('relations', 'relation_id'), ('transmission', 'transmission_id'),
                      ('rules', 'rule_id')):
        for row in tables[name]:
            ident = row.get(key, '')
            if ident:
                order.append(ident)
                owner[ident] = row.get('case_id', '')
                kind[ident] = name
    write(DATA / 'facts.json', {'order': order, 'case': owner, 'type': kind})

    terms = {}
    for row in tables.get('ontology_term_map', []):
        en = row.get('label_en') or ''
        zh = row.get('label_zh') or ''
        if en and zh:
            terms[en] = zh
    write(DATA / 'terms.json', terms)

    by_language, evidence_types = {}, {}
    for case in cases:
        by_language[case.get('language', '')] = by_language.get(case.get('language', ''), 0) + 1
    for row in tables['evidence_references']:
        key = row.get('fact_type', '') or 'untyped'
        evidence_types[key] = evidence_types.get(key, 0) + 1
    write(DATA / 'diagnostics.json', {
        'counts': {name: len(rows) for name, rows in tables.items()},
        'cases_by_language': by_language,
        'cases_with_transmission': len({r.get('case_id') for r in tables['transmission']}),
        'cases_with_rules': len({r.get('case_id') for r in tables['rules']}),
        'release_view_rules_without_condition_and_result_text': sum(
            1 for r in tables['rules'] if not r.get('conditions') and not r.get('result')),
        'local_original_rule_records': 0,
        'local_original_rule_elements': 0,
        'evidence_by_fact_type': evidence_types,
    })

    write(DATA / 'cases.json', {'version': str(manifest.get('version', '')), 'cases': index})

    size = sum(p.stat().st_size for p in DATA.rglob('*.json'))
    print(f'cases      : {len(index)}')
    print(f'case files : {len(list((DATA / "case").glob("*.json")))}')
    print(f'total JSON : {size / 1048576:.1f} MB')
    print(f'largest    : {max((p.stat().st_size, p.name) for p in (DATA / "case").glob("*.json"))[1]}')


if __name__ == '__main__':
    main()
