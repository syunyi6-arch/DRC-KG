# -*- coding: utf-8 -*-
"""Build the JSON data files of the static explorer from the standardized KG tables.

Reads 04_knowledge_graph/01_standardized_data/*.csv (and the ontology term map) and writes
one compact JSON per case plus the global indexes. The browser then loads only the case it
displays, so the page never downloads the whole 90 MB of CSV.

The site and 04_knowledge_graph share one single source of truth; the incremental batch
(increment_1115, 149 rows over 19 cases) is included.

Field mapping notes:
  * entity_name      <- entities.entity_raw, ontology_class <- entities.class_label_en
  * owner_id / head_id / tail_id / source_id / target_id: DRC-KG does not disambiguate
    entities across cases, so these are *case-local literal matches* between a raw name and
    an entity of the same case. They are published as endpoint_status='candidate'
    (or 'unresolved' when no entity of the case carries that name).
  * source_section / source_page / certainty_original / association_nature /
    assertion_polarity / relation_layer are not part of the standardized tables; they are
    emitted empty (the interface already treats them as optional).
  * knowledge_units keeps the locator semantics of the release: text SHA-256 + length only,
    never the sentence.

Run from 06_code/DRC-KG-Web-HTML-JS/:  python -X utf8 tools/build_web_data.py
"""
import csv
import json
import os
import sys
import unicodedata
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")

SITE = Path(__file__).resolve().parents[1]
Z = SITE.parents[1]
STD = Path(os.getenv("DRC_KG_STD", Z / "04_knowledge_graph" / "01_standardized_data"))
ONTO = Path(os.getenv("DRC_KG_ONTO", Z / "03_ontology" / "ontology_term_map.csv"))
DATA = SITE / "data"

# Columns kept per table; the interface never shows anything else.
FIELDS = {
    "entities": ("entity_id", "entity_name", "ontology_class", "identity_status",
                 "resolution_status"),
    "attributes": ("attribute_id", "owner_id", "owner_raw", "attribute_type", "attribute_value",
                   "owner_status"),
    "relations": ("relation_id", "head_kind", "head_id", "head_raw", "relation_original",
                  "ontology_relation", "tail_kind", "tail_id", "tail_raw", "endpoint_status",
                  "transmission_id", "relation_layer", "ku_id"),
    "transmission": ("transmission_id", "source_id", "source_raw", "source_status", "target_id",
                     "target_raw", "target_status", "certainty_original", "association_nature",
                     "assertion_polarity", "resolution_status", "graph_ready"),
    "rules": ("rule_id", "rule_group_id", "title_block", "ku_id", "n_elements", "subject",
              "conditions", "result", "authority"),
    "rule_elements": ("rule_element_id", "rule_id", "source_row", "element_order",
                      "element_original", "content_original", "element_category", "ku_id",
                      "evidence_id"),
    "knowledge_units": ("ku_id", "case_id", "source_page", "source_section", "source_table",
                        "section"),
    "evidence_references": ("evidence_id", "case_id", "fact_type", "fact_id", "ku_id", "kuc_id",
                            "source_file", "source_doi", "source_url", "source_page",
                            "source_section", "source_table", "source_sheet", "source_row"),
}
TABLE_FILES = {
    "cases": "cases.csv",
    "entities": "entities.csv",
    "attributes": "attributes.csv",
    "relations": "relations.csv",
    "transmission": "transmission.csv",
    "transmission_participants": "transmission_participants.csv",
    "transmission_attributes": "transmission_attributes.csv",
    "rules": "rules.csv",
    "rule_elements": "rule_elements.csv",
    "rule_groups": "rule_groups.csv",
    "knowledge_units": "knowledge_units.csv",
    "knowledge_unit_clusters": "knowledge_unit_clusters.csv",
    "evidence_references": "evidence_references.csv",
}


def norm(value):
    if value is None:
        return ""
    return unicodedata.normalize("NFKC", str(value)).strip()


def read(name):
    with open(STD / TABLE_FILES[name], encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def pick(row, name):
    return {field: row[field] for field in FIELDS[name] if row.get(field, "") != ""}


def write(path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, separators=(",", ":")),
                    encoding="utf-8")
    return path.stat().st_size


def build_name_index(entities):
    """case-local raw-name -> entity_id; the class disambiguates homonyms."""
    by_case = {}
    for row in entities:
        by_case.setdefault(row["case_id"], []).append(row)
    index = {}
    for case_id, rows in by_case.items():
        exact, loose = {}, {}
        for row in rows:
            key = (norm(row["entity_raw"]).lower(), norm(row["class_label_zh"]))
            exact.setdefault(key, row["entity_id"])
            loose.setdefault(norm(row["entity_raw"]).lower(), row["entity_id"])
        index[case_id] = (exact, loose)
    return index


def resolve(index, case_id, raw, class_zh=""):
    exact, loose = index.get(case_id, ({}, {}))
    key = (norm(raw).lower(), norm(class_zh))
    if class_zh and key in exact:
        return exact[key]
    return loose.get(norm(raw).lower(), "")


def main():
    tables = {name: read(name) for name in TABLE_FILES}
    cases = tables["cases"]

    # ---- case-local entity resolution (literal match, same case only)
    index = build_name_index(tables["entities"])

    # ---- knowledge units -> cluster, and rule element -> evidence id
    ku_cluster = {row["ku_id"]: row["cluster_id"] for row in tables["knowledge_units"]}
    ku_table = {row["ku_id"]: (json.loads(row["source_sheets"] or "[]") or [""])[0]
                for row in tables["knowledge_units"]}
    element_evidence = {row["fact_id"]: row["evidence_id"] for row in tables["evidence_references"]
                        if row["fact_type"] == "rule_element"}

    # ---- head/tail participant of every transmission instance
    tr_head, tr_tail = {}, {}
    for row in tables["transmission_participants"]:
        role = row["role_raw"] or ""
        tr_id = row["transmission_id"]
        if "头实体" in role:
            tr_head.setdefault(tr_id, row)
        elif "尾实体" in role:
            tr_tail.setdefault(tr_id, row)

    def group(name):
        out = {}
        for row in tables[name]:
            out.setdefault(row.get("case_id", ""), []).append(row)
        return out

    grouped = {name: group(name) for name in (
        "entities", "attributes", "relations", "transmission", "rules", "rule_elements",
        "knowledge_units", "evidence_references")}

    # ---- per-case entity payloads with raw names, plus the derived fields
    entities_out = {}
    for case_id, rows in grouped["entities"].items():
        entities_out[case_id] = [{
            "entity_id": row["entity_id"],
            "entity_name": row["entity_raw"],
            "ontology_class": row["class_label_en"],
            "identity_status": row["identity_status"],
            "resolution_status": "",
        } for row in rows]

    attributes_out = {}
    for case_id, rows in grouped["attributes"].items():
        items = []
        for row in rows:
            owner_id = resolve(index, case_id, row["owner_entity_raw"], row["class_label_zh"])
            items.append({
                "attribute_id": row["attribute_id"],
                "owner_id": owner_id,
                "owner_raw": row["owner_entity_raw"],
                "attribute_type": row["attribute_label_en"],
                "attribute_value": row["attribute_value"],
                "owner_status": "candidate" if owner_id else "",
            })
        attributes_out[case_id] = items

    relations_out = {}
    for case_id, rows in grouped["relations"].items():
        items = []
        for row in rows:
            head_id = resolve(index, case_id, row["head_value"], row["head_class_zh"])
            tail_id = resolve(index, case_id, row["tail_value"], row["tail_class_zh"])
            items.append({
                "relation_id": row["relation_id"],
                "head_kind": "entity",
                "head_id": head_id,
                "head_raw": row["head_value"],
                "relation_original": row["relation_raw"],
                "ontology_relation": row["ontology_relation_en"],
                "tail_kind": "entity",
                "tail_id": tail_id,
                "tail_raw": row["tail_value"],
                "endpoint_status": "candidate" if (head_id and tail_id) else "unresolved",
                "transmission_id": "",
                "relation_layer": "plain",
                "ku_id": "",
            })
        relations_out[case_id] = items

    # ---- relation_id -> ku_id, from the evidence of each relation assertion
    rel_ku = {}
    for row in tables["evidence_references"]:
        if row["fact_type"] == "relation" and row["fact_id"] not in rel_ku:
            rel_ku[row["fact_id"]] = row["ku_id"]
    for items in relations_out.values():
        for item in items:
            item["ku_id"] = rel_ku.get(item["relation_id"], "")

    transmission_out = {}
    for case_id, rows in grouped["transmission"].items():
        items = []
        for row in rows:
            head = tr_head.get(row["transmission_id"], {})
            tail = tr_tail.get(row["transmission_id"], {})
            source_id = resolve(index, case_id, head.get("entity_value", ""),
                                head.get("class_label_zh", "")) if head else ""
            target_id = resolve(index, case_id, tail.get("entity_value", ""),
                                tail.get("class_label_zh", "")) if tail else ""
            items.append({
                "transmission_id": row["transmission_id"],
                "source_id": source_id,
                "source_raw": row["head_participant"],
                "source_status": "candidate" if source_id else "",
                "target_id": target_id,
                "target_raw": row["tail_participant"],
                "target_status": "candidate" if target_id else "",
                "certainty_original": "",
                "association_nature": "",
                "assertion_polarity": "",
                "resolution_status": "",
                "graph_ready": row["graph_ready"],
            })
        transmission_out[case_id] = items

    rules_out = {}
    for case_id, rows in grouped["rules"].items():
        rules_out[case_id] = [dict(pick(row, "rules")) for row in rows]

    elements_out = {}
    for case_id, rows in grouped["rule_elements"].items():
        items = []
        for row in rows:
            item = {
                "rule_element_id": row["rule_element_id"],
                "rule_id": row["rule_id"],
                "source_row": row["source_row"],
                "element_order": row["element_order"],
                "element_original": row["element_raw"],
                "content_original": row["content"],
                "element_category": row["element_category"],
                "ku_id": row["ku_id"],
                "evidence_id": element_evidence.get(row["rule_element_id"], ""),
            }
            items.append(item)
        elements_out[case_id] = items

    kus_out = {}
    for case_id, rows in grouped["knowledge_units"].items():
        kus_out[case_id] = [{
            "ku_id": row["ku_id"],
            "case_id": row["case_id"],
            "source_page": "",
            "source_section": "",
            "source_table": ku_table.get(row["ku_id"], ""),
            "section": "",
        } for row in rows]

    evidence_out = {}
    for case_id, rows in grouped["evidence_references"].items():
        items = []
        for row in rows:
            items.append({
                "evidence_id": row["evidence_id"],
                "case_id": row["case_id"],
                "fact_type": row["fact_type"],
                "fact_id": row["fact_id"],
                "ku_id": row["ku_id"],
                "kuc_id": ku_cluster.get(row["ku_id"], ""),
                "source_file": row["source_file"],
                "source_doi": "",
                "source_url": "",
                "source_page": "",
                "source_section": "",
                "source_table": row["source_sheet"],
                "source_sheet": row["source_sheet"],
                "source_row": row["source_row"],
            })
        evidence_out[case_id] = items

    # ---- one shard per case
    case_dir = DATA / "case"
    case_dir.mkdir(parents=True, exist_ok=True)
    for stale in case_dir.glob("*.json"):
        stale.unlink()

    total = 0
    index_rows = []
    for case in cases:
        cid = case["case_id"]
        payload = {
            "id": cid,
            "title": case["title"],
            "language": case["language"],
            "source_file": (json.loads(case["source_files"] or "[]") or [""])[0],
            "relations": relations_out.get(cid, []),
            "entities": entities_out.get(cid, []),
            "transmission": transmission_out.get(cid, []),
            "rules": rules_out.get(cid, []),
            "elements": elements_out.get(cid, []),
            "attributes": attributes_out.get(cid, []),
            "kus": kus_out.get(cid, []),
            "evidence": evidence_out.get(cid, []),
        }
        payload["counts"] = {
            "entities": len(payload["entities"]),
            "relations": len(payload["relations"]),
            "transmission": len(payload["transmission"]),
            "rules": len(payload["rules"]),
        }
        total += write(case_dir / ("%s.json" % cid), payload)
        index_rows.append({"id": cid, "title": payload["title"],
                           "language": payload["language"], "counts": payload["counts"]})

    # ---- global indexes
    write(DATA / "rules.json", {
        "rules": [dict(pick(row, "rules"), case_id=row["case_id"]) for row in tables["rules"]],
        "elements": [dict(pick(row, "rule_elements"), case_id=row["case_id"])
                     for row in tables["rule_elements"]],
        "cases": {row["case_id"]: {"title": row["title"],
                                   "source_file": (json.loads(row["source_files"] or "[]") or [""])[0]}
                  for row in cases},
    })

    order, owner, kind = [], {}, {}
    for name, key in (("relations", "relation_id"), ("transmission", "transmission_id"),
                      ("rules", "rule_id")):
        for row in tables[name]:
            ident = row.get(key, "")
            if ident:
                order.append(ident)
                owner[ident] = row["case_id"]
                kind[ident] = name
    write(DATA / "facts.json", {"order": order, "case": owner, "type": kind})

    terms = {}
    with open(ONTO, encoding="utf-8-sig", newline="") as handle:
        ontology_rows = list(csv.DictReader(handle))
    for row in ontology_rows:
        if row.get("label_en") and row.get("label_zh"):
            terms[row["label_en"]] = row["label_zh"]
    write(DATA / "terms.json", terms)

    by_language, evidence_types = {}, {}
    for case in cases:
        by_language[case["language"]] = by_language.get(case["language"], 0) + 1
    for row in tables["evidence_references"]:
        key = row.get("fact_type") or "untyped"
        evidence_types[key] = evidence_types.get(key, 0) + 1

    manifest = json.loads((STD / "release_manifest.json").read_text(encoding="utf-8"))
    counts = {name: len(rows) for name, rows in tables.items()}
    counts["ontology_term_map"] = len(ontology_rows)
    counts["cases"] = len(cases)
    write(DATA / "diagnostics.json", {
        "counts": counts,
        "cases_by_language": by_language,
        "cases_with_transmission": len({row["case_id"] for row in tables["transmission"]}),
        "cases_with_rules": len({row["case_id"] for row in tables["rules"]}),
        "release_view_rules_without_condition_and_result_text": sum(
            1 for row in tables["rules"] if not row["conditions"] and not row["result"]),
        "local_original_rule_records": 0,
        "local_original_rule_elements": 0,
        "evidence_by_fact_type": evidence_types,
        "cases_with_increment_rows": sum(
            1 for case in cases if int(case.get("n_increment_rows") or 0) > 0),
        "increment_rows": sum(int(case.get("n_increment_rows") or 0) for case in cases),
        "release": {
            "version": manifest.get("version", ""),
            "generated": manifest.get("generated", ""),
            "mode": manifest.get("mode", ""),
            "source": "04_knowledge_graph/01_standardized_data",
            "increment": manifest.get("increment", {}),
        },
    })

    write(DATA / "cases.json", {"version": str(manifest.get("version", "")), "cases": index_rows})

    size = sum(p.stat().st_size for p in DATA.rglob("*.json"))
    print("cases      :", len(index_rows))
    print("case files :", len(list(case_dir.glob("*.json"))))
    print("total JSON : %.1f MB" % (size / 1048576))
    print("largest    :", max((p.stat().st_size, p.name) for p in case_dir.glob("*.json"))[1])
    print("increment  :", sum(int(c.get("n_increment_rows") or 0) for c in cases), "rows over",
          sum(1 for c in cases if int(c.get("n_increment_rows") or 0) > 0), "cases")


if __name__ == "__main__":
    main()
