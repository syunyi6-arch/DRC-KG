/* Headless smoke test of the static explorer logic (no browser, no vis-network).
   Loads the shipped scripts in a vm context and exercises the code paths the page uses. */
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const SITE = path.resolve(__dirname, '..');
const read = (p) => fs.readFileSync(path.join(SITE, p), 'utf8');
const loadJson = (p) => JSON.parse(fs.readFileSync(path.join(SITE, p), 'utf8'));

const context = { console };
context.window = context;
context.document = { createElement: () => ({ classList: { add() {}, remove() {} }, style: {} }) };
context.fetch = () => { throw new Error('fetch is not available in the smoke test'); };
vm.createContext(context);

for (const script of ['assets/js/i18n-data.js', 'assets/js/i18n.js',
  'assets/js/explorer.js', 'assets/js/graph.js']) {
  vm.runInContext(read(script), context, { filename: script });
}

const terms = loadJson('data/terms.json');
const cases = loadJson('data/cases.json');
const diagnostics = loadJson('data/diagnostics.json');
const rulesData = loadJson('data/rules.json');

const problems = [];
const check = (label, condition, detail) => {
  if (!condition) problems.push(`${label}: ${detail}`);
};

check('cases.json', cases.cases.length === 261, `cases=${cases.cases.length}`);
check('diagnostics', diagnostics.counts.cases === 261, JSON.stringify(diagnostics.counts.cases));
check('rules.json', rulesData.rules.length === 250, `rules=${rulesData.rules.length}`);

const { Explorer, Graph } = context;
let totals = { relations: 0, rows: 0, local: 0, tracesOk: 0, graphEdges: 0, emptyGraphs: [] };
const increments = cases.cases.filter((c) => (c.counts.rules || 0) >= 0);

for (const entry of cases.cases) {
  const caseData = loadJson(`data/case/${entry.id}.json`);
  totals.relations += caseData.relations.length;
  totals.rows += Explorer.combinedRows(caseData, 'zh', terms).length;
  totals.local += Explorer.localRows(caseData, 'zh', terms).rows.length;

  // trace: every relation of the first ten cases must report evidence
  if (entry.id.startsWith('CN-01') || entry.id.startsWith('EN-00')) {
    for (const relation of caseData.relations.slice(0, 3)) {
      const result = Explorer.trace(caseData, 'zh', 'relation', relation.relation_id, 'local');
      if (result.status === 'ok') totals.tracesOk += 1;
      else problems.push(`trace ${entry.id} ${relation.relation_id}: ${result.status}`);
    }
    for (const tr of caseData.transmission.slice(0, 2)) {
      const result = Explorer.trace(caseData, 'zh', 'transmission', tr.transmission_id, 'local');
      if (result.status !== 'ok') problems.push(`transmission trace ${entry.id} ${tr.transmission_id}: ${result.status}`);
    }
  }

  const view = Graph.buildView(caseData, 'zh', terms, []);
  totals.graphEdges += view.edges.length;
  if (caseData.relations.length > 0 && view.edges.filter((e) => e.kind === 'relation').length === 0) {
    totals.emptyGraphs.push(entry.id);
  }
}

// attributes tab of a case that only has increment rows added
const target = loadJson('data/case/CN-011.json');
const attrRows = target.attributes.map((row) => {
  const entity = target.entities.find((item) => item.entity_id === (row.owner_id || ''));
  return [row.attribute_id, entity ? entity.entity_name : '', row.attribute_type, row.attribute_value];
});
const incrementAttr = attrRows.find((row) => row[3] === '19例');

console.log('relations            :', totals.relations);
console.log('combined rows        :', totals.rows);
console.log('local selection rows :', totals.local);
console.log('relation traces ok   :', totals.tracesOk);
console.log('graph edges          :', totals.graphEdges);
console.log('empty graphs         :', totals.emptyGraphs.length, totals.emptyGraphs.slice(0, 5));
console.log('CN-011 increment attr:', JSON.stringify(incrementAttr));
console.log('problems             :', problems.length, problems.slice(0, 5));
if (problems.length) process.exitCode = 1;
